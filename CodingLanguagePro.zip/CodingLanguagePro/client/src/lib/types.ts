export type QuestionType = 
  | 'multiple_choice' 
  | 'checkbox' 
  | 'text' 
  | 'textarea' 
  | 'rating' 
  | 'date' 
  | 'image_choice' 
  | 'dropdown' 
  | 'slider';

export interface SurveyQuestion {
  id: string;
  type: QuestionType;
  title: string;
  required: boolean;
  options?: string[];
  placeholder?: string;
  minValue?: number;
  maxValue?: number;
  step?: number;
  allowMultiple?: boolean;
  images?: string[];
}

export interface SurveyResponse {
  questionId: string;
  answer: string | string[] | number;
}
