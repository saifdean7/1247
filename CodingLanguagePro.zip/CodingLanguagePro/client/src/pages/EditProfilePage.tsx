import { useState } from 'react';
import { User } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, Save, Upload, MapPin, Link2, Briefcase } from 'lucide-react';

const EditProfilePage = () => {
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const queryClient = useQueryClient();
  const userId = 1; // Using demo user for now
  
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });

  // Form state
  const [username, setUsername] = useState<string>('');
  const [displayName, setDisplayName] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [bio, setBio] = useState<string>('');
  const [location, setLocation] = useState<string>('New York, USA');
  const [website, setWebsite] = useState<string>('surveyhub.com');
  const [occupation, setOccupation] = useState<string>('Survey Specialist');
  
  // Initialize form with user data when available
  useState(() => {
    if (user) {
      setUsername(user.username || '');
      setDisplayName(user.displayName || '');
      setTitle(user.title || '');
      setBio(user.bio || '');
    }
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data: Partial<User>) => {
      const res = await apiRequest('PATCH', `/api/users/${userId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      // Redirect back to profile page
      navigate('/profile');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const handleProfileUpdate = () => {
    const updateData: Partial<User> = {
      username,
      displayName,
      title,
      bio
    };
    
    updateUserMutation.mutate(updateData);
  };

  const handleUploadProfileImage = () => {
    toast({
      title: "Upload functionality",
      description: "This feature will upload a new profile image.",
    });
  };

  const handleUploadCoverImage = () => {
    toast({
      title: "Upload functionality",
      description: "This feature will upload a new cover image.",
    });
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="animate-pulse space-y-6 mt-8">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="h-12 w-full bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="h-12 w-full bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="h-32 w-full bg-slate-200 dark:bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !user) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="bg-red-50 dark:bg-red-900/30 p-4 rounded-md mt-8">
          <h3 className="text-red-800 dark:text-red-300 font-medium">Error loading profile</h3>
          <p className="text-red-700 dark:text-red-400 mt-2">{error instanceof Error ? error.message : 'Unknown error'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => navigate('/profile')} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Edit Profile</h1>
        </div>
        <Button onClick={handleProfileUpdate} disabled={updateUserMutation.isPending}>
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
        <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700">
          <h2 className="text-lg font-medium text-slate-900 dark:text-white">
            Profile Images
          </h2>
        </div>
        <div className="px-6 py-5 grid grid-cols-1 gap-6 md:grid-cols-2">
          <div>
            <Label htmlFor="profile-picture">Profile Picture</Label>
            <div className="mt-2 flex items-center">
              <div className="h-20 w-20 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-700">
                <img 
                  src={user.profileImageUrl || "https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"} 
                  alt="Profile" 
                  className="h-full w-full object-cover" 
                />
              </div>
              <Button variant="outline" size="sm" className="ml-5" onClick={handleUploadProfileImage}>
                <Upload className="h-4 w-4 mr-2" />
                Change Image
              </Button>
            </div>
          </div>
          <div>
            <Label htmlFor="cover-picture">Cover Image</Label>
            <div className="mt-2 flex items-center">
              <div className="h-20 w-40 rounded overflow-hidden bg-slate-100 dark:bg-slate-700">
                <img 
                  src={user.coverImageUrl || "https://images.unsplash.com/photo-1606166193756-28758468c459?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"} 
                  alt="Cover" 
                  className="h-full w-full object-cover" 
                />
              </div>
              <Button variant="outline" size="sm" className="ml-5" onClick={handleUploadCoverImage}>
                <Upload className="h-4 w-4 mr-2" />
                Change Cover
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg mt-6">
        <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700">
          <h2 className="text-lg font-medium text-slate-900 dark:text-white">
            Basic Information
          </h2>
        </div>
        <div className="px-6 py-5 space-y-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="display-name">Display Name</Label>
              <Input 
                id="display-name" 
                value={displayName} 
                onChange={(e) => setDisplayName(e.target.value)}
                className="mt-1.5"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="title">Professional Title</Label>
            <Input 
              id="title" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Survey Design Specialist" 
              className="mt-1.5"
            />
          </div>
          
          <div>
            <Label htmlFor="bio">Bio</Label>
            <Textarea 
              id="bio" 
              value={bio} 
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell others about yourself..." 
              className="min-h-[120px] mt-1.5"
            />
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {150 - bio.length} characters remaining
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg mt-6">
        <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700">
          <h2 className="text-lg font-medium text-slate-900 dark:text-white">
            Additional Information
          </h2>
        </div>
        <div className="px-6 py-5 space-y-6">
          <div>
            <Label htmlFor="location">Location</Label>
            <div className="flex items-center mt-1.5">
              <MapPin className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
              <Input 
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Add your location"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="website">Website</Label>
            <div className="flex items-center mt-1.5">
              <Link2 className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
              <Input 
                id="website"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="Add your website"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="occupation">Occupation</Label>
            <div className="flex items-center mt-1.5">
              <Briefcase className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
              <Input 
                id="occupation"
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                placeholder="Add your occupation"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProfilePage;