import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { WalletTransaction, User } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Coins, CreditCard, TrendingUp, ArrowUp, ArrowDown, Calendar, Download, Gift, Award, Trophy, Star, Zap } from 'lucide-react';
import { format } from 'date-fns';

const WalletPage = () => {
  const { toast } = useToast();
  const userId = 1; // Using demo user for now
  const [filter, setFilter] = useState('all');
  
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });
  
  const { data: transactions, isLoading } = useQuery<WalletTransaction[]>({
    queryKey: [`/api/users/${userId}/wallet/transactions`],
  });
  
  const calculateBalance = () => {
    if (!transactions) return 0;
    
    return transactions.reduce((total, tx) => {
      return total + (tx.amount || 0);
    }, 0);
  };

  const getFilteredTransactions = () => {
    if (!transactions) return [];
    
    switch (filter) {
      case 'income':
        return transactions.filter(tx => tx.amount > 0);
      case 'expense':
        return transactions.filter(tx => tx.amount < 0);
      default:
        return transactions;
    }
  };
  
  const filteredTransactions = getFilteredTransactions();
  
  const calculateMonthlyEarnings = () => {
    if (!transactions) return [];
    
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    
    // Get last 6 months
    const months = [];
    for (let i = 0; i < 6; i++) {
      const month = (currentMonth - i + 12) % 12;
      const year = currentYear - (currentMonth < i ? 1 : 0);
      months.push({ month, year });
    }
    
    // Calculate earnings for each month
    return months.map(({ month, year }) => {
      const monthName = format(new Date(year, month, 1), 'MMM yyyy');
      const earnings = transactions
        .filter(tx => {
          if (!tx.createdAt) return false;
          const txDate = new Date(tx.createdAt);
          return txDate.getMonth() === month && txDate.getFullYear() === year && tx.amount > 0;
        })
        .reduce((total, tx) => total + tx.amount, 0);
      
      return { month: monthName, earnings };
    }).reverse();
  };
  
  const monthlyEarnings = calculateMonthlyEarnings();
  
  const renderMonthlyEarningsChart = () => {
    const maxEarnings = Math.max(...monthlyEarnings.map(m => m.earnings), 100);
    
    return (
      <div className="mt-4">
        <div className="flex justify-between text-xs text-slate-500 mb-1">
          <div>Revenue</div>
          <div>Last 6 months</div>
        </div>
        <div className="space-y-2">
          {monthlyEarnings.map((data, i) => (
            <div key={i} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span>{data.month}</span>
                <span>{data.earnings.toFixed(2)} Coins</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full" 
                  style={{ width: `${(data.earnings / maxEarnings) * 100}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  const statCards = [
    {
      title: 'Current Balance',
      value: `${calculateBalance().toFixed(2)} Coins`,
      description: 'Available for withdrawal',
      icon: <Coins className="h-5 w-5" />,
      color: 'text-green-500 bg-green-100 dark:bg-green-900/30',
    },
    {
      title: 'Monthly Earnings',
      value: `${monthlyEarnings[0]?.earnings.toFixed(2) || "0.00"} Coins`,
      description: 'This month',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'text-blue-500 bg-blue-100 dark:bg-blue-900/30',
    },
    {
      title: 'Next Payout',
      value: 'Jun 30, 2025',
      description: 'Scheduled date',
      icon: <Calendar className="h-5 w-5" />,
      color: 'text-purple-500 bg-purple-100 dark:bg-purple-900/30',
    },
  ];
  
  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
          </div>
          <div className="h-64 w-full bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
      <div className="pb-5 border-b border-slate-200 dark:border-slate-700 sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Wallet & Transactions</h1>
        <div className="mt-3 sm:mt-0 sm:ml-4 flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              toast({
                title: "Add Card",
                description: "You can now add a new payment method for your wallet.",
              });
            }}
          >
            <CreditCard className="h-5 w-5 mr-2" />
            Add Card
          </Button>
          
          <Button 
            variant="secondary"
            onClick={() => {
              toast({
                title: "Charge Wallet",
                description: "Your wallet has been charged with 100.00 Coins.",
              });
            }}
          >
            <ArrowUp className="h-5 w-5 mr-2" />
            Charge Wallet
          </Button>
          
          <Button 
            onClick={() => {
              toast({
                title: "Withdrawal requested",
                description: `A withdrawal of ${calculateBalance().toFixed(2)} Coins has been requested and will be processed within 1-3 business days.`,
              });
            }}
          >
            <Coins className="h-5 w-5 mr-2" />
            Withdraw Funds
          </Button>
        </div>
      </div>
      
      {/* Stat Cards */}
      <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
        {statCards.map((card, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div className={`p-2 rounded-full ${card.color}`}>
                  {card.icon}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col">
                <CardTitle className="text-2xl font-bold">{card.value}</CardTitle>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    {card.title}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    {card.description}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Tabs Section */}
      <div className="mt-6">
        <Tabs defaultValue="transactions">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="earnings">Earnings Analytics</TabsTrigger>
            <TabsTrigger value="payment-methods">Payment Methods</TabsTrigger>
            <TabsTrigger value="rewards">Rewards</TabsTrigger>
          </TabsList>
          
          <TabsContent value="transactions" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Transaction History</CardTitle>
                  <Select value={filter} onValueChange={setFilter}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Filter" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <CardDescription>Recent wallet activity and payments</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableCaption>A list of your recent transactions.</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions && filteredTransactions.length > 0 ? (
                      filteredTransactions.map((tx) => (
                        <TableRow key={tx.id}>
                          <TableCell className="font-medium">{tx.description}</TableCell>
                          <TableCell>{tx.createdAt ? format(new Date(tx.createdAt), 'MMM dd, yyyy') : 'N/A'}</TableCell>
                          <TableCell>
                            <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs ${
                              tx.amount > 0 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {tx.amount > 0 ? (
                                <><ArrowUp className="h-3 w-3 mr-1" />Income</>
                              ) : (
                                <><ArrowDown className="h-3 w-3 mr-1" />Expense</>
                              )}
                            </span>
                          </TableCell>
                          <TableCell className={`text-right ${
                            tx.amount > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                          }`}>
                            {tx.amount > 0 ? '+' : ''}{tx.amount.toFixed(2)} Coins
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          No transactions found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="earnings" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Earnings Overview</CardTitle>
                <CardDescription>Your survey and referral earnings over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium mb-4">Monthly Revenue</h3>
                    {renderMonthlyEarningsChart()}
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-4">Earnings by Survey</h3>
                    <div className="rounded-lg border border-slate-200 dark:border-slate-700">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Survey Name</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                            <TableHead className="text-right">Responses</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="font-medium">Customer Feedback Survey</TableCell>
                            <TableCell className="text-right">120.50 Coins</TableCell>
                            <TableCell className="text-right">241</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Product Research</TableCell>
                            <TableCell className="text-right">86.25 Coins</TableCell>
                            <TableCell className="text-right">173</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Market Analysis</TableCell>
                            <TableCell className="text-right">65.75 Coins</TableCell>
                            <TableCell className="text-right">131</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                    
                    <div className="mt-4">
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          toast({
                            title: "Report generated",
                            description: "Earnings report has been generated and downloaded.",
                          });
                        }}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download Earnings Report
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="payment-methods" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Payment Methods</CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      toast({
                        title: "Add Card",
                        description: "You can now add a new payment method for your wallet.",
                      });
                    }}
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Add New Card
                  </Button>
                </div>
                <CardDescription>Manage your payment methods and cards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Card 1 */}
                  <div className="border rounded-lg p-4 bg-gradient-to-r from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-800/20">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-xl font-medium mb-1">•••• •••• •••• 4242</div>
                        <div className="text-sm text-slate-500">Visa ending in 4242</div>
                        <div className="flex items-center mt-2 text-sm text-slate-500">
                          <span>Expires 12/25</span>
                          <span className="mx-2">•</span>
                          <span>Default</span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button variant="ghost" size="sm" className="h-8">
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 text-red-500 hover:text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20">
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Card 2 */}
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-xl font-medium mb-1">•••• •••• •••• 5555</div>
                        <div className="text-sm text-slate-500">Mastercard ending in 5555</div>
                        <div className="flex items-center mt-2 text-sm text-slate-500">
                          <span>Expires 08/26</span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button variant="ghost" size="sm" className="h-8">
                          Set Default
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8">
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 text-red-500 hover:text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20">
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-3">Billing Address</h3>
                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-medium">Saif Ahmed</div>
                          <div className="text-sm text-slate-500 mt-1">
                            123 Main Street<br />
                            Apt 4B<br />
                            New York, NY 10001<br />
                            United States
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="rewards" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Loyalty & Rewards Program</CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      toast({
                        title: "Rewards Refreshed",
                        description: "Your rewards and points have been updated.",
                      });
                    }}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Refresh Points
                  </Button>
                </div>
                <CardDescription>Earn and redeem points through surveys and platform activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* User Status & Points */}
                  <div className="border rounded-lg p-6 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
                    <div className="flex gap-6 flex-col sm:flex-row justify-between">
                      <div className="flex-1">
                        <div className="text-sm text-slate-500 uppercase font-medium">Your Status</div>
                        <div className="flex items-center mt-1">
                          <Award className="h-5 w-5 text-purple-600 mr-2" />
                          <span className="text-xl font-bold text-purple-600">Gold Member</span>
                        </div>
                        <div className="text-sm text-slate-500 mt-2">
                          You're 500 points away from Platinum status
                        </div>
                        <div className="mt-4">
                          <div className="text-sm text-slate-500 flex justify-between mb-1">
                            <span>Progress to Platinum</span>
                            <span>1,500/2,000</span>
                          </div>
                          <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-purple-600 rounded-full" 
                              style={{ width: '75%' }}
                            ></div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="text-sm text-slate-500 uppercase font-medium">Available Points</div>
                        <div className="text-3xl font-bold mt-1">1,500</div>
                        <div className="text-sm text-green-600 mt-1 flex items-center">
                          <ArrowUp className="h-3 w-3 mr-1" /> 
                          <span>Earned 350 points this month</span>
                        </div>
                        <div className="mt-4">
                          <Button 
                            variant="secondary" 
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Reward Redeemed",
                                description: "Your points have been exchanged for a 10 Coins reward.",
                              });
                            }}
                          >
                            <Gift className="h-4 w-4 mr-2" />
                            Redeem Points
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Rewards Categories */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Available Rewards</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between">
                          <div className="p-2 rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                            <Coins className="h-5 w-5" />
                          </div>
                          <div className="text-sm font-medium bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-300 py-1 px-2 rounded-full">
                            500 pts
                          </div>
                        </div>
                        <h4 className="font-medium mt-3">5 Coins Reward</h4>
                        <p className="text-sm text-slate-500 mt-1">Redeem points for Coins deposited to your wallet</p>
                      </div>
                      
                      <div className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between">
                          <div className="p-2 rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                            <Star className="h-5 w-5" />
                          </div>
                          <div className="text-sm font-medium bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-300 py-1 px-2 rounded-full">
                            1000 pts
                          </div>
                        </div>
                        <h4 className="font-medium mt-3">Premium Survey Tools</h4>
                        <p className="text-sm text-slate-500 mt-1">Unlock advanced survey features for 1 month</p>
                      </div>
                      
                      <div className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                        <div className="flex items-start justify-between">
                          <div className="p-2 rounded-full bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400">
                            <Trophy className="h-5 w-5" />
                          </div>
                          <div className="text-sm font-medium bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-300 py-1 px-2 rounded-full">
                            2000 pts
                          </div>
                        </div>
                        <h4 className="font-medium mt-3">Platinum Status</h4>
                        <p className="text-sm text-slate-500 mt-1">Upgrade to Platinum with higher earnings & perks</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Recent Rewards Activity */}
                  <div>
                    <h3 className="text-lg font-medium mb-3">Recent Rewards Activity</h3>
                    <div className="border rounded-lg overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Activity</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead className="text-right">Points</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="font-medium">Completed Market Research Survey</TableCell>
                            <TableCell>{format(new Date(2025, 2, 25), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="text-right text-green-600">+150</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Referred a New User</TableCell>
                            <TableCell>{format(new Date(2025, 2, 20), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="text-right text-green-600">+200</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Redeemed 5 Coins Reward</TableCell>
                            <TableCell>{format(new Date(2025, 2, 15), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="text-right text-red-600">-500</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Created Premium Survey</TableCell>
                            <TableCell>{format(new Date(2025, 2, 10), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="text-right text-green-600">+100</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default WalletPage;