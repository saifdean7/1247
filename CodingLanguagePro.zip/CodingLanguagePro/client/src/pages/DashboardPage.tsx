import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, Survey, Activity } from '@shared/schema';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  BarChartHorizontal, 
  LineChart, 
  PieChart, 
  Users, 
  FileText, 
  Award, 
  TrendingUp, 
  DollarSign,
  MessageSquare,
  Plus
} from 'lucide-react';
import { cn } from '@/lib/utils';
import SocialFeed from '@/components/social/SocialFeed';
import CreateSurveyModal from '@/components/survey/CreateSurveyModal';

const DashboardPage = () => {
  const userId = 1; // Using demo user for now
  const [isCreateSurveyModalOpen, setIsCreateSurveyModalOpen] = useState(false);
  
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });
  
  const { data: activities } = useQuery<Activity[]>({
    queryKey: [`/api/users/${userId}/activities`],
  });
  
  const { data: surveys } = useQuery<Survey[]>({
    queryKey: [`/api/users/${userId}/surveys`],
  });
  
  // Stat cards data
  const statCards = [
    {
      title: 'Total Surveys',
      value: '38',
      description: '+12% from last month',
      trend: 'up',
      icon: <FileText className="h-5 w-5" />,
      color: 'text-blue-500 bg-blue-100 dark:bg-blue-900/30',
    },
    {
      title: 'Active Surveys',
      value: '12',
      description: '4 ending this week',
      trend: 'neutral',
      icon: <BarChartHorizontal className="h-5 w-5" />,
      color: 'text-green-500 bg-green-100 dark:bg-green-900/30',
    },
    {
      title: 'Total Responses',
      value: '1,257',
      description: '+23% from last month',
      trend: 'up',
      icon: <Users className="h-5 w-5" />,
      color: 'text-purple-500 bg-purple-100 dark:bg-purple-900/30',
    },
    {
      title: 'Average Completion',
      value: '87%',
      description: '3% higher than industry average',
      trend: 'up',
      icon: <PieChart className="h-5 w-5" />,
      color: 'text-orange-500 bg-orange-100 dark:bg-orange-900/30',
    },
  ];
  
  // Earning cards data
  const earningCards = [
    {
      title: 'Total Earnings',
      value: '$389.50',
      description: 'Current balance',
      icon: <DollarSign className="h-5 w-5" />,
      color: 'text-emerald-500 bg-emerald-100 dark:bg-emerald-900/30',
    },
    {
      title: 'Monthly Trend',
      value: '+$126.40',
      description: 'This month',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'text-cyan-500 bg-cyan-100 dark:bg-cyan-900/30',
    },
    {
      title: 'Achievements',
      value: '8/15',
      description: '3 new this month',
      icon: <Award className="h-5 w-5" />,
      color: 'text-pink-500 bg-pink-100 dark:bg-pink-900/30',
    },
  ];
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
      <div className="pb-5 border-b border-slate-200 dark:border-slate-700 sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
        <div className="mt-3 sm:mt-0 sm:ml-4">
          <Button 
            onClick={() => setIsCreateSurveyModalOpen(true)}
            className="flex items-center"
          >
            <Plus className="h-4 w-4 mr-1" />
            Create New Survey
          </Button>
        </div>
      </div>
      
      <CreateSurveyModal 
        isOpen={isCreateSurveyModalOpen} 
        onClose={() => setIsCreateSurveyModalOpen(false)} 
        userId={userId} 
      />
      
      {/* Welcome Card */}
      <div className="mt-6 bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
        <div className="p-6">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            Welcome back, {user?.displayName || 'User'}
          </h2>
          <p className="mt-1 text-slate-500 dark:text-slate-400">
            Here's what's happening with your surveys and statistics.
          </p>
        </div>
      </div>
      
      {/* Stats Grid */}
      <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-4">
        {statCards.map((card, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div 
                  className={cn(
                    "p-2 rounded-full", 
                    card.color
                  )}
                >
                  {card.icon}
                </div>
                <CardDescription>
                  {card.description}
                  {card.trend === 'up' && (
                    <span className="ml-1 text-green-500">↑</span>
                  )}
                  {card.trend === 'down' && (
                    <span className="ml-1 text-red-500">↓</span>
                  )}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline">
                <CardTitle className="text-2xl font-bold">{card.value}</CardTitle>
                <span className="ml-2 text-sm text-slate-500 dark:text-slate-400">
                  {card.title}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Middle Section - Charts */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle>Survey Responses Over Time</CardTitle>
            <CardDescription>Weekly response rates for your active surveys</CardDescription>
          </CardHeader>
          <CardContent className="h-80 flex items-center justify-center">
            <LineChart className="h-12 w-12 text-slate-400" />
            <span className="ml-2 text-slate-500 dark:text-slate-400">
              Chart visualization will appear here
            </span>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Response Demographics</CardTitle>
            <CardDescription>Age and location breakdown</CardDescription>
          </CardHeader>
          <CardContent className="h-64 flex items-center justify-center">
            <PieChart className="h-12 w-12 text-slate-400" />
            <span className="ml-2 text-slate-500 dark:text-slate-400">
              Demographics chart will appear here
            </span>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Survey Performance</CardTitle>
            <CardDescription>Completion rates by survey</CardDescription>
          </CardHeader>
          <CardContent className="h-64 flex items-center justify-center">
            <BarChart className="h-12 w-12 text-slate-400" />
            <span className="ml-2 text-slate-500 dark:text-slate-400">
              Performance chart will appear here
            </span>
          </CardContent>
        </Card>
      </div>
      
      {/* Bottom Row */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SocialFeed userId={userId} />
        </div>
        
        <div className="space-y-6">
          {earningCards.map((card, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <div 
                    className={cn(
                      "p-2 rounded-full", 
                      card.color
                    )}
                  >
                    {card.icon}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <CardTitle className="text-2xl font-bold">{card.value}</CardTitle>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      {card.title}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {card.description}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
