import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Survey, User } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  PieChart, 
  LineChart, 
  Download, 
  Users, 
  Filter,
  FileText,
  MapPin,
  Clock,
  CheckCircle
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

const AnalyticsPage = () => {
  const { toast } = useToast();
  const userId = 1; // Using demo user for now
  const [selectedSurvey, setSelectedSurvey] = useState<string>('');
  
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });
  
  const { data: surveys, isLoading } = useQuery<Survey[]>({
    queryKey: [`/api/users/${userId}/surveys`],
  });
  
  const selectedSurveyData = surveys?.find(survey => survey.id.toString() === selectedSurvey);

  // Sample response data (normally would be fetched from the backend)
  const sampleResponses = {
    total: 324,
    completion: 87, // percentage
    averageTime: '4m 12s',
    demographics: {
      age: [
        { group: '18-24', count: 54 },
        { group: '25-34', count: 128 },
        { group: '35-44', count: 86 },
        { group: '45-54', count: 42 },
        { group: '55+', count: 14 },
      ],
      gender: [
        { group: 'Male', count: 162 },
        { group: 'Female', count: 147 },
        { group: 'Non-binary', count: 12 },
        { group: 'Prefer not to say', count: 3 },
      ],
      location: [
        { group: 'North America', count: 156 },
        { group: 'Europe', count: 98 },
        { group: 'Asia', count: 52 },
        { group: 'Other', count: 18 },
      ]
    },
    questions: [
      {
        id: 1,
        question: 'How satisfied are you with our service?',
        type: 'rating',
        answers: [
          { answer: '1', count: 12 },
          { answer: '2', count: 18 },
          { answer: '3', count: 45 },
          { answer: '4', count: 126 },
          { answer: '5', count: 123 },
        ]
      },
      {
        id: 2,
        question: 'What features do you use most often?',
        type: 'multiple_choice',
        answers: [
          { answer: 'Survey Creation', count: 187 },
          { answer: 'Analytics Dashboard', count: 142 },
          { answer: 'Response Collection', count: 165 },
          { answer: 'User Management', count: 89 },
          { answer: 'Reporting Tools', count: 104 },
        ]
      },
      {
        id: 3,
        question: 'How likely are you to recommend our platform?',
        type: 'rating',
        answers: [
          { answer: 'Very Unlikely', count: 24 },
          { answer: 'Unlikely', count: 35 },
          { answer: 'Neutral', count: 67 },
          { answer: 'Likely', count: 98 },
          { answer: 'Very Likely', count: 100 },
        ]
      }
    ],
    responseOverTime: [
      { date: '2025-03-01', count: 23 },
      { date: '2025-03-08', count: 42 },
      { date: '2025-03-15', count: 65 },
      { date: '2025-03-22', count: 87 },
      { date: '2025-03-29', count: 107 },
    ]
  };

  const calculatePercentage = (count: number, total: number) => {
    return Math.round((count / total) * 100);
  };

  const renderDemographicsPieChart = (data: { group: string, count: number }[], title: string) => {
    const total = data.reduce((acc, item) => acc + item.count, 0);
    
    return (
      <div className="space-y-4">
        <h3 className="text-sm font-medium">{title}</h3>
        {data.map((item, i) => {
          const percentage = calculatePercentage(item.count, total);
          return (
            <div key={i} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>{item.group}</span>
                <span>{percentage}%</span>
              </div>
              <Progress value={percentage} className="h-2" />
            </div>
          )
        })}
      </div>
    );
  };

  const renderQuestionResults = (question: any) => {
    const total = question.answers.reduce((acc: number, answer: any) => acc + answer.count, 0);
    
    return (
      <Card key={question.id} className="mb-4">
        <CardHeader>
          <CardTitle className="text-lg">{question.question}</CardTitle>
          <CardDescription>Question {question.id} • {question.type}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {question.answers.map((answer: any, i: number) => {
              const percentage = calculatePercentage(answer.count, total);
              return (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>{answer.answer}</span>
                    <span>{answer.count} responses ({percentage}%)</span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
          </div>
          <div className="h-64 w-full bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
      <div className="pb-5 border-b border-slate-200 dark:border-slate-700 sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Survey Analytics</h1>
        <div className="mt-3 sm:mt-0 sm:ml-4">
          <Button variant="outline">
            <Filter className="h-5 w-5 mr-2" />
            Advanced Filters
          </Button>
        </div>
      </div>
      
      {/* Survey Selector */}
      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Select Survey to Analyze</CardTitle>
            <CardDescription>View detailed analytics and download reports</CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={selectedSurvey} onValueChange={setSelectedSurvey}>
              <SelectTrigger className="w-full md:w-1/2">
                <SelectValue placeholder="Choose a survey" />
              </SelectTrigger>
              <SelectContent>
                {surveys && surveys.length > 0 ? (
                  surveys.map((survey) => (
                    <SelectItem key={survey.id} value={survey.id.toString()}>
                      {survey.title}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="demo" disabled>
                    No surveys available
                  </SelectItem>
                )}
                {/* Add demo survey for display purposes */}
                <SelectItem value="demo">
                  Customer Satisfaction Survey
                </SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>
      
      {/* Analytics Dashboard - Only show when a survey is selected */}
      {(selectedSurvey || selectedSurvey === 'demo') && (
        <div className="mt-6">
          {/* Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="p-2 rounded-full text-blue-500 bg-blue-100 dark:bg-blue-900/30 w-fit">
                  <Users className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <CardTitle className="text-2xl font-bold">{sampleResponses.total}</CardTitle>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    Total Responses
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="p-2 rounded-full text-green-500 bg-green-100 dark:bg-green-900/30 w-fit">
                  <CheckCircle className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <CardTitle className="text-2xl font-bold">{sampleResponses.completion}%</CardTitle>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    Completion Rate
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="p-2 rounded-full text-purple-500 bg-purple-100 dark:bg-purple-900/30 w-fit">
                  <Clock className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <CardTitle className="text-2xl font-bold">{sampleResponses.averageTime}</CardTitle>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    Average Time
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="p-2 rounded-full text-orange-500 bg-orange-100 dark:bg-orange-900/30 w-fit">
                  <MapPin className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col">
                  <CardTitle className="text-2xl font-bold">16</CardTitle>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    Countries
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Tabs for different reports */}
          <div className="mt-6">
            <Tabs defaultValue="summary">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="demographics">Demographics</TabsTrigger>
                <TabsTrigger value="questions">Questions</TabsTrigger>
                <TabsTrigger value="trends">Trends</TabsTrigger>
              </TabsList>
              
              {/* Summary Tab */}
              <TabsContent value="summary" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Survey Performance Overview</CardTitle>
                    <CardDescription>
                      {selectedSurveyData?.title || "Customer Satisfaction Survey"} • Created on {format(new Date(), 'MMMM dd, yyyy')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      <div>
                        <h3 className="text-sm font-medium mb-4">Response Rate Over Time</h3>
                        <div className="flex items-center justify-center h-64 border rounded-lg border-slate-200 dark:border-slate-700">
                          <LineChart className="h-12 w-12 text-slate-400 mr-2" />
                          <span className="text-slate-500">Response trends visualization</span>
                        </div>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium mb-4">Top Level Insights</h3>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span>Overall Satisfaction:</span>
                            <span className="font-medium">4.2/5.0</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span>NPS Score:</span>
                            <span className="font-medium">42</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span>Recommend Rate:</span>
                            <span className="font-medium">78%</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span>Top Feature:</span>
                            <span className="font-medium">Survey Creation</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span>Most Common Feedback:</span>
                            <span className="font-medium">Positive</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button 
                      variant="outline"
                      onClick={() => {
                        toast({
                          title: "Report generated",
                          description: "A comprehensive report is being generated and will be emailed to you.",
                        });
                      }}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Generate Report
                    </Button>
                    <Button
                      onClick={() => {
                        toast({
                          title: "Data downloaded",
                          description: "Survey data has been prepared and downloaded as CSV.",
                        });
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Data
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              {/* Demographics Tab */}
              <TabsContent value="demographics" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Respondent Demographics</CardTitle>
                    <CardDescription>Breakdown of survey participants</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div>
                        {renderDemographicsPieChart(sampleResponses.demographics.age, 'Age Distribution')}
                      </div>
                      <div>
                        {renderDemographicsPieChart(sampleResponses.demographics.gender, 'Gender Distribution')}
                      </div>
                      <div>
                        {renderDemographicsPieChart(sampleResponses.demographics.location, 'Geographic Distribution')}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button
                      onClick={() => {
                        toast({
                          title: "Demographics data downloaded",
                          description: "Demographics data has been prepared and downloaded as CSV.",
                        });
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Demographics
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              {/* Questions Tab */}
              <TabsContent value="questions" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Question Analysis</CardTitle>
                    <CardDescription>Detailed breakdown of responses by question</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {sampleResponses.questions.map((question) => renderQuestionResults(question))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button
                      onClick={() => {
                        toast({
                          title: "Question data downloaded",
                          description: "Question analysis data has been prepared and downloaded as CSV.",
                        });
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Question Data
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              {/* Trends Tab */}
              <TabsContent value="trends" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Response Trends</CardTitle>
                    <CardDescription>Temporal analysis and response patterns</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      <div>
                        <h3 className="text-sm font-medium mb-4">Weekly Response Volume</h3>
                        <div className="flex items-center justify-center h-64 border rounded-lg border-slate-200 dark:border-slate-700">
                          <BarChart className="h-12 w-12 text-slate-400 mr-2" />
                          <span className="text-slate-500">Weekly trends visualization</span>
                        </div>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium mb-4">Daily Response Distribution</h3>
                        <div className="flex items-center justify-center h-64 border rounded-lg border-slate-200 dark:border-slate-700">
                          <PieChart className="h-12 w-12 text-slate-400 mr-2" />
                          <span className="text-slate-500">Daily distribution visualization</span>
                        </div>
                      </div>
                    </div>
                    
                    <Separator className="my-6" />
                    
                    <div>
                      <h3 className="text-sm font-medium mb-4">Response Time Trends</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span>Weekdays</span>
                          <span>3m 45s average</span>
                        </div>
                        <Progress value={75} className="h-2" />
                        
                        <div className="flex justify-between">
                          <span>Weekends</span>
                          <span>5m 10s average</span>
                        </div>
                        <Progress value={100} className="h-2" />
                        
                        <div className="flex justify-between">
                          <span>Morning (6am-12pm)</span>
                          <span>4m 22s average</span>
                        </div>
                        <Progress value={85} className="h-2" />
                        
                        <div className="flex justify-between">
                          <span>Afternoon (12pm-6pm)</span>
                          <span>3m 58s average</span>
                        </div>
                        <Progress value={78} className="h-2" />
                        
                        <div className="flex justify-between">
                          <span>Evening (6pm-12am)</span>
                          <span>4m 45s average</span>
                        </div>
                        <Progress value={92} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button
                      onClick={() => {
                        toast({
                          title: "Trend analysis downloaded",
                          description: "Survey trend analysis report has been prepared and downloaded as PDF.",
                        });
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Trend Analysis
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalyticsPage;