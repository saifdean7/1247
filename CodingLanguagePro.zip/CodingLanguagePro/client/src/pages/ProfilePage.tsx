import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { User } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import ProfileHeader from '@/components/profile/ProfileHeader';
import ProfileBio from '@/components/profile/ProfileBio';
import ActivityTimeline from '@/components/profile/ActivityTimeline';
import SurveyPortfolio from '@/components/profile/SurveyPortfolio';
import AchievementGallery from '@/components/profile/AchievementGallery';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Grid, BarChart2, Award, Activity, Users } from 'lucide-react';

const ProfilePage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = 1; // Using demo user for now
  
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data: Partial<User>) => {
      const res = await apiRequest('PATCH', `/api/users/${userId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const handleUpdateUser = (data: Partial<User>) => {
    updateUserMutation.mutate(data);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="animate-pulse space-y-6">
          <div className="h-64 w-full bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
          <div className="h-48 w-full bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
          <div className="h-64 w-full bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !user) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="bg-red-50 dark:bg-red-900/30 p-4 rounded-md">
          <h3 className="text-red-800 dark:text-red-300 font-medium">Error loading profile</h3>
          <p className="text-red-700 dark:text-red-400 mt-2">{error instanceof Error ? error.message : 'Unknown error'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">      
      {/* Instagram-style Profile Header and Bio */}
      <div className="mb-6">
        <ProfileHeader user={user} onUpdateUser={handleUpdateUser} />
        <ProfileBio user={user} onUpdateUser={handleUpdateUser} />
      </div>
      
      {/* Instagram-style Tabs for Content */}
      <Tabs defaultValue="surveys" className="w-full mb-6">
        <TabsList className="w-full grid grid-cols-5 mb-8">
          <TabsTrigger value="surveys" className="flex items-center gap-1.5">
            <Grid className="h-4 w-4" />
            <span className="hidden sm:inline">Surveys</span>
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-1.5">
            <Activity className="h-4 w-4" />
            <span className="hidden sm:inline">Activity</span>
          </TabsTrigger>
          <TabsTrigger value="achievements" asChild>
            <a href="/profile/achievements" className="flex items-center gap-1.5 justify-center">
              <Award className="h-4 w-4" />
              <span className="hidden sm:inline">Achievements</span>
            </a>
          </TabsTrigger>
          <TabsTrigger value="analytics" asChild>
            <a href="/profile/analytics" className="flex items-center gap-1.5 justify-center">
              <BarChart2 className="h-4 w-4" />
              <span className="hidden sm:inline">Analytics</span>
            </a>
          </TabsTrigger>
          <TabsTrigger value="connections" asChild>
            <a href="/profile/connections" className="flex items-center gap-1.5 justify-center">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Connections</span>
            </a>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="surveys" className="mt-0">
          <SurveyPortfolio userId={user.id} />
        </TabsContent>
        
        <TabsContent value="activity" className="mt-0">
          <ActivityTimeline userId={user.id} />
        </TabsContent>
        
        <TabsContent value="achievements" className="mt-0">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">Recent Achievements</h3>
            <Button variant="outline" size="sm" asChild>
              <a href="/profile/achievements">View All Achievements</a>
            </Button>
          </div>
          <AchievementGallery userId={user.id} />
        </TabsContent>
        
        <TabsContent value="analytics" className="mt-0">
          <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
            <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
              <div>
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">Survey Analytics</h3>
                <p className="mt-1 max-w-2xl text-sm text-slate-500 dark:text-slate-400">
                  View detailed analytics about your surveys.
                </p>
              </div>
              <Button asChild>
                <a href="/profile/analytics">View Full Analytics</a>
              </Button>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="connections" className="mt-0">
          <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
            <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
              <div>
                <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">Connections</h3>
                <p className="mt-1 max-w-2xl text-sm text-slate-500 dark:text-slate-400">
                  View your followers and people you follow.
                </p>
              </div>
              <Button asChild>
                <a href="/profile/connections">View All Connections</a>
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfilePage;
