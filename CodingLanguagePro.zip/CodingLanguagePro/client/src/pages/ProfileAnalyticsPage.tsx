import { useState } from 'react';
import { Survey, User } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, BarChart2, FileDown, Users, Clock, LineChart, PieChart, Zap, TrendingUp, Eye } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Random data for the demo charts
const generateRandomData = (points: number, min: number, max: number) => {
  return Array.from({ length: points }, () => Math.floor(Math.random() * (max - min + 1) + min));
};

const ProfileAnalyticsPage = () => {
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const userId = 1; // Using demo user for now
  const [timeRange, setTimeRange] = useState('month');
  
  // Get user data
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });
  
  // Get surveys data
  const { data: surveys, isLoading } = useQuery<Survey[]>({
    queryKey: [`/api/users/${userId}/surveys`],
  });
  
  // Create demo analytics data
  const analyticsData = {
    totalViews: 1546,
    totalResponses: 867,
    avgCompletionRate: 86,
    responseOverTime: generateRandomData(7, 10, 50),
    categories: ['Product Feedback', 'Customer Satisfaction', 'Market Research', 'UX Research'],
    categoryDistribution: generateRandomData(4, 10, 40),
    completionRates: [
      { survey: 'Product Satisfaction', rate: 92 },
      { survey: 'Website Usability', rate: 78 },
      { survey: 'Feature Feedback', rate: 85 },
      { survey: 'Market Research', rate: 91 },
    ],
    viewsByDevice: [
      { device: 'Mobile', count: 821 },
      { device: 'Desktop', count: 612 },
      { device: 'Tablet', count: 113 },
    ],
    responsesByDemographics: {
      age: [
        { group: '18-24', count: 142 },
        { group: '25-34', count: 354 },
        { group: '35-44', count: 239 },
        { group: '45-54', count: 97 },
        { group: '55+', count: 35 },
      ],
      gender: [
        { group: 'Male', count: 421 },
        { group: 'Female', count: 446 },
      ],
      location: [
        { region: 'North America', count: 486 },
        { region: 'Europe', count: 213 },
        { region: 'Asia', count: 98 },
        { region: 'Others', count: 70 },
      ]
    },
  };
  
  // Function to handle data download
  const handleDownloadData = (dataType: string) => {
    toast({
      title: "Download Started",
      description: `${dataType} data is being downloaded.`,
    });
    
    // In a real app, this would trigger an actual data download
    setTimeout(() => {
      toast({
        title: "Download Complete",
        description: `${dataType} has been downloaded successfully.`,
      });
    }, 1500);
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => navigate('/profile')} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            Profile Analytics
          </h1>
        </div>
        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Last 7 days</SelectItem>
              <SelectItem value="month">Last 30 days</SelectItem>
              <SelectItem value="quarter">Last 90 days</SelectItem>
              <SelectItem value="year">Last year</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => handleDownloadData('Analytics')}>
            <FileDown className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Total Surveys
                </p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                  {surveys?.length || 38}
                </h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                <BarChart2 className="h-5 w-5 text-primary-600 dark:text-primary-400" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600 dark:text-green-400 flex items-center">
              <TrendingUp className="h-3.5 w-3.5 mr-1" />
              <span>+12.3% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Total Survey Views
                </p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                  {analyticsData.totalViews.toLocaleString()}
                </h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                <Eye className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600 dark:text-green-400 flex items-center">
              <TrendingUp className="h-3.5 w-3.5 mr-1" />
              <span>+18.7% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Total Responses
                </p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                  {analyticsData.totalResponses.toLocaleString()}
                </h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                <Users className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600 dark:text-green-400 flex items-center">
              <TrendingUp className="h-3.5 w-3.5 mr-1" />
              <span>+8.4% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                  Avg. Completion Rate
                </p>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                  {analyticsData.avgCompletionRate}%
                </h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                <Zap className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600 dark:text-green-400 flex items-center">
              <TrendingUp className="h-3.5 w-3.5 mr-1" />
              <span>+2.1% from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Analytics Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="w-full max-w-md mx-auto grid grid-cols-3 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="responses">Responses</TabsTrigger>
          <TabsTrigger value="demographics">Demographics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="mt-0">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Survey Responses Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <LineChart className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Response trend graph would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows daily response volume over the selected time period
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Survey Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <PieChart className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Category distribution chart would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows breakdown of surveys by category
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Completion Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <BarChart2 className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Completion rate chart would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows completion rates for each survey
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="responses" className="mt-0">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Response Trend Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <LineChart className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Response trend graph would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows daily response volume over the selected time period
                    </p>
                    <Button variant="outline" size="sm" onClick={() => handleDownloadData('Response Trends')}>
                      <FileDown className="h-4 w-4 mr-2" />
                      Download Trend Data
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Device Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <PieChart className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Device distribution chart would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows responses by device type (mobile, desktop, tablet)
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Response Time Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <Clock className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Response time chart would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows average time spent on each survey
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="demographics" className="mt-0">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Age Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <BarChart2 className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Age distribution chart would appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Gender Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <PieChart className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Gender distribution chart would appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Location Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px] bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <BarChart2 className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Geographic distribution chart would appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="md:col-span-2 lg:col-span-3">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Demographic Data Breakdown</CardTitle>
                <Button size="sm" onClick={() => handleDownloadData('Demographics')}>
                  <FileDown className="h-4 w-4 mr-2" />
                  Download Demographics
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700 p-4">
                  <div className="text-center space-y-2">
                    <Users className="h-16 w-16 text-slate-400 mx-auto" />
                    <p>Detailed demographic data table would appear here</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Shows complete breakdown of respondent demographics
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfileAnalyticsPage;