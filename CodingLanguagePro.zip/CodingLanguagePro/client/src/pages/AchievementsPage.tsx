import { useState } from 'react';
import { Achievement } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, Award, Calendar, Share2, Unlock, Trophy, Star, Target, BarChart2, Users, Gift } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';

const AchievementsPage = () => {
  const [_, navigate] = useLocation();
  const userId = 1; // Using demo user for now
  
  // Get achievements data
  const { data: achievements, isLoading } = useQuery<Achievement[]>({
    queryKey: [`/api/users/${userId}/achievements`],
  });
  
  // Create demo achievements if none exist
  const demoAchievements: Partial<Achievement>[] = [
    {
      id: 1,
      userId: 1,
      type: "survey_creator",
      name: "Survey Creator", 
      description: "Create your first survey",
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
      iconType: "clipboard",
      unlockedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    },
    {
      id: 2,
      userId: 1,
      type: "survey_master",
      name: "Survey Master", 
      description: "Create 10 surveys",
      progress: 3,
      maxProgress: 10,
      isCompleted: false,
      iconType: "star",
      unlockedAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000)
    },
    {
      id: 3,
      userId: 1,
      type: "response_collector",
      name: "Response Collector", 
      description: "Collect 100 survey responses",
      progress: 78,
      maxProgress: 100,
      isCompleted: false,
      iconType: "chart",
      unlockedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
    },
    {
      id: 4,
      userId: 1,
      type: "verified_creator",
      name: "Verified Creator", 
      description: "Become a verified creator on the platform",
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
      iconType: "badge",
      unlockedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
    },
    {
      id: 5,
      userId: 1,
      type: "network_builder",
      name: "Network Builder", 
      description: "Get 10 followers",
      progress: 1,
      maxProgress: 10,
      isCompleted: false,
      iconType: "users",
      unlockedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
    },
    {
      id: 6,
      userId: 1,
      type: "survey_pro",
      name: "Survey Pro", 
      description: "Upgrade to Pro tier",
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
      iconType: "crown",
      unlockedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
    }
  ];
  
  // Display real data if available, otherwise use demo data
  const displayAchievements = achievements?.length ? achievements : demoAchievements;
  
  // Sort achievements - completed first, then by unlock date
  const sortedAchievements = [...displayAchievements].sort((a, b) => {
    if (a.isCompleted && !b.isCompleted) return -1;
    if (!a.isCompleted && b.isCompleted) return 1;
    
    // Sort by unlock date (newest first) if completion status is the same
    if (a.unlockedAt && b.unlockedAt) {
      return new Date(b.unlockedAt).getTime() - new Date(a.unlockedAt).getTime();
    }
    return 0;
  });
  
  // Count completed achievements
  const completedCount = displayAchievements.filter(a => a.isCompleted).length;
  const totalCount = displayAchievements.length;
  
  // Get icon based on achievement type
  const getAchievementIcon = (achievement: Partial<Achievement>) => {
    switch (achievement.iconType) {
      case 'clipboard':
        return <Award className="h-8 w-8 text-purple-500" />;
      case 'star':
        return <Star className="h-8 w-8 text-yellow-500" />;
      case 'chart':
        return <BarChart2 className="h-8 w-8 text-blue-500" />;
      case 'badge':
        return <Trophy className="h-8 w-8 text-green-500" />;
      case 'users':
        return <Users className="h-8 w-8 text-indigo-500" />;
      case 'crown':
        return <Gift className="h-8 w-8 text-amber-500" />;
      default:
        return <Target className="h-8 w-8 text-primary-500" />;
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => navigate('/profile')} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Achievements</h1>
        </div>
        <Button variant="outline" size="sm">
          <Share2 className="h-4 w-4 mr-2" />
          Share Achievements
        </Button>
      </div>
      
      <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg mb-6">
        <div className="px-6 py-5 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium text-slate-900 dark:text-white">
              Your Achievement Progress
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              You've completed {completedCount} out of {totalCount} achievements
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-16 w-16 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
              <Trophy className="h-8 w-8 text-primary-600 dark:text-primary-400" />
            </div>
            <div className="text-center">
              <span className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                {Math.round((completedCount / totalCount) * 100)}%
              </span>
              <span className="block text-sm text-slate-500 dark:text-slate-400">
                Completed
              </span>
            </div>
          </div>
        </div>
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-700">
          <Progress value={(completedCount / totalCount) * 100} className="h-2" />
        </div>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="overflow-hidden">
              <CardHeader className="p-5 pb-0">
                <div className="flex items-center justify-between mb-4">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <Skeleton className="h-5 w-40 mb-2" />
                <Skeleton className="h-4 w-full" />
              </CardHeader>
              <CardFooter className="px-5 py-3 border-t flex justify-between items-center">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-20" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {sortedAchievements.map(achievement => (
            <Card key={achievement.id} className={`overflow-hidden ${achievement.isCompleted ? 'border-primary-200 dark:border-primary-800' : ''}`}>
              <CardHeader className="p-5 pb-4">
                <div className="flex items-center justify-between mb-4">
                  {getAchievementIcon(achievement)}
                  <Badge className={achievement.isCompleted ? 
                    'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 
                    'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                  }>
                    {achievement.isCompleted ? 'Completed' : 'In Progress'}
                  </Badge>
                </div>
                <CardTitle className="text-base">{achievement.name}</CardTitle>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5">
                  {achievement.description}
                </p>
              </CardHeader>
              
              {!achievement.isCompleted && achievement.progress !== null && achievement.maxProgress !== null && (
                <CardContent className="px-5 pb-3 pt-0">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                    <span>Progress</span>
                    <span>{achievement.progress} / {achievement.maxProgress}</span>
                  </div>
                  <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-1.5" />
                </CardContent>
              )}
              
              <CardFooter className="px-5 py-3 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center">
                <div className="flex items-center text-xs text-slate-500 dark:text-slate-400">
                  <Unlock className="h-3.5 w-3.5 mr-1.5" />
                  Unlocked {format(new Date(achievement.unlockedAt!), 'MMM d, yyyy')}
                </div>
                <Button variant="ghost" size="sm" className="h-7 px-2">
                  <Share2 className="h-3.5 w-3.5" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default AchievementsPage;