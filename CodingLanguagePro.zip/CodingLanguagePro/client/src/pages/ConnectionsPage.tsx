import { useState } from 'react';
import { User } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, UserPlus, Check, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

const ConnectionsPage = () => {
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const queryClient = useQueryClient();
  const userId = 1; // Using demo user for now
  const [searchQuery, setSearchQuery] = useState('');
  
  // Get user data
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });
  
  // Get followers list
  const { data: followers, isLoading: isLoadingFollowers } = useQuery<User[]>({
    queryKey: [`/api/users/${userId}/followers`],
  });
  
  // Get following list
  const { data: following, isLoading: isLoadingFollowing } = useQuery<User[]>({
    queryKey: [`/api/users/${userId}/following`],
  });
  
  // Create demo followers if none exist
  const demoFollowers: Partial<User>[] = [
    {
      id: 2,
      username: "alex",
      displayName: "Alex Rodriguez",
      profileImageUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      title: "Market Research Analyst",
      tier: "Pro",
      isVerified: true
    }
  ];
  
  // Create demo following if none exist
  const demoFollowing: Partial<User>[] = [
    {
      id: 3,
      username: "maya",
      displayName: "Maya Chen",
      profileImageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      title: "UX Researcher",
      tier: "Elite",
      isVerified: true
    },
    {
      id: 4,
      username: "carlos",
      displayName: "Carlos Diaz",
      profileImageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      title: "Product Manager",
      tier: "Pro",
      isVerified: false
    }
  ];
  
  // Display real data if available, otherwise use demo data
  const displayFollowers = followers?.length ? followers : demoFollowers;
  const displayFollowing = following?.length ? following : demoFollowing;
  
  // Filter users based on search query
  const filteredFollowers = displayFollowers.filter(user => 
    user.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    user.username?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredFollowing = displayFollowing.filter(user => 
    user.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    user.username?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Follow/unfollow mutation
  const followMutation = useMutation({
    mutationFn: ({ targetUserId, isFollow }: { targetUserId: number, isFollow: boolean }) => {
      if (isFollow) {
        return apiRequest('/api/follows', {
          method: 'POST',
          body: JSON.stringify({
            followerId: userId,
            followingId: targetUserId
          }),
        });
      } else {
        return apiRequest(`/api/follows?followerId=${userId}&followingId=${targetUserId}`, {
          method: 'DELETE'
        });
      }
    },
    onSuccess: (_, variables) => {
      const { targetUserId, isFollow } = variables;
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/following`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/followers`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/following/count`] });
      
      toast({
        title: isFollow ? "Following" : "Unfollowed",
        description: isFollow ? 
          `You are now following this user` : 
          `You are no longer following this user`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update follow status: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleFollowToggle = (targetUserId: number, isFollowing: boolean) => {
    followMutation.mutate({ targetUserId, isFollow: !isFollowing });
  };
  
  // Check if a user is being followed by the current user
  const isFollowingUser = (targetUserId: number) => {
    return displayFollowing.some(user => user.id === targetUserId);
  };

  // User list item component
  const UserListItem = ({ user }: { user: Partial<User> }) => {
    const isFollowed = isFollowingUser(user.id!);
    
    return (
      <div className="flex items-center justify-between py-4 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center">
          <div className="h-12 w-12 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-700">
            <img 
              src={user.profileImageUrl || "https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"} 
              alt={user.displayName || user.username} 
              className="h-full w-full object-cover" 
            />
          </div>
          <div className="ml-4">
            <div className="flex items-center">
              <h3 className="text-sm font-medium text-slate-900 dark:text-white">
                {user.displayName || user.username}
              </h3>
              {user.isVerified && (
                <Badge className="ml-2 bg-blue-500 text-white scale-75">
                  <Check className="h-3 w-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              @{user.username}
              {user.title && <span className="ml-2">• {user.title}</span>}
            </p>
          </div>
        </div>
        <Button 
          variant={isFollowed ? "outline" : "default"}
          size="sm"
          onClick={() => handleFollowToggle(user.id!, isFollowed)}
          disabled={user.id === userId} // Can't follow yourself
        >
          {isFollowed ? (
            <>
              <Check className="h-4 w-4 mr-1" />
              Following
            </>
          ) : (
            <>
              <UserPlus className="h-4 w-4 mr-1" />
              Follow
            </>
          )}
        </Button>
      </div>
    );
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => navigate('/profile')} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Connections</h1>
        </div>
      </div>
      
      <div className="bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search connections..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        
        <Tabs defaultValue="followers" className="w-full">
          <TabsList className="w-full grid grid-cols-2 rounded-none border-b border-slate-200 dark:border-slate-700 px-4">
            <TabsTrigger value="followers" className="data-[state=active]:bg-transparent">
              Followers ({displayFollowers.length})
            </TabsTrigger>
            <TabsTrigger value="following" className="data-[state=active]:bg-transparent">
              Following ({displayFollowing.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="followers" className="p-4 pt-0">
            {isLoadingFollowers ? (
              <div className="space-y-6 py-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2 ml-4">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <Skeleton className="h-9 w-20 ml-auto" />
                  </div>
                ))}
              </div>
            ) : filteredFollowers.length > 0 ? (
              <div>
                {filteredFollowers.map(follower => (
                  <UserListItem key={follower.id} user={follower} />
                ))}
              </div>
            ) : (
              <div className="py-8 text-center">
                <p className="text-slate-500 dark:text-slate-400">
                  {searchQuery ? "No followers found matching your search." : "No followers yet."}
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="following" className="p-4 pt-0">
            {isLoadingFollowing ? (
              <div className="space-y-6 py-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2 ml-4">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <Skeleton className="h-9 w-20 ml-auto" />
                  </div>
                ))}
              </div>
            ) : filteredFollowing.length > 0 ? (
              <div>
                {filteredFollowing.map(followed => (
                  <UserListItem key={followed.id} user={followed} />
                ))}
              </div>
            ) : (
              <div className="py-8 text-center">
                <p className="text-slate-500 dark:text-slate-400">
                  {searchQuery ? "No users found matching your search." : "You're not following anyone yet."}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ConnectionsPage;