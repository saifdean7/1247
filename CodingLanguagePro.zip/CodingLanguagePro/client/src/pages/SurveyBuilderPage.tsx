import SurveyBuilder from '@/components/survey-builder/SurveyBuilder';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

const SurveyBuilderPage = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
      <div className="pb-5 border-b border-slate-200 dark:border-slate-700 sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Survey Builder</h1>
        <div className="mt-3 sm:mt-0 sm:ml-4">
          <Button>
            <Plus className="h-5 w-5 mr-2" />
            Create New Survey
          </Button>
        </div>
      </div>
      
      <SurveyBuilder />
    </div>
  );
};

export default SurveyBuilderPage;
