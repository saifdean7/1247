import { useRef, useEffect } from 'react';

interface DragItem {
  id: string;
  [key: string]: any;
}

interface DragAndDropOptions<T extends DragItem> {
  type: string;
  item: T;
  onDragStart?: () => void;
  onDragEnd?: () => void;
}

export function useDragAndDrop<ElementType extends HTMLElement>({
  type,
  item,
  onDragStart,
  onDragEnd,
}: DragAndDropOptions<DragItem>) {
  const dragRef = useRef<ElementType>(null);
  const isDragging = useRef(false);

  useEffect(() => {
    const element = dragRef.current;
    if (!element) return;

    const handleDragStart = (e: DragEvent) => {
      if (e.dataTransfer) {
        // Set the drag data
        e.dataTransfer.setData('application/json', JSON.stringify({ type, item }));
        e.dataTransfer.effectAllowed = 'move';
        
        // For better UX, we can set a drag image
        if (element instanceof HTMLElement) {
          // Create a ghost image if needed
          // e.dataTransfer.setDragImage(element, 0, 0);
        }
        
        isDragging.current = true;
        if (onDragStart) onDragStart();
      }
    };

    const handleDragEnd = () => {
      isDragging.current = false;
      if (onDragEnd) onDragEnd();
    };

    element.draggable = true;
    element.addEventListener('dragstart', handleDragStart);
    element.addEventListener('dragend', handleDragEnd);

    return () => {
      element.removeEventListener('dragstart', handleDragStart);
      element.removeEventListener('dragend', handleDragEnd);
    };
  }, [type, item, onDragStart, onDragEnd]);

  return {
    dragRef,
    isDragging: isDragging.current,
  };
}
