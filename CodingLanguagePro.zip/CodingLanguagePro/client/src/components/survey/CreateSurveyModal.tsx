import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { QuestionType } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { 
  Loader2, 
  PlusCircle, 
  XCircle, 
  Sparkles, 
  Brain, 
  Lightbulb, 
  LayoutTemplate, 
  Layout, 
  CheckSquare,
  Copy
} from 'lucide-react';

// Form schema
const surveySchema = z.object({
  title: z.string().min(3, {
    message: 'Title must be at least 3 characters',
  }),
  description: z.string().min(10, {
    message: 'Description must be at least 10 characters',
  }),
  questions: z.array(
    z.object({
      id: z.string(),
      type: z.string(),
      title: z.string().min(3, { message: 'Question title must be at least 3 characters' }),
      required: z.boolean().default(true),
      options: z.array(z.string()).optional(),
    })
  ).min(1, { message: 'Add at least one question' }),
});

type SurveyFormValues = z.infer<typeof surveySchema>;

interface CreateSurveyModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number;
}

const questionTypes: { value: QuestionType; label: string }[] = [
  { value: 'multiple_choice', label: 'Multiple Choice' },
  { value: 'checkbox', label: 'Checkbox (Multiple Answers)' },
  { value: 'text', label: 'Short Answer' },
  { value: 'textarea', label: 'Long Answer' },
  { value: 'rating', label: 'Rating Scale' },
  { value: 'dropdown', label: 'Dropdown' },
];

const CreateSurveyModal = ({ isOpen, onClose, userId }: CreateSurveyModalProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentQuestionType, setCurrentQuestionType] = useState<QuestionType>('multiple_choice');
  const [aiAssistantActive, setAiAssistantActive] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<Array<{title: string, type: QuestionType, options?: string[]}>>([]);
  const [surveyTopic, setSurveyTopic] = useState('');

  // Initialize form
  const form = useForm<SurveyFormValues>({
    resolver: zodResolver(surveySchema),
    defaultValues: {
      title: '',
      description: '',
      questions: [
        {
          id: crypto.randomUUID(),
          type: 'multiple_choice',
          title: '',
          required: true,
          options: ['Option 1', 'Option 2', 'Option 3'],
        },
      ],
    },
  });

  // Survey creation mutation
  const createSurveyMutation = useMutation({
    mutationFn: (data: SurveyFormValues) => {
      return apiRequest('/api/surveys', {
        method: 'POST',
        body: JSON.stringify({
          title: data.title,
          description: data.description,
          questions: data.questions,
          userId: userId,
          status: 'active',
          responseCount: 0,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: 'Survey Created',
        description: 'Your survey has been successfully created.',
      });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/surveys`] });
      form.reset();
      onClose();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to create survey. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Form submission handler
  const onSubmit = (data: SurveyFormValues) => {
    createSurveyMutation.mutate(data);
  };

  // Add a new question
  const addQuestion = () => {
    const currentQuestions = form.getValues('questions');
    const newQuestion = {
      id: crypto.randomUUID(),
      type: currentQuestionType,
      title: '',
      required: true,
    };
    
    // Add options array for question types that need them
    if (['multiple_choice', 'checkbox', 'dropdown'].includes(currentQuestionType)) {
      (newQuestion as any).options = ['Option 1', 'Option 2', 'Option 3'];
    }
    
    form.setValue('questions', [...currentQuestions, newQuestion]);
  };

  // Remove a question
  const removeQuestion = (index: number) => {
    const currentQuestions = form.getValues('questions');
    if (currentQuestions.length <= 1) {
      toast({
        title: 'Error',
        description: 'Survey must have at least one question',
        variant: 'destructive',
      });
      return;
    }
    const updatedQuestions = [...currentQuestions];
    updatedQuestions.splice(index, 1);
    form.setValue('questions', updatedQuestions);
  };

  // Add an option to a multiple choice question
  const addOption = (questionIndex: number) => {
    const currentQuestions = form.getValues('questions');
    const currentOptions = (currentQuestions[questionIndex] as any).options || [];
    const updatedOptions = [...currentOptions, `Option ${currentOptions.length + 1}`];
    
    // Update the specific question's options
    const updatedQuestions = [...currentQuestions];
    (updatedQuestions[questionIndex] as any).options = updatedOptions;
    
    form.setValue('questions', updatedQuestions);
  };

  // Remove an option from a multiple choice question
  const removeOption = (questionIndex: number, optionIndex: number) => {
    const currentQuestions = form.getValues('questions');
    const currentOptions = [...((currentQuestions[questionIndex] as any).options || [])];
    
    if (currentOptions.length <= 2) {
      toast({
        title: 'Error',
        description: 'Question must have at least two options',
        variant: 'destructive',
      });
      return;
    }
    
    currentOptions.splice(optionIndex, 1);
    
    // Update the specific question's options
    const updatedQuestions = [...currentQuestions];
    (updatedQuestions[questionIndex] as any).options = currentOptions;
    
    form.setValue('questions', updatedQuestions);
  };

  // Handle question type change
  const handleQuestionTypeChange = (questionIndex: number, newType: QuestionType) => {
    const currentQuestions = form.getValues('questions');
    const updatedQuestions = [...currentQuestions];
    
    // Update the question type
    updatedQuestions[questionIndex].type = newType;
    
    // Add options if needed for the new type
    if (['multiple_choice', 'checkbox', 'dropdown'].includes(newType) && 
        (!(updatedQuestions[questionIndex] as any).options || (updatedQuestions[questionIndex] as any).options.length === 0)) {
      (updatedQuestions[questionIndex] as any).options = ['Option 1', 'Option 2', 'Option 3'];
    }
    
    form.setValue('questions', updatedQuestions);
  };
  
  // Generate AI suggestions for questions based on survey topic
  const generateAiSuggestions = () => {
    if (!surveyTopic.trim()) {
      toast({
        title: "Survey Topic Required",
        description: "Please enter a survey topic to generate AI suggestions.",
        variant: "destructive"
      });
      return;
    }
    
    setAiLoading(true);
    
    // This is a simulated AI response function
    // In a real implementation, this would call an AI API
    setTimeout(() => {
      const generatedSuggestions = getAiQuestionSuggestions(surveyTopic);
      setAiSuggestions(generatedSuggestions);
      setAiLoading(false);
      
      toast({
        title: "AI Suggestions Generated",
        description: `${generatedSuggestions.length} questions generated for your survey.`,
      });
    }, 1500); // Simulate API delay
  };
  
  // Add a suggested question to the form
  const addSuggestedQuestion = (suggestion: {title: string, type: QuestionType, options?: string[]}) => {
    const currentQuestions = form.getValues('questions');
    const newQuestion = {
      id: crypto.randomUUID(),
      type: suggestion.type,
      title: suggestion.title,
      required: true,
      options: suggestion.options || []
    };
    
    form.setValue('questions', [...currentQuestions, newQuestion]);
    
    toast({
      title: "Question Added",
      description: "AI suggested question has been added to your survey."
    });
  };
  
  // Simulated AI function - in real implementation this would call an AI API
  const getAiQuestionSuggestions = (topic: string): Array<{title: string, type: QuestionType, options?: string[]}> => {
    // These are template suggestions based on common survey topics
    const suggestions = {
      "customer satisfaction": [
        {
          title: "How satisfied are you with our product/service?",
          type: "rating" as QuestionType,
        },
        {
          title: "What aspects of our product/service do you like the most?",
          type: "multiple_choice" as QuestionType,
          options: ["Quality", "Price", "Customer service", "User experience", "Features"]
        },
        {
          title: "How likely are you to recommend our product/service to others?",
          type: "rating" as QuestionType,
        },
        {
          title: "What improvements would you suggest for our product/service?",
          type: "textarea" as QuestionType,
        }
      ],
      "product feedback": [
        {
          title: "Which features do you use most frequently?",
          type: "checkbox" as QuestionType,
          options: ["Feature A", "Feature B", "Feature C", "Feature D", "Feature E"]
        },
        {
          title: "How would you rate the usability of our product?",
          type: "rating" as QuestionType,
        },
        {
          title: "What additional features would you like to see?",
          type: "textarea" as QuestionType,
        },
        {
          title: "How often do you use our product?",
          type: "multiple_choice" as QuestionType,
          options: ["Daily", "Weekly", "Monthly", "Rarely", "This is my first time"]
        }
      ],
      "event feedback": [
        {
          title: "How would you rate the overall event experience?",
          type: "rating" as QuestionType,
        },
        {
          title: "Which sessions did you attend?",
          type: "checkbox" as QuestionType,
          options: ["Session A", "Session B", "Session C", "Networking event", "Workshops"]
        },
        {
          title: "What did you like most about the event?",
          type: "textarea" as QuestionType,
        },
        {
          title: "How did you hear about this event?",
          type: "multiple_choice" as QuestionType,
          options: ["Email", "Social media", "Website", "Friend/Colleague", "Other"]
        }
      ],
      "market research": [
        {
          title: "Which of these competing products have you used?",
          type: "checkbox" as QuestionType,
          options: ["Product A", "Product B", "Product C", "None of the above"]
        },
        {
          title: "What factors influence your purchasing decision the most?",
          type: "multiple_choice" as QuestionType,
          options: ["Price", "Quality", "Brand reputation", "Recommendations", "Features"]
        },
        {
          title: "How much would you be willing to pay for this product/service?",
          type: "multiple_choice" as QuestionType,
          options: ["$0-$50", "$51-$100", "$101-$200", "$201-$500", "More than $500"]
        },
        {
          title: "What problem are you trying to solve with this type of product?",
          type: "textarea" as QuestionType,
        }
      ],
      "employee satisfaction": [
        {
          title: "How satisfied are you with your current role?",
          type: "rating" as QuestionType,
        },
        {
          title: "What aspects of your job do you enjoy the most?",
          type: "multiple_choice" as QuestionType,
          options: ["Work environment", "Colleagues", "Role responsibilities", "Growth opportunities", "Work-life balance"]
        },
        {
          title: "How would you rate the company culture?",
          type: "rating" as QuestionType,
        },
        {
          title: "What suggestions do you have for improving the workplace?",
          type: "textarea" as QuestionType,
        }
      ],
      "default": [
        {
          title: "How would you rate your experience?",
          type: "rating" as QuestionType,
        },
        {
          title: "What do you like most about this topic?",
          type: "multiple_choice" as QuestionType,
          options: ["Option A", "Option B", "Option C", "Option D", "Option E"]
        },
        {
          title: "Please share any additional feedback you have.",
          type: "textarea" as QuestionType,
        },
        {
          title: "How likely are you to engage with this topic again?",
          type: "rating" as QuestionType,
        }
      ]
    };
    
    // Convert topic to lowercase for matching
    const lowerTopic = topic.toLowerCase();
    
    // Find best match from available templates
    let bestMatch = "default";
    for (const key of Object.keys(suggestions)) {
      if (lowerTopic.includes(key)) {
        bestMatch = key;
        break;
      }
    }
    
    // Return matching suggestions
    return suggestions[bestMatch as keyof typeof suggestions];
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Survey</DialogTitle>
          <DialogDescription>
            Design your survey with customizable questions to gather valuable feedback.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="manual" className="w-full mb-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manual">Manual Design</TabsTrigger>
            <TabsTrigger value="ai-assistant" onClick={() => setAiAssistantActive(true)}>
              <Sparkles className="h-4 w-4 mr-2" />
              AI Assistant
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="manual">
            <div className="text-sm text-muted-foreground mb-4">
              Design your survey manually by adding questions and customizing their types.
            </div>
          </TabsContent>
          
          <TabsContent value="ai-assistant">
            <div className="p-4 border rounded-md bg-muted/30 mb-4">
              <h3 className="text-lg font-medium flex items-center mb-4">
                <Brain className="h-5 w-5 mr-2 text-primary" />
                AI Survey Assistant
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="md:col-span-3">
                  <FormItem>
                    <FormLabel>Survey Topic</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g. Customer Satisfaction, Product Feedback, Event Survey..." 
                        value={surveyTopic}
                        onChange={(e) => setSurveyTopic(e.target.value)}
                      />
                    </FormControl>
                    <FormDescription>
                      Describe the topic of your survey to get AI-generated question suggestions.
                    </FormDescription>
                  </FormItem>
                </div>
                
                <div className="flex items-end">
                  <Button 
                    onClick={generateAiSuggestions} 
                    disabled={aiLoading}
                    className="w-full"
                  >
                    {aiLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Lightbulb className="h-4 w-4 mr-2" />
                        Generate
                      </>
                    )}
                  </Button>
                </div>
              </div>
              
              {aiSuggestions.length > 0 && (
                <div className="space-y-3 mt-6">
                  <h4 className="text-sm font-medium flex items-center">
                    <LayoutTemplate className="h-4 w-4 mr-2 text-primary" />
                    Suggested Questions ({aiSuggestions.length})
                  </h4>
                  
                  <div className="max-h-[300px] overflow-y-auto space-y-3 border rounded-md p-2">
                    {aiSuggestions.map((suggestion, index) => (
                      <div 
                        key={index} 
                        className="border rounded-md p-3 bg-background flex justify-between items-start"
                      >
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center">
                            <Badge variant="outline" className="mr-2">
                              {questionTypes.find(t => t.value === suggestion.type)?.label || suggestion.type}
                            </Badge>
                          </div>
                          <p className="text-sm">{suggestion.title}</p>
                          
                          {suggestion.options && suggestion.options.length > 0 && (
                            <div className="mt-2">
                              <div className="text-xs text-muted-foreground">Options:</div>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {suggestion.options.map((option, oidx) => (
                                  <Badge key={oidx} variant="secondary" className="text-xs">
                                    {option}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => addSuggestedQuestion(suggestion)}
                          className="ml-2"
                        >
                          <PlusCircle className="h-4 w-4 text-primary" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Survey Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter survey title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe what your survey is about" 
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Questions</h3>
                  <div className="flex items-center gap-2">
                    <Select 
                      value={currentQuestionType} 
                      onValueChange={(value: QuestionType) => setCurrentQuestionType(value)}
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Question Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {questionTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addQuestion}
                      className="flex items-center"
                    >
                      <PlusCircle className="h-4 w-4 mr-1" />
                      Add Question
                    </Button>
                  </div>
                </div>
                
                {form.getValues('questions').map((question, questionIndex) => (
                  <div key={question.id} className="border p-4 rounded-md">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="font-medium">Question {questionIndex + 1}</h4>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(questionIndex)}
                      >
                        <XCircle className="h-5 w-5 text-red-500" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
                      <div className="md:col-span-2">
                        <FormField
                          control={form.control}
                          name={`questions.${questionIndex}.type`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Question Type</FormLabel>
                              <FormControl>
                                <Select 
                                  value={field.value} 
                                  onValueChange={(value: string) => {
                                    field.onChange(value);
                                    handleQuestionTypeChange(questionIndex, value as QuestionType);
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {questionTypes.map((type) => (
                                      <SelectItem key={type.value} value={type.value}>
                                        {type.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="md:col-span-3">
                        <FormField
                          control={form.control}
                          name={`questions.${questionIndex}.title`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Question Text</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your question" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="md:col-span-5">
                        <FormField
                          control={form.control}
                          name={`questions.${questionIndex}.required`}
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                              <FormControl>
                                <input
                                  type="checkbox"
                                  checked={field.value}
                                  onChange={field.onChange}
                                  className="w-4 h-4 text-primary-600 border-slate-300 rounded focus:ring-primary-500"
                                />
                              </FormControl>
                              <FormLabel className="font-normal">Required question</FormLabel>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    {/* Options for multiple choice, checkbox, and dropdown questions */}
                    {['multiple_choice', 'checkbox', 'dropdown'].includes(form.getValues(`questions.${questionIndex}.type`)) && (
                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between items-center">
                          <FormLabel>Options</FormLabel>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => addOption(questionIndex)}
                          >
                            <PlusCircle className="h-4 w-4 mr-1" />
                            Add Option
                          </Button>
                        </div>
                        
                        {((form.getValues(`questions.${questionIndex}`) as any).options || []).map((option: string, optionIndex: number) => (
                          <div key={optionIndex} className="flex items-center gap-2">
                            <FormField
                              control={form.control}
                              name={`questions.${questionIndex}.options.${optionIndex}`}
                              render={({ field }) => (
                                <FormItem className="flex-grow">
                                  <FormControl>
                                    <Input placeholder={`Option ${optionIndex + 1}`} {...field} />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeOption(questionIndex, optionIndex)}
                            >
                              <XCircle className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createSurveyMutation.isPending}
              >
                {createSurveyMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Survey'
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateSurveyModal;