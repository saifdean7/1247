import { useState } from 'react';
import { SurveyQuestion } from '@/lib/types';
import { 
  Card, 
  CardContent, 
  CardHeader 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Grip, Trash2, Plus, ArrowUp, ArrowDown } from 'lucide-react';
import { useDragAndDrop } from '@/hooks/useDragAndDrop';

interface QuestionBuilderProps {
  question: SurveyQuestion;
  index: number;
  onUpdate: (question: SurveyQuestion) => void;
  onRemove: (id: string) => void;
  onMove: (id: string, direction: 'up' | 'down') => void;
  isFirst: boolean;
  isLast: boolean;
}

const QuestionBuilder = ({ 
  question, 
  index,
  onUpdate, 
  onRemove, 
  onMove, 
  isFirst, 
  isLast 
}: QuestionBuilderProps) => {
  const { dragRef, isDragging } = useDragAndDrop<HTMLDivElement>({
    type: 'question',
    item: { id: question.id },
  });

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ ...question, title: e.target.value });
  };

  const handleRequiredChange = (checked: boolean) => {
    onUpdate({ ...question, required: checked });
  };

  const handleOptionChange = (index: number, value: string) => {
    if (!question.options) return;
    
    const newOptions = [...question.options];
    newOptions[index] = value;
    onUpdate({ ...question, options: newOptions });
  };

  const handleAddOption = () => {
    if (!question.options) return;
    
    onUpdate({ ...question, options: [...question.options, ''] });
  };

  const handleRemoveOption = (index: number) => {
    if (!question.options || question.options.length <= 1) return;
    
    const newOptions = question.options.filter((_, i) => i !== index);
    onUpdate({ ...question, options: newOptions });
  };

  // Different question type renderers
  const renderMultipleChoice = () => (
    <div className="mt-3 space-y-2">
      <RadioGroup>
        {question.options?.map((option, i) => (
          <div key={i} className="flex items-center space-x-2 mb-2">
            <RadioGroupItem value={`option-${i}`} id={`option-${question.id}-${i}`} disabled />
            <div className="flex-1 flex items-center space-x-2">
              <Input
                value={option}
                onChange={(e) => handleOptionChange(i, e.target.value)}
                placeholder={`Option ${i + 1}`}
                className="flex-1"
              />
              {question.options && question.options.length > 1 && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveOption(i)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        ))}
      </RadioGroup>
      <Button
        variant="outline"
        size="sm"
        onClick={handleAddOption}
        className="mt-2"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Option
      </Button>
    </div>
  );

  const renderCheckboxes = () => (
    <div className="mt-3 space-y-2">
      {question.options?.map((option, i) => (
        <div key={i} className="flex items-center space-x-2 mb-2">
          <Checkbox id={`option-${question.id}-${i}`} disabled />
          <div className="flex-1 flex items-center space-x-2">
            <Input
              value={option}
              onChange={(e) => handleOptionChange(i, e.target.value)}
              placeholder={`Option ${i + 1}`}
              className="flex-1"
            />
            {question.options && question.options.length > 1 && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleRemoveOption(i)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      ))}
      <Button
        variant="outline"
        size="sm"
        onClick={handleAddOption}
        className="mt-2"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Option
      </Button>
    </div>
  );

  const renderTextInput = () => (
    <div className="mt-3">
      <Input 
        placeholder={question.placeholder || "Enter your answer"} 
        disabled 
      />
    </div>
  );

  const renderTextArea = () => (
    <div className="mt-3">
      <Textarea 
        placeholder={question.placeholder || "Enter your answer"} 
        disabled 
      />
    </div>
  );

  const renderRating = () => (
    <div className="mt-3 flex space-x-2">
      {[1, 2, 3, 4, 5].map((rating) => (
        <div 
          key={rating} 
          className="flex flex-col items-center"
        >
          <div className="text-2xl text-yellow-400 cursor-pointer">★</div>
          <span className="text-xs text-slate-500 mt-1">{rating}</span>
        </div>
      ))}
    </div>
  );

  const renderDatePicker = () => (
    <div className="mt-3">
      <Input type="date" disabled />
    </div>
  );

  const renderQuestionContent = () => {
    switch (question.type) {
      case 'multiple_choice':
        return renderMultipleChoice();
      case 'checkbox':
        return renderCheckboxes();
      case 'text':
        return renderTextInput();
      case 'textarea':
        return renderTextArea();
      case 'rating':
        return renderRating();
      case 'date':
        return renderDatePicker();
      default:
        return <p>Unsupported question type</p>;
    }
  };

  return (
    <Card 
      className={`${isDragging ? 'opacity-50' : ''}`}
    >
      <CardHeader className="px-4 py-2 flex flex-row items-center border-b border-slate-200 dark:border-slate-700">
        <div
          ref={dragRef}
          className="cursor-move mr-2 p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700"
        >
          <Grip className="h-5 w-5 text-slate-400" />
        </div>
        <div className="flex-1 flex items-center space-x-2">
          <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
            Question {index + 1}
          </span>
          <div className="flex ml-auto space-x-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onMove(question.id, 'up')}
              disabled={isFirst}
              className="h-8 w-8"
            >
              <ArrowUp className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onMove(question.id, 'down')}
              disabled={isLast}
              className="h-8 w-8"
            >
              <ArrowDown className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onRemove(question.id)}
              className="h-8 w-8 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Input
              value={question.title}
              onChange={handleTitleChange}
              placeholder="Enter question title"
              className="flex-1"
            />
            <div className="flex items-center space-x-2">
              <Switch
                id={`required-${question.id}`}
                checked={question.required}
                onCheckedChange={handleRequiredChange}
              />
              <Label htmlFor={`required-${question.id}`} className="text-sm">
                Required
              </Label>
            </div>
          </div>
          {renderQuestionContent()}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuestionBuilder;
