import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import QuestionTypeSelector from './QuestionTypeSelector';
import QuestionBuilder from './QuestionBuilder';
import { FilePlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { type InsertSurvey } from '@shared/schema';
import { QuestionType, SurveyQuestion } from '@/lib/types';

const SurveyBuilder = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState<SurveyQuestion[]>([]);
  const [showEmptyState, setShowEmptyState] = useState(true);

  // Create survey mutation
  const createSurveyMutation = useMutation({
    mutationFn: async (survey: InsertSurvey) => {
      const res = await apiRequest('POST', '/api/surveys', survey);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/surveys'] });
      toast({
        title: "Survey created",
        description: "Your survey has been successfully created.",
      });
      // Reset form
      setTitle('');
      setDescription('');
      setQuestions([]);
      setShowEmptyState(true);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create survey: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const handleAddQuestion = (type: QuestionType) => {
    const newQuestion: SurveyQuestion = {
      id: Date.now().toString(),
      type,
      title: '',
      required: false,
      options: type === 'multiple_choice' || type === 'checkbox' ? [''] : undefined,
      placeholder: type === 'text' || type === 'textarea' ? 'Enter your answer' : undefined,
    };
    
    setQuestions([...questions, newQuestion]);
    setShowEmptyState(false);
  };

  const handleUpdateQuestion = (updatedQuestion: SurveyQuestion) => {
    setQuestions(questions.map(q => 
      q.id === updatedQuestion.id ? updatedQuestion : q
    ));
  };

  const handleRemoveQuestion = (questionId: string) => {
    setQuestions(questions.filter(q => q.id !== questionId));
    if (questions.length === 1) {
      setShowEmptyState(true);
    }
  };

  const handleMoveQuestion = (questionId: string, direction: 'up' | 'down') => {
    const index = questions.findIndex(q => q.id === questionId);
    if (
      (direction === 'up' && index === 0) || 
      (direction === 'down' && index === questions.length - 1)
    ) {
      return;
    }
    
    const newQuestions = [...questions];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    [newQuestions[index], newQuestions[targetIndex]] = [newQuestions[targetIndex], newQuestions[index]];
    setQuestions(newQuestions);
  };

  const handleSaveSurvey = () => {
    if (!title) {
      toast({
        title: "Missing title",
        description: "Please provide a title for your survey.",
        variant: "destructive",
      });
      return;
    }
    
    if (questions.length === 0) {
      toast({
        title: "No questions",
        description: "Please add at least one question to your survey.",
        variant: "destructive",
      });
      return;
    }
    
    createSurveyMutation.mutate({
      userId: 1, // Using the demo user
      title,
      description,
      questions: questions,
      status: "draft",
    });
  };

  return (
    <div className="mt-6 bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">New Survey</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-500 dark:text-slate-400">Create your survey by dragging question types.</p>
      </div>
      <div className="border-t border-slate-200 dark:border-slate-700">
        <div className="grid grid-cols-1 lg:grid-cols-4">
          {/* Question Type Sidebar */}
          <div className="lg:col-span-1 border-r border-slate-200 dark:border-slate-700">
            <QuestionTypeSelector onSelectQuestionType={handleAddQuestion} />
          </div>
          
          {/* Survey Builder Canvas */}
          <div className="lg:col-span-3">
            <div className="px-4 py-5">
              <div className="mb-4">
                <label htmlFor="survey-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  Survey Title
                </label>
                <Input
                  type="text"
                  id="survey-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter survey title"
                  className="mt-1"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="survey-description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  Description
                </label>
                <Textarea
                  id="survey-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="Enter survey description"
                  className="mt-1"
                />
              </div>
              
              {/* Question Container (Drop Zone) */}
              <div className="mt-6 bg-slate-50 dark:bg-slate-700 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-4 min-h-[400px]">
                {showEmptyState ? (
                  <div className="text-center py-10">
                    <FilePlus className="mx-auto h-12 w-12 text-slate-400" />
                    <h3 className="mt-2 text-sm font-medium text-slate-900 dark:text-white">No questions added</h3>
                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Get started by adding a question from the left panel.</p>
                    <div className="mt-6">
                      <Button 
                        onClick={() => handleAddQuestion('multiple_choice')}
                      >
                        <svg className="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                        Add First Question
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <QuestionBuilder
                        key={question.id}
                        question={question}
                        index={index}
                        onUpdate={handleUpdateQuestion}
                        onRemove={handleRemoveQuestion}
                        onMove={handleMoveQuestion}
                        isFirst={index === 0}
                        isLast={index === questions.length - 1}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Builder Footer */}
      <div className="px-4 py-3 bg-slate-50 dark:bg-slate-700 text-right sm:px-6 border-t border-slate-200 dark:border-slate-700">
        <Button 
          onClick={handleSaveSurvey}
          disabled={createSurveyMutation.isPending}
        >
          {createSurveyMutation.isPending ? 'Saving...' : 'Save Survey'}
        </Button>
      </div>
    </div>
  );
};

export default SurveyBuilder;
