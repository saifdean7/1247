import { 
  Check, 
  CheckSquare, 
  MessageSquare, 
  AlignLeft, 
  Star, 
  Calendar, 
  Image, 
  List, 
  Sliders 
} from 'lucide-react';
import { QuestionType } from '@/lib/types';

interface QuestionTypeSelectorProps {
  onSelectQuestionType: (type: QuestionType) => void;
}

const QuestionTypeSelector = ({ onSelectQuestionType }: QuestionTypeSelectorProps) => {
  const questionTypes = [
    {
      type: 'multiple_choice' as QuestionType,
      label: 'Multiple Choice',
      description: 'Single selection',
      icon: <Check className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'checkbox' as QuestionType,
      label: 'Checkbox',
      description: 'Multiple selection',
      icon: <CheckSquare className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'text' as QuestionType,
      label: 'Text Input',
      description: 'Short answer',
      icon: <MessageSquare className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'textarea' as QuestionType,
      label: 'Text Area',
      description: 'Long answer',
      icon: <AlignLeft className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'rating' as QuestionType,
      label: 'Rating',
      description: 'Star rating',
      icon: <Star className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'date' as QuestionType,
      label: 'Date',
      description: 'Date picker',
      icon: <Calendar className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'image_choice' as QuestionType,
      label: 'Image Choice',
      description: 'Select images',
      icon: <Image className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'dropdown' as QuestionType,
      label: 'Dropdown',
      description: 'Select from list',
      icon: <List className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
    {
      type: 'slider' as QuestionType,
      label: 'Slider',
      description: 'Range selection',
      icon: <Sliders className="h-5 w-5 text-primary-600 dark:text-primary-300" />,
    },
  ];

  return (
    <div className="px-4 py-5">
      <h4 className="text-sm font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">Question Types</h4>
      <div className="mt-4 space-y-3">
        {questionTypes.map((item) => (
          <div 
            key={item.type}
            className="p-3 bg-slate-50 dark:bg-slate-700 rounded-md cursor-pointer transition-all duration-200 hover:transform hover:-translate-y-0.5 hover:shadow-md"
            onClick={() => onSelectQuestionType(item.type)}
          >
            <div className="flex items-center">
              <div className="flex-shrink-0 h-8 w-8 rounded-md bg-primary-100 dark:bg-primary-800 flex items-center justify-center">
                {item.icon}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-slate-900 dark:text-white">{item.label}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{item.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuestionTypeSelector;
