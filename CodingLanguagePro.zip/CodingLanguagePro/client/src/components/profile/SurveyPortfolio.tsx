import { useState } from 'react';
import { Survey } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';
import { BarChart2, ClipboardList, Eye, MessageSquare, MoreHorizontal, Heart, PenTool } from 'lucide-react';

interface SurveyPortfolioProps {
  userId: number;
}

const SurveyPortfolio = ({ userId }: SurveyPortfolioProps) => {
  const { data: surveys, isLoading } = useQuery<Survey[]>({
    queryKey: [`/api/users/${userId}/surveys`],
  });

  // Generate demo surveys if none exist yet
  const demoSurveys: Partial<Survey>[] = [
    {
      id: 1,
      userId: 1,
      title: "Product Satisfaction Survey",
      description: "Gathering feedback on our latest product release",
      status: "active",
      responseCount: 143,
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    },
    {
      id: 2,
      userId: 1,
      title: "Competitor Comparison Study",
      description: "Analyzing our market position against key competitors",
      status: "draft",
      responseCount: 0,
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    },
    {
      id: 3,
      userId: 1,
      title: "Website Usability Test",
      description: "Evaluating the user experience of our new website design",
      status: "completed",
      responseCount: 89,
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
    },
    {
      id: 4,
      userId: 1,
      title: "Employee Satisfaction Survey",
      description: "Measuring team morale and satisfaction levels",
      status: "active",
      responseCount: 56,
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    },
    {
      id: 5,
      userId: 1,
      title: "Market Trends Analysis",
      description: "Understanding emerging market patterns",
      status: "completed",
      responseCount: 127,
      createdAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000), // 21 days ago
    },
    {
      id: 6,
      userId: 1,
      title: "Product Feature Feedback",
      description: "Gathering input on proposed features",
      status: "draft",
      responseCount: 0,
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    }
  ];

  // Combine real and demo surveys
  const displaySurveys = surveys?.length ? surveys : demoSurveys;

  const getSurveyCategory = (survey: Partial<Survey>) => {
    // In a real app, this would be based on survey data
    if (survey.id && survey.id % 3 === 0) return "User Research";
    if (survey.id && survey.id % 2 === 0) return "Market Analysis";
    return "Customer Research";
  };
  
  const getSurveyIcon = (survey: Partial<Survey>) => {
    if (survey.id && survey.id % 3 === 0) return <Eye className="h-full w-full text-blue-500" />;
    if (survey.id && survey.id % 2 === 0) return <BarChart2 className="h-full w-full text-purple-500" />;
    return <ClipboardList className="h-full w-full text-green-500" />;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <Badge variant="outline" className="bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-100">
            Active
          </Badge>
        );
      case 'draft':
        return (
          <Badge variant="outline" className="bg-yellow-100 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-100">
            Draft
          </Badge>
        );
      case 'completed':
        return (
          <Badge variant="outline" className="bg-slate-100 dark:bg-slate-600 text-slate-800 dark:text-slate-200">
            Completed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-slate-100 dark:bg-slate-600 text-slate-800 dark:text-slate-200">
            {status}
          </Badge>
        );
    }
  };

  return (
    <div className="w-full">
      {/* Instagram-style grid layout */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-1">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="aspect-square bg-slate-200 dark:bg-slate-700 animate-pulse">
            </div>
          ))}
        </div>
      ) : (
        <>
          {/* Instagram-style Survey Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-1">
            {displaySurveys.map((survey) => (
              <div 
                key={survey.id} 
                className="aspect-square group relative overflow-hidden bg-slate-100 dark:bg-slate-700"
              >
                {/* Survey Preview */}
                <div className="h-full w-full p-4 flex flex-col items-center justify-center">
                  <div className="w-16 h-16 mb-4">
                    {getSurveyIcon(survey)}
                  </div>
                  <h4 className="text-center font-medium text-slate-900 dark:text-white line-clamp-2">
                    {survey.title}
                  </h4>
                  {survey.status && (
                    <div className="mt-2">
                      {getStatusBadge(survey.status)}
                    </div>
                  )}
                </div>
                
                {/* Instagram-style Hover Overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-70 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                  <div className="flex items-center justify-center space-x-8 text-white">
                    <div className="flex flex-col items-center">
                      <MessageSquare className="h-8 w-8 mb-1" />
                      <span className="text-sm font-medium">{survey.responseCount}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <Heart className="h-8 w-8 mb-1" />
                      <span className="text-sm font-medium">{Math.floor(Math.random() * 50) + 5}</span>
                    </div>
                  </div>
                  
                  {/* Action Button Based on Status */}
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="absolute bottom-4 text-white border-white hover:bg-white hover:text-slate-900"
                  >
                    {survey.status === 'draft' ? (
                      <>
                        <PenTool className="h-4 w-4 mr-1.5" />
                        Edit
                      </>
                    ) : (
                      <>
                        <Eye className="h-4 w-4 mr-1.5" />
                        View
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          {/* Instagram-style Load More Button */}
          <div className="mt-6 text-center">
            <Button variant="outline" className="mx-auto">
              Load More
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default SurveyPortfolio;
