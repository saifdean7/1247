import { useState } from 'react';
import { User } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Edit, Link2, MapPin, Briefcase, Calendar } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface ProfileBioProps {
  user: User;
  onUpdateUser: (data: Partial<User>) => void;
}

const ProfileBio = ({ user, onUpdateUser }: ProfileBioProps) => {
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editedBio, setEditedBio] = useState(user.bio || '');
  
  // Additional profile fields (these would be in the User schema in a real app)
  const [location, setLocation] = useState('New York, USA');
  const [website, setWebsite] = useState('surveyhub.com');
  const [occupation, setOccupation] = useState('Survey Specialist');
  const [joinedDate] = useState(new Date(2022, 6, 15)); // July 15, 2022
  
  const handleSaveBio = () => {
    onUpdateUser({ bio: editedBio });
    setIsEditDialogOpen(false);
    toast({
      title: "Bio updated",
      description: "Your profile has been successfully updated.",
    });
  };
  
  return (
    <>
      <div className="w-full bg-white dark:bg-slate-800 rounded-lg px-6 py-5">
        {/* Instagram-style Bio */}
        <div className="flex justify-between items-start">
          <div className="prose prose-sm dark:prose-invert max-w-none">
            {user.bio ? (
              <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                {user.bio}
              </p>
            ) : (
              <p className="text-sm text-slate-500 dark:text-slate-400 italic">
                No bio information provided yet. Click edit to add your bio.
              </p>
            )}
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-7 p-1.5"
            onClick={() => setIsEditDialogOpen(true)}
          >
            <Edit className="h-3.5 w-3.5" />
          </Button>
        </div>
        
        {/* Profile Metadata with Instagram-like icons */}
        <div className="mt-4 space-y-2">
          <div className="flex items-center text-sm text-slate-700 dark:text-slate-300">
            <Briefcase className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
            <span>{occupation}</span>
          </div>
          
          <div className="flex items-center text-sm text-slate-700 dark:text-slate-300">
            <MapPin className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
            <span>{location}</span>
          </div>
          
          <div className="flex items-center text-sm text-slate-700 dark:text-slate-300">
            <Link2 className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
            <a 
              href={`https://${website}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary-600 dark:text-primary-400 hover:underline"
            >
              {website}
            </a>
          </div>
          
          <div className="flex items-center text-sm text-slate-700 dark:text-slate-300">
            <Calendar className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
            <span>Joined {joinedDate.toLocaleDateString('en-US', { 
              month: 'long', 
              year: 'numeric' 
            })}</span>
          </div>
        </div>
      </div>
      
      {/* Edit Bio Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>
          
          <div className="mt-4 space-y-4">
            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={editedBio}
                onChange={(e) => setEditedBio(e.target.value)}
                placeholder="Tell others about yourself..."
                className="min-h-[120px] mt-1.5"
              />
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                {150 - editedBio.length} characters remaining
              </p>
            </div>
            
            <div>
              <Label htmlFor="location">Location</Label>
              <div className="flex items-center mt-1.5">
                <MapPin className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
                <Input 
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Add your location"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="website">Website</Label>
              <div className="flex items-center mt-1.5">
                <Link2 className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
                <Input 
                  id="website"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="Add your website"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="occupation">Occupation</Label>
              <div className="flex items-center mt-1.5">
                <Briefcase className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
                <Input 
                  id="occupation"
                  value={occupation}
                  onChange={(e) => setOccupation(e.target.value)}
                  placeholder="Add your occupation"
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveBio}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfileBio;
