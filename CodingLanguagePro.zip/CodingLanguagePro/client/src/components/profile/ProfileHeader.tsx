import { useState } from 'react';
import { User } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Edit, Upload, UserPlus, Check, Info, Grid, Cog, MessageSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import ProfileSettings from './ProfileSettings';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Separator } from '@/components/ui/separator';

interface ProfileHeaderProps {
  user: User;
  onUpdateUser: (data: Partial<User>) => void;
}

const ProfileHeader = ({ user, onUpdateUser }: ProfileHeaderProps) => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState<number>(0);
  const [followingCount, setFollowingCount] = useState<number>(0);
  
  // Get follow status, followers count, and following count
  const viewerId = 1; // Current logged in user (demo)
  
  // Check if the current user is following this profile
  useQuery<{isFollowing: boolean}>({
    queryKey: [`/api/users/${viewerId}/is-following/${user.id}`],
    enabled: user.id !== viewerId, // Only check if viewing someone else's profile
    onSuccess: (data) => {
      if (data) {
        setIsFollowing(data.isFollowing);
      }
    }
  });
  
  // Get followers count
  useQuery<{count: number}>({
    queryKey: [`/api/users/${user.id}/followers/count`],
    onSuccess: (data) => {
      if (data) {
        setFollowersCount(data.count);
      }
    }
  });
  
  // Get following count
  useQuery<{count: number}>({
    queryKey: [`/api/users/${user.id}/following/count`],
    onSuccess: (data) => {
      if (data) {
        setFollowingCount(data.count);
      }
    }
  });
  
  const handleProfileImageUpload = () => {
    toast({
      title: "Upload functionality",
      description: "This feature will upload a new profile image.",
    });
    // In a real implementation, this would open a file picker
    // and then upload the file to a server
  };
  
  const handleEditProfile = () => {
    toast({
      title: "Edit Profile",
      description: "This feature will allow editing the profile.",
    });
    // In a real implementation, this would open a modal or navigate
    // to an edit profile page
  };
  
  // Follow/unfollow mutation
  const followMutation = useMutation({
    mutationFn: (isFollow: boolean) => {
      if (isFollow) {
        return apiRequest('/api/follows', {
          method: 'POST',
          body: JSON.stringify({
            followerId: viewerId,
            followingId: user.id
          }),
        });
      } else {
        return apiRequest(`/api/follows?followerId=${viewerId}&followingId=${user.id}`, {
          method: 'DELETE'
        });
      }
    },
    onSuccess: () => {
      setIsFollowing(!isFollowing);
      setFollowersCount(prev => isFollowing ? prev - 1 : prev + 1);
      toast({
        title: isFollowing ? "Unfollowed" : "Following",
        description: isFollowing ? 
          `You are no longer following ${user.displayName || user.username}` : 
          `You are now following ${user.displayName || user.username}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isFollowing ? 'unfollow' : 'follow'}: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleFollow = () => {
    followMutation.mutate(!isFollowing);
  };
  
  // Stats data (in a real app, these would be fetched from API)
  const profileStats = [
    { label: "surveys", value: 38 },
    { label: "followers", value: followersCount },
    { label: "following", value: followingCount },
  ];
  
  return (
    <div className="w-full bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
      {/* Instagram-style Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Profile Picture */}
          <div className="flex-shrink-0 relative">
            <div className="relative group">
              <div className="h-24 w-24 md:h-36 md:w-36 rounded-full overflow-hidden border-2 border-white dark:border-slate-700 bg-white dark:bg-slate-700 ring-2 ring-primary-100 dark:ring-primary-900">
                <img 
                  className="h-full w-full object-cover" 
                  src={user.profileImageUrl || "https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"} 
                  alt="Profile"
                />
              </div>
              <a 
                href="/profile/edit"
                className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"
              >
                <Upload className="h-6 w-6 text-white" />
              </a>
            </div>
          </div>
          
          {/* Profile Info */}
          <div className="flex-1">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
              <div className="flex items-center">
                <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
                  {user.username}
                </h1>
                {user.isVerified && (
                  <Badge className="ml-2 bg-blue-500 text-white">
                    <Check className="h-3 w-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
              
              <div className="flex gap-2 mt-2 md:mt-0">
                {user.id === viewerId ? (
                  <>
                    <Button variant="outline" size="sm" asChild>
                      <a href="/profile/edit">Edit Profile</a>
                    </Button>
                    <ProfileSettings user={user} onUpdateUser={onUpdateUser} />
                  </>
                ) : (
                  <>
                    <Button 
                      size="sm" 
                      onClick={handleFollow}
                      variant={isFollowing ? "outline" : "default"}
                    >
                      {isFollowing ? "Following" : "Follow"}
                    </Button>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            {/* Instagram-style Stats Row */}
            <div className="flex space-x-8 mt-6">
              {profileStats.map((stat, index) => (
                <div key={index} className="text-center">
                  <span className="block font-bold text-slate-900 dark:text-white">{stat.value}</span>
                  <span className="text-sm text-slate-500 dark:text-slate-400">{stat.label}</span>
                </div>
              ))}
            </div>
            
            {/* Instagram-style Name and Bio Preview */}
            <div className="mt-4">
              <h2 className="font-semibold text-slate-900 dark:text-white">
                {user.displayName || user.username}
                {user.title && (
                  <span className="font-normal text-slate-500 dark:text-slate-400 ml-2">
                    • {user.title}
                  </span>
                )}
              </h2>
            </div>
            
            {/* Badges */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="bg-primary-100 dark:bg-primary-800 text-primary-800 dark:text-primary-100">
                {user.tier} Tier
              </Badge>
              
              <Badge variant="outline" className="bg-purple-100 dark:bg-purple-800 text-purple-800 dark:text-purple-100 flex items-center">
                <svg className="h-3 w-3 mr-1" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 18.26l-7.053 3.948 1.575-7.928L.587 8.792l8.027-.952L12 .5l3.386 7.34 8.027.952-5.935 5.488 1.575 7.928z" />
                </svg>
                Elite Creator
              </Badge>
            </div>
          </div>
        </div>
      </div>
      
      {/* Profile highlights with Instagram-style horizontal scroll (shown on mobile devices) */}
      <div className="px-4 py-3 overflow-x-auto md:hidden">
        <div className="flex space-x-4 min-w-max">
          {['Popular Surveys', 'Recent Activity', 'Top Achievements', 'Analytics', 'Earnings'].map((highlight, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="h-16 w-16 rounded-full border-2 border-primary-300 dark:border-primary-700 flex items-center justify-center bg-slate-100 dark:bg-slate-700">
                <Grid className="h-6 w-6 text-slate-500 dark:text-slate-300" />
              </div>
              <span className="mt-1 text-xs text-center text-slate-700 dark:text-slate-300">{highlight}</span>
            </div>
          ))}
        </div>
      </div>
      
      <Separator className="mt-2" />
    </div>
  );
};

export default ProfileHeader;
