import { useState } from 'react';
import { User } from '@shared/schema';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { 
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar';
import { 
  Upload,
  Settings,
  Key,
  User as UserIcon,
  MapPin,
  Globe,
  BriefcaseBusiness,
  UserCircle,
  AtSign,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Shield
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Define the form schema
const profileFormSchema = z.object({
  displayName: z.string().min(2, {
    message: "Display name must be at least 2 characters.",
  }),
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }).regex(/^[a-zA-Z0-9_]+$/, {
    message: "Username can only contain letters, numbers, and underscores.",
  }),
  bio: z.string().max(500, {
    message: "Bio cannot be longer than 500 characters.",
  }).optional(),
  title: z.string().max(100, {
    message: "Title cannot be longer than 100 characters.",
  }).optional(),
  location: z.string().max(100).optional(),
  website: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
  company: z.string().max(100).optional(),
  phoneNumber: z.string().max(15).optional(),
  email: z.string().email({ message: "Please enter a valid email address." }).optional(),
});

// Password schema
const passwordFormSchema = z.object({
  currentPassword: z.string().min(6, {
    message: "Current password is required.",
  }),
  newPassword: z.string().min(8, {
    message: "Password must be at least 8 characters.",
  }),
  confirmPassword: z.string().min(8),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Social links schema
const socialLinksFormSchema = z.object({
  facebook: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
  twitter: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
  instagram: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
  linkedin: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
});

// Privacy schema
const privacyFormSchema = z.object({
  profileVisibility: z.enum(["public", "private", "followers"], {
    required_error: "You need to select a privacy option.",
  }),
  activityVisibility: z.enum(["public", "private", "followers"], {
    required_error: "You need to select a privacy option.",
  }),
  allowTagging: z.boolean().default(true),
  allowComments: z.boolean().default(true),
});

interface ProfileSettingsProps {
  user: User;
  onUpdateUser: (data: Partial<User>) => void;
}

const ProfileSettings = ({ user, onUpdateUser }: ProfileSettingsProps) => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const [profileImagePreview, setProfileImagePreview] = useState(user.profileImageUrl || '');
  const [coverImagePreview, setCoverImagePreview] = useState(user.coverImageUrl || '');

  // Initialize the profile form
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      displayName: user.displayName || '',
      username: user.username || '',
      bio: user.bio || '',
      title: user.title || '',
      location: '',
      website: '',
      company: '',
      phoneNumber: '',
      email: '',
    },
  });

  // Initialize the password form
  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  // Initialize the social links form
  const socialLinksForm = useForm<z.infer<typeof socialLinksFormSchema>>({
    resolver: zodResolver(socialLinksFormSchema),
    defaultValues: {
      facebook: '',
      twitter: '',
      instagram: '',
      linkedin: '',
    },
  });

  // Initialize the privacy form
  const privacyForm = useForm<z.infer<typeof privacyFormSchema>>({
    resolver: zodResolver(privacyFormSchema),
    defaultValues: {
      profileVisibility: "public",
      activityVisibility: "public",
      allowTagging: true,
      allowComments: true,
    },
  });

  // Handle profile save
  const handleProfileSubmit = (data: z.infer<typeof profileFormSchema>) => {
    onUpdateUser({
      displayName: data.displayName,
      username: data.username,
      bio: data.bio,
      title: data.title,
    });
    
    toast({
      title: "Profile updated",
      description: "Your profile has been successfully updated",
    });
  };

  // Handle password save
  const handlePasswordSubmit = (data: z.infer<typeof passwordFormSchema>) => {
    // In a real app, we would send this to an API
    // We're just showing a success toast for now
    toast({
      title: "Password updated",
      description: "Your password has been successfully changed",
    });
    passwordForm.reset();
  };

  // Handle social links save
  const handleSocialLinksSubmit = (data: z.infer<typeof socialLinksFormSchema>) => {
    // In a real app, we would update the user's social links
    toast({
      title: "Social links updated",
      description: "Your social media links have been successfully updated",
    });
  };

  // Handle privacy settings save
  const handlePrivacySubmit = (data: z.infer<typeof privacyFormSchema>) => {
    // In a real app, we would update the user's privacy settings
    toast({
      title: "Privacy settings updated",
      description: "Your privacy settings have been successfully updated",
    });
  };

  // Handle profile image change
  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, we would upload this file to a server
      // For now, we'll just set a preview
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setProfileImagePreview(result);
        // We would normally upload the file and get a URL back
        onUpdateUser({ profileImageUrl: result });
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle cover image change
  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, we would upload this file to a server
      // For now, we'll just set a preview
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setCoverImagePreview(result);
        // We would normally upload the file and get a URL back
        onUpdateUser({ coverImageUrl: result });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        asChild
      >
        <a href="/settings">
          <Settings className="h-4 w-4 mr-1.5" />
          Settings
        </a>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Profile Settings</DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid grid-cols-4">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="password">Password</TabsTrigger>
              <TabsTrigger value="social">Social Links</TabsTrigger>
              <TabsTrigger value="privacy">Privacy</TabsTrigger>
            </TabsList>

            {/* Profile tab content */}
            <TabsContent value="profile" className="space-y-6">
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-6">
                  {/* Profile image upload */}
                  <div className="flex flex-col items-center space-y-2">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={profileImagePreview} alt={user.displayName || user.username} />
                      <AvatarFallback>{(user.displayName || user.username)?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex items-center">
                      <label htmlFor="profile-image" className="cursor-pointer text-sm text-primary-600 hover:text-primary-800 flex items-center">
                        <Upload className="h-3.5 w-3.5 mr-1" />
                        Change Avatar
                        <input 
                          id="profile-image" 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={handleProfileImageChange}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Cover image upload */}
                  <div className="flex-1">
                    <div className="relative h-32 w-full rounded-md bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      {coverImagePreview ? (
                        <img 
                          src={coverImagePreview} 
                          alt="Cover" 
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full bg-gradient-to-r from-primary-500 to-secondary-500" />
                      )}
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity">
                        <label htmlFor="cover-image" className="cursor-pointer text-white flex items-center bg-black/50 px-3 py-1.5 rounded-md">
                          <Upload className="h-4 w-4 mr-1.5" />
                          Change Cover Image
                          <input 
                            id="cover-image" 
                            type="file" 
                            className="hidden" 
                            accept="image/*"
                            onChange={handleCoverImageChange}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(handleProfileSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={profileForm.control}
                        name="displayName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Display Name</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <UserCircle className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="Your name" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <AtSign className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="username" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Professional Title</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <BriefcaseBusiness className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="e.g. Survey Expert" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <MapPin className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="e.g. New York, USA" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="website"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Website</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <Globe className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="https://yourwebsite.com" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company</FormLabel>
                            <FormControl>
                              <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                                <BriefcaseBusiness className="h-4 w-4 text-slate-400 mr-2" />
                                <Input placeholder="Company name" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={profileForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Tell others about yourself..."
                              className="resize-none min-h-[120px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Write a short bio about yourself. This will be displayed on your profile.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end">
                      <Button type="submit">
                        Save Profile
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </TabsContent>

            {/* Password tab content */}
            <TabsContent value="password" className="space-y-6">
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(handlePasswordSubmit)} className="space-y-4">
                  <FormField
                    control={passwordForm.control}
                    name="currentPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current Password</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Key className="h-4 w-4 text-slate-400 mr-2" />
                            <Input type="password" placeholder="••••••••" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={passwordForm.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>New Password</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Key className="h-4 w-4 text-slate-400 mr-2" />
                            <Input type="password" placeholder="••••••••" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Password must be at least 8 characters long.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={passwordForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm New Password</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Key className="h-4 w-4 text-slate-400 mr-2" />
                            <Input type="password" placeholder="••••••••" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end">
                    <Button type="submit">
                      Update Password
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>

            {/* Social links tab content */}
            <TabsContent value="social" className="space-y-6">
              <Form {...socialLinksForm}>
                <form onSubmit={socialLinksForm.handleSubmit(handleSocialLinksSubmit)} className="space-y-4">
                  <FormField
                    control={socialLinksForm.control}
                    name="facebook"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Facebook</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Facebook className="h-4 w-4 text-slate-400 mr-2" />
                            <Input placeholder="https://facebook.com/username" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={socialLinksForm.control}
                    name="twitter"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Twitter</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Twitter className="h-4 w-4 text-slate-400 mr-2" />
                            <Input placeholder="https://twitter.com/username" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={socialLinksForm.control}
                    name="instagram"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Instagram</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Instagram className="h-4 w-4 text-slate-400 mr-2" />
                            <Input placeholder="https://instagram.com/username" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={socialLinksForm.control}
                    name="linkedin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LinkedIn</FormLabel>
                        <FormControl>
                          <div className="flex items-center border rounded-md focus-within:ring-1 focus-within:ring-primary-500 px-3">
                            <Linkedin className="h-4 w-4 text-slate-400 mr-2" />
                            <Input placeholder="https://linkedin.com/in/username" {...field} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end">
                    <Button type="submit">
                      Save Social Links
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>

            {/* Privacy tab content */}
            <TabsContent value="privacy" className="space-y-6">
              <Form {...privacyForm}>
                <form onSubmit={privacyForm.handleSubmit(handlePrivacySubmit)} className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <h3 className="text-base font-medium">Profile Visibility</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Control who can see your profile information
                        </p>
                      </div>
                      <FormField
                        control={privacyForm.control}
                        name="profileVisibility"
                        render={({ field }) => (
                          <FormItem>
                            <select 
                              className="border rounded-md p-2 text-sm" 
                              value={field.value} 
                              onChange={field.onChange}
                            >
                              <option value="public">Everyone</option>
                              <option value="followers">Followers Only</option>
                              <option value="private">Only Me</option>
                            </select>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <h3 className="text-base font-medium">Activity Visibility</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Control who can see your activity and surveys
                        </p>
                      </div>
                      <FormField
                        control={privacyForm.control}
                        name="activityVisibility"
                        render={({ field }) => (
                          <FormItem>
                            <select 
                              className="border rounded-md p-2 text-sm" 
                              value={field.value} 
                              onChange={field.onChange}
                            >
                              <option value="public">Everyone</option>
                              <option value="followers">Followers Only</option>
                              <option value="private">Only Me</option>
                            </select>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex items-center justify-between py-3 border-b">
                      <div className="space-y-0.5">
                        <h3 className="text-base font-medium">Allow Tagging</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Let others tag you in their posts and surveys
                        </p>
                      </div>
                      <FormField
                        control={privacyForm.control}
                        name="allowTagging"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <div className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  checked={field.value}
                                  onChange={field.onChange}
                                  className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                />
                              </div>
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex items-center justify-between py-3">
                      <div className="space-y-0.5">
                        <h3 className="text-base font-medium">Allow Comments</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Let others comment on your posts and surveys
                        </p>
                      </div>
                      <FormField
                        control={privacyForm.control}
                        name="allowComments"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <div className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  checked={field.value}
                                  onChange={field.onChange}
                                  className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                />
                              </div>
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit">
                      Save Privacy Settings
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfileSettings;