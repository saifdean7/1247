import { useState, useEffect } from 'react';
import { Activity } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { 
  FileText, 
  DollarSign, 
  CheckCircle,
  Calendar,
  Award
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { formatDistanceToNow } from 'date-fns';

interface ActivityTimelineProps {
  userId: number;
}

const ActivityTimeline = ({ userId }: ActivityTimelineProps) => {
  const { data: activities, isLoading } = useQuery<Activity[]>({
    queryKey: [`/api/users/${userId}/activities`],
  });

  // Function to get the icon based on activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'survey_created':
        return (
          <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-800 flex items-center justify-center text-primary-600 dark:text-primary-300">
            <FileText className="h-6 w-6" />
          </div>
        );
      case 'payment_received':
        return (
          <div className="h-10 w-10 rounded-full bg-green-100 dark:bg-green-800 flex items-center justify-center text-green-600 dark:text-green-300">
            <DollarSign className="h-6 w-6" />
          </div>
        );
      case 'survey_completed':
        return (
          <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-300">
            <CheckCircle className="h-6 w-6" />
          </div>
        );
      case 'achievement_unlocked':
        return (
          <div className="h-10 w-10 rounded-full bg-yellow-100 dark:bg-yellow-800 flex items-center justify-center text-yellow-600 dark:text-yellow-300">
            <Award className="h-6 w-6" />
          </div>
        );
      default:
        return (
          <div className="h-10 w-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300">
            <Calendar className="h-6 w-6" />
          </div>
        );
    }
  };

  const formatTime = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };
  
  // Generate demo activities if none exist yet
  const demoActivities: Activity[] = [
    {
      id: 1,
      userId: 1,
      type: 'survey_created',
      description: 'Created a new survey: "Customer Satisfaction 2023"',
      createdAt: new Date(Date.now() - 7200000), // 2 hours ago
    },
    {
      id: 2,
      userId: 1,
      type: 'payment_received',
      description: 'Received payment: $48.75 for survey responses',
      createdAt: new Date(Date.now() - 86400000), // 24 hours ago
    },
    {
      id: 3,
      userId: 1,
      type: 'survey_completed',
      description: 'Completed "Product Market Research" survey',
      createdAt: new Date(Date.now() - 172800000), // 48 hours ago
    }
  ];

  // Combine real and demo activities
  const displayActivities = activities?.length ? activities : demoActivities;

  return (
    <div className="mt-6 bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">Recent Activity</h3>
        <Button variant="link" className="text-primary-600 dark:text-primary-400 p-0 h-auto">
          View All
        </Button>
      </div>
      <div className="border-t border-slate-200 dark:border-slate-700">
        {isLoading ? (
          <div className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
            Loading activities...
          </div>
        ) : (
          <ul role="list" className="divide-y divide-slate-200 dark:divide-slate-700">
            {displayActivities.map((activity) => (
              <li key={activity.id} className="px-4 py-4 sm:px-6">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{activity.description}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{formatTime(activity.createdAt)}</p>
                  </div>
                  <div>
                    <Button variant="outline" size="sm" className="h-8">
                      View
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default ActivityTimeline;
