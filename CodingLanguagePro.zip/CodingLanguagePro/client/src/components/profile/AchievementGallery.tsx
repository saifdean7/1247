import { useEffect } from 'react';
import { Achievement } from '@shared/schema';
import { 
  Star, 
  CheckCircle, 
  DollarSign, 
  Zap, 
  Users 
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';

interface AchievementGalleryProps {
  userId: number;
}

const AchievementGallery = ({ userId }: AchievementGalleryProps) => {
  const { data: achievements, isLoading } = useQuery<Achievement[]>({
    queryKey: [`/api/users/${userId}/achievements`],
  });

  // Function to get the icon based on achievement type
  const getAchievementIcon = (achievement: Achievement) => {
    switch (achievement.iconType) {
      case 'star':
        return <Star className="h-8 w-8" />;
      case 'checkmark':
        return <CheckCircle className="h-8 w-8" />;
      case 'money':
        return <DollarSign className="h-8 w-8" />;
      case 'lightning':
        return <Zap className="h-8 w-8" />;
      case 'users':
        return <Users className="h-8 w-8" />;
      default:
        return <Star className="h-8 w-8" />;
    }
  };

  // Generate demo achievements if none exist yet
  const demoAchievements: Achievement[] = [
    {
      id: 1,
      userId: 1,
      type: 'survey_creator',
      name: 'Survey Master',
      description: 'Created 25+ surveys',
      iconType: 'star',
      progress: 10,
      maxProgress: 25,
      isCompleted: false,
      unlockedAt: new Date(),
    },
    {
      id: 2,
      userId: 1,
      type: 'responder',
      name: 'Top Contributor',
      description: 'Completed 100+ surveys',
      iconType: 'checkmark',
      progress: 42,
      maxProgress: 100,
      isCompleted: false,
      unlockedAt: new Date(),
    },
    {
      id: 3,
      userId: 1,
      type: 'earner',
      name: 'Elite Earner',
      description: 'Earned over $250',
      iconType: 'money',
      progress: 180,
      maxProgress: 250,
      isCompleted: false,
      unlockedAt: new Date(),
    },
    {
      id: 4,
      userId: 1,
      type: 'quick_responder',
      name: 'Quick Responder',
      description: 'Avg. response time < 2min',
      iconType: 'lightning',
      progress: 100,
      maxProgress: 100,
      isCompleted: true,
      unlockedAt: new Date(),
    },
    {
      id: 5,
      userId: 1,
      type: 'team_leader',
      name: 'Team Leader',
      description: 'Invite 5 friends',
      iconType: 'users',
      progress: 0,
      maxProgress: 5,
      isCompleted: false,
      unlockedAt: new Date(),
    }
  ];

  // Combine real and demo achievements
  const displayAchievements = achievements?.length ? achievements : demoAchievements;

  // Group achievements by completion status
  const completedAchievements = displayAchievements.filter(a => a.isCompleted);
  const inProgressAchievements = displayAchievements.filter(a => !a.isCompleted);

  return (
    <div className="mt-6 bg-white dark:bg-slate-800 shadow overflow-hidden rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">Achievements</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-500 dark:text-slate-400">Your progress and badges earned.</p>
      </div>
      <div className="border-t border-slate-200 dark:border-slate-700 px-4 py-5 sm:p-6">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="flex flex-col items-center text-center">
                <Skeleton className="w-16 h-16 rounded-full" />
                <Skeleton className="mt-2 w-24 h-4" />
                <Skeleton className="mt-1 w-20 h-3" />
              </div>
            ))}
          </div>
        ) : (
          <>
            {/* Completed Achievements */}
            {completedAchievements.length > 0 && (
              <>
                <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-4">Completed</h4>
                <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 mb-8">
                  {completedAchievements.map((achievement) => (
                    <div key={achievement.id} className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 flex items-center justify-center rounded-full bg-primary-100 dark:bg-primary-800 text-primary-600 dark:text-primary-300">
                        {getAchievementIcon(achievement)}
                      </div>
                      <h4 className="mt-2 font-medium text-slate-900 dark:text-white">{achievement.name}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{achievement.description}</p>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* In Progress Achievements */}
            {inProgressAchievements.length > 0 && (
              <>
                <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-4">In Progress</h4>
                <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                  {inProgressAchievements.map((achievement) => (
                    <div key={achievement.id} className="flex flex-col items-center text-center">
                      <div className={`w-16 h-16 flex items-center justify-center rounded-full ${
                        achievement.progress > 0 
                          ? "bg-primary-100 dark:bg-primary-800 text-primary-600 dark:text-primary-300"
                          : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 opacity-60"
                      }`}>
                        {getAchievementIcon(achievement)}
                      </div>
                      <h4 className={`mt-2 font-medium ${
                        achievement.progress > 0
                          ? "text-slate-900 dark:text-white"
                          : "text-slate-500 dark:text-slate-400"
                      }`}>
                        {achievement.name}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{achievement.description}</p>
                      <div className="w-full mt-2">
                        <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-1" />
                        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                          {achievement.progress} / {achievement.maxProgress}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AchievementGallery;
