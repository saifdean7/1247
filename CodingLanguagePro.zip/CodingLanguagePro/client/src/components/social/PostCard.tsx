import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Post, Comment } from '@shared/schema';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  ThumbsUp, 
  Send
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface PostCardProps {
  post: Post;
  userId: number;
}

const PostCard = ({ post, userId }: PostCardProps) => {
  const [comment, setComment] = useState('');
  const [showComments, setShowComments] = useState(false);
  const queryClient = useQueryClient();
  
  // Fetch user data for the post author
  const { data: author } = useQuery({
    queryKey: [`/api/users/${post.userId}`],
  });
  
  // Fetch comments for this post
  const { data: comments = [] } = useQuery<Comment[]>({
    queryKey: [`/api/posts/${post.id}/comments`],
    enabled: showComments,
  });
  
  // Check if the current user has liked this post
  const { data: likeStatus } = useQuery({
    queryKey: [`/api/users/${userId}/likes/${post.id}`],
  });
  
  // Like/unlike mutation
  const likeMutation = useMutation({
    mutationFn: async () => {
      if (likeStatus?.isLiked) {
        return apiRequest(`/api/likes?userId=${userId}&postId=${post.id}`, {
          method: 'DELETE'
        });
      } else {
        return apiRequest('/api/likes', {
          method: 'POST',
          body: JSON.stringify({
            userId,
            postId: post.id
          })
        });
      }
    },
    onSuccess: () => {
      // Invalidate both the post and the like status
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/likes/${post.id}`] });
    },
  });
  
  // Add comment mutation
  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest('/api/comments', {
        method: 'POST',
        body: JSON.stringify({
          userId,
          postId: post.id,
          content
        })
      });
    },
    onSuccess: () => {
      // Invalidate comments and the post
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}/comments`] });
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}`] });
      setComment('');
    },
  });
  
  const handleToggleComments = () => {
    setShowComments(!showComments);
  };
  
  const handleLike = () => {
    likeMutation.mutate();
  };
  
  const handleShare = () => {
    // This would typically share functionality
    alert('Share feature coming soon!');
  };
  
  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      commentMutation.mutate(comment);
    }
  };
  
  // Format post date
  const postDate = post.createdAt 
    ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })
    : '';
  
  // Get type-specific badge color
  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'survey': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'article': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'news': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      default: return 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300';
    }
  };
  
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <Avatar className="h-10 w-10 mr-3">
              <AvatarImage src={author?.profileImageUrl || ''} alt={author?.displayName || 'User'} />
              <AvatarFallback>{author?.displayName?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium text-sm text-slate-900 dark:text-white">
                {author?.displayName || 'Anonymous User'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {postDate} · 
                <Badge variant="outline" className={`ml-1 text-xs ${getBadgeColor(post.type)}`}>
                  {post.type?.charAt(0).toUpperCase() + post.type?.slice(1)}
                </Badge>
              </p>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="px-4 pt-0 pb-2">
        <h4 className="text-md font-semibold mb-1">{post.title}</h4>
        <p className="text-sm text-slate-600 dark:text-slate-300">{post.content}</p>
        
        {post.imageUrl && (
          <div className="mt-3 rounded-md overflow-hidden">
            <img 
              src={post.imageUrl} 
              alt={post.title} 
              className="w-full h-auto object-cover" 
            />
          </div>
        )}
        
        <div className="flex items-center justify-between mt-3 text-sm text-slate-500 dark:text-slate-400">
          <div className="flex space-x-4">
            <span className="flex items-center">
              <ThumbsUp className="h-4 w-4 mr-1" />
              {post.likeCount || 0}
            </span>
            <span className="flex items-center">
              <MessageCircle className="h-4 w-4 mr-1" />
              {post.commentCount || 0}
            </span>
          </div>
          <span className="flex items-center">
            <Share2 className="h-4 w-4 mr-1" />
            {post.shareCount || 0}
          </span>
        </div>
      </CardContent>
      
      <Separator />
      
      <CardFooter className="px-2 py-1 flex justify-between">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleLike}
          className={likeStatus?.isLiked ? "text-blue-600" : ""}
        >
          <Heart className={`h-5 w-5 mr-1 ${likeStatus?.isLiked ? "fill-current" : ""}`} />
          Like
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleToggleComments}
        >
          <MessageCircle className="h-5 w-5 mr-1" />
          Comment
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleShare}
        >
          <Share2 className="h-5 w-5 mr-1" />
          Share
        </Button>
      </CardFooter>
      
      {showComments && (
        <div className="px-4 pb-3">
          <Separator className="mb-3" />
          
          {/* Comment form */}
          <form onSubmit={handleSubmitComment} className="flex items-center mb-3">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarFallback>
                {author?.displayName?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <Input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write a comment..."
              className="flex-grow text-sm"
            />
            <Button 
              type="submit" 
              size="sm" 
              variant="ghost" 
              disabled={!comment.trim()}
              className="ml-2"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
          
          {/* Comments list */}
          <div className="space-y-3">
            {comments.length === 0 ? (
              <p className="text-center text-sm text-slate-500 dark:text-slate-400 py-2">
                No comments yet. Be the first to comment!
              </p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="flex items-start">
                  <Avatar className="h-8 w-8 mr-2 mt-1">
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-3 py-2 text-sm flex-grow">
                    <p className="font-medium text-slate-900 dark:text-white text-xs">
                      {comment.userId === userId ? 'You' : 'User'}
                    </p>
                    <p className="text-slate-700 dark:text-slate-300">
                      {comment.content}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {comment.createdAt 
                        ? formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })
                        : ''
                      }
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </Card>
  );
};

export default PostCard;