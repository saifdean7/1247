import { useQuery } from '@tanstack/react-query';
import { Post } from '@shared/schema';
import { Loader2 } from 'lucide-react';
import PostCard from './PostCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface SocialFeedProps {
  userId: number;
  limit?: number;
}

const SocialFeed = ({ userId, limit = 5 }: SocialFeedProps) => {
  // Fetch posts
  const { 
    data: posts = [], 
    isLoading, 
    isError,
  } = useQuery<Post[]>({
    queryKey: [`/api/posts?limit=${limit}`],
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Social Feed</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
        </CardContent>
      </Card>
    );
  }
  
  if (isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Social Feed</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-red-500 mb-3">Failed to load posts</p>
            <Button variant="outline" size="sm">
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Social Feed</h2>
      
      {posts.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-slate-500 dark:text-slate-400 mb-3">
              No posts available at the moment
            </p>
            <Button variant="outline" size="sm">
              Create a Post
            </Button>
          </CardContent>
        </Card>
      ) : (
        posts.map((post) => (
          <PostCard key={post.id} post={post} userId={userId} />
        ))
      )}
      
      {posts.length > 0 && (
        <div className="flex justify-center mt-4">
          <Button variant="outline">
            View More
          </Button>
        </div>
      )}
    </div>
  );
};

export default SocialFeed;