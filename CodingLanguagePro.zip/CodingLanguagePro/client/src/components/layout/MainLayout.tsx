import { useState, ReactNode } from 'react';
import Sidebar from './Sidebar';
import TopNavigation from './TopNavigation';
import { useTheme } from '@/contexts/ThemeContext';

interface MainLayoutProps {
  children: ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isDarkMode } = useTheme();
  
  return (
    <div 
      className={`flex h-screen overflow-hidden ${isDarkMode ? 'dark' : ''} bg-slate-50 dark:bg-slate-900`}
    >
      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 flex md:hidden"
          aria-modal="true"
        >
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-slate-600 bg-opacity-75"
            aria-hidden="true"
            onClick={() => setSidebarOpen(false)}
          ></div>
          
          {/* Sidebar */}
          <div className="relative flex flex-col flex-1 w-full max-w-xs">
            <Sidebar isMobile={true} onClose={() => setSidebarOpen(false)} />
          </div>
          
          <div className="flex-shrink-0 w-14" aria-hidden="true">
            {/* Force sidebar to shrink to fit close icon */}
          </div>
        </div>
      )}
      
      {/* Desktop sidebar */}
      <div className="hidden md:flex md:flex-shrink-0">
        <div className="flex flex-col w-64">
          <Sidebar />
        </div>
      </div>
      
      {/* Main content area */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <TopNavigation onOpenMobileSidebar={() => setSidebarOpen(true)} />
        
        {/* Main content */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-slate-50 dark:bg-slate-900">
          <div className="py-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
