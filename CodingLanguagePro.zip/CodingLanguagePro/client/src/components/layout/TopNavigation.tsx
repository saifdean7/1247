import { useState } from 'react';
import { Menu, Search, Bell } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { useQuery } from '@tanstack/react-query';
import { type User } from '@shared/schema';

interface TopNavigationProps {
  onOpenMobileSidebar: () => void;
}

const TopNavigation = ({ onOpenMobileSidebar }: TopNavigationProps) => {
  const { data: currentUser } = useQuery<User>({
    queryKey: ['/api/users/1'], // Just getting the demo user for now
  });
  
  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
      {/* Mobile menu button */}
      <Button 
        variant="ghost"
        className="px-4 text-slate-500 dark:text-slate-400 md:hidden"
        onClick={onOpenMobileSidebar}
      >
        <Menu className="h-6 w-6" />
      </Button>
      
      {/* Top Navigation Items */}
      <div className="flex-1 flex justify-between px-4">
        <div className="flex-1 flex items-center">
          <div className="w-full max-w-lg lg:max-w-xs relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-slate-400" />
            </div>
            <Input
              id="search"
              name="search"
              className="block w-full pl-10 pr-3 py-2"
              placeholder="Search"
              type="search"
            />
          </div>
        </div>
        
        <div className="ml-4 flex items-center md:ml-6">
          {/* Notification button */}
          <Button variant="ghost" size="icon" className="rounded-full">
            <span className="sr-only">View notifications</span>
            <Bell className="h-6 w-6" />
          </Button>
          
          {/* Profile dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative rounded-full h-8 w-8 ml-3">
                <Avatar>
                  <AvatarImage 
                    src={currentUser?.profileImageUrl || "https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"} 
                    alt="User profile"
                  />
                  <AvatarFallback>{currentUser?.displayName?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Your Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};

export default TopNavigation;
