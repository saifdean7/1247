import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useTheme } from '@/contexts/ThemeContext';
import { Moon, Sun, Home, User, FileText, BarChart2, Wallet, Settings, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface SidebarProps {
  isMobile?: boolean;
  onClose?: () => void;
}

const Sidebar = ({ isMobile = false, onClose }: SidebarProps) => {
  const [location, setLocation] = useLocation();
  const { isDarkMode, toggleTheme } = useTheme();
  const { toast } = useToast();
  
  // Extract the current path without any query parameters
  const currentPath = location.split('?')[0];

  const navigationItems = [
    { path: '/', label: 'Dashboard', icon: <Home className="w-5 h-5 mr-3" /> },
    { path: '/profile', label: 'Profile', icon: <User className="w-5 h-5 mr-3" /> },
    { path: '/surveys', label: 'Surveys', icon: <FileText className="w-5 h-5 mr-3" /> },
    { path: '/analytics', label: 'Analytics', icon: <BarChart2 className="w-5 h-5 mr-3" /> },
    { path: '/wallet', label: 'Wallet', icon: <Wallet className="w-5 h-5 mr-3" /> },
    { path: '/settings', label: 'Settings', icon: <Settings className="w-5 h-5 mr-3" /> },
  ];

  const handleLinkClick = () => {
    if (isMobile && onClose) {
      onClose();
    }
  };
  
  const handleSignOut = () => {
    toast({
      title: 'Signed out',
      description: 'You have been successfully signed out.',
    });
    
    // In a real app, we would call an API to sign out the user
    // For demo purposes, just redirect to sign-in page
    setTimeout(() => {
      setLocation('/signin');
    }, 1000);
  };

  return (
    <div className="flex flex-col flex-1 min-h-0 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700">
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-2">
          <img 
            src="/assets/feathers_logo.png" 
            alt="Feathers Company" 
            className="h-8 w-8"
            onError={(e) => {
              console.log("Image failed to load");
              e.currentTarget.onerror = null;
              e.currentTarget.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMTZjMi4yMDYgMCA0LTEuNzk0IDQtNHMtMS43OTQtNC00LTQtNCAxLjc5NC00IDQgMS43OTQgNCA0IDR6bTAtNmMxLjEwMyAwIDIgLjg5NyAyIDJzLS44OTcgMi0yIDItMi0uODk3LTItMiAuODk3LTIgMi0yeiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMiAyQzYuNDc3IDIgMiA2LjQ3NyAyIDEyczQuNDc3IDEwIDEwIDEwIDEwLTQuNDc3IDEwLTEwUzE3LjUyMyAyIDEyIDJ6bTAgMkM3LjU4MiA0IDQgNy41ODIgNCAxMnMzLjU4MiA4IDggOCA4LTMuNTgyIDgtOC0zLjU4Mi04LTgtOHoiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjwvc3ZnPg==" 
            }}
          />
          <span className="text-xl font-bold text-primary-600 dark:text-primary-400">Feathers</span>
        </div>
        
        {isMobile && onClose && (
          <button onClick={onClose} className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        )}
      </div>
      
      {/* Navigation Links */}
      <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
        {navigationItems.map((item) => (
          <Link 
            key={item.path}
            href={item.path}
            onClick={handleLinkClick}
          >
            <a
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                currentPath === item.path
                  ? "bg-primary-50 dark:bg-slate-700 text-primary-600 dark:text-primary-400"
                  : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
              }`}
            >
              {item.icon}
              {item.label}
            </a>
          </Link>
        ))}
      </nav>
      
      {/* Theme Toggle and Sign Out */}
      <div className="p-4 space-y-3 border-t border-slate-200 dark:border-slate-700">
        <Button
          variant="outline"
          className="w-full justify-center"
          onClick={toggleTheme}
        >
          {isDarkMode ? (
            <>
              <Sun className="w-5 h-5 mr-2" />
              Light Mode
            </>
          ) : (
            <>
              <Moon className="w-5 h-5 mr-2" />
              Dark Mode
            </>
          )}
        </Button>
        
        <Button
          variant="outline"
          className="w-full justify-center text-red-500 hover:text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:text-red-300 dark:hover:bg-slate-700/70"
          onClick={handleSignOut}
        >
          <LogOut className="w-5 h-5 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
