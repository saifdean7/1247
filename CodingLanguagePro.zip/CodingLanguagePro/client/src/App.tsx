import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { queryClient } from "./lib/queryClient";
import ProfilePage from "./pages/ProfilePage";
import SurveyBuilderPage from "./pages/SurveyBuilderPage";
import DashboardPage from "./pages/DashboardPage";
import WalletPage from "./pages/WalletPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import SettingsPage from "./pages/SettingsPage";
import SignInPage from "./pages/SignInPage";
import SignUpPage from "./pages/SignUpPage";
import MainLayout from "./components/layout/MainLayout";
import AuthLayout from "./components/layout/AuthLayout";
import { ThemeProvider } from "./contexts/ThemeContext";

// New pages for profile button actions
import EditProfilePage from "./pages/EditProfilePage";
import ConnectionsPage from "./pages/ConnectionsPage";
import AchievementsPage from "./pages/AchievementsPage";
import ProfileAnalyticsPage from "./pages/ProfileAnalyticsPage";

function App() {
  // Simple authentication state 
  // In a real app, this would be managed with a proper auth context
  const [isAuthenticated, setIsAuthenticated] = useState(true); // For demo purposes, default to true
  const [location, setLocation] = useLocation();

  // For demo purposes only - would be handled by a real auth system
  useEffect(() => {
    // Automatically authenticate when going to auth pages for demo purposes
    if (location === '/signin' || location === '/signup') {
      setIsAuthenticated(false);
    }
    
    // Auto-redirect based on auth status
    if (!isAuthenticated && !location.startsWith('/sign')) {
      // setLocation('/signin');
    }
  }, [location, isAuthenticated]);

  // Determine if the current route should use AuthLayout instead of MainLayout
  const isAuthRoute = location === '/signin' || location === '/signup';

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        {isAuthRoute ? (
          <AuthLayout>
            <Switch>
              <Route path="/signin" component={SignInPage} />
              <Route path="/signup" component={SignUpPage} />
            </Switch>
          </AuthLayout>
        ) : (
          <MainLayout>
            <Switch>
              <Route path="/" component={DashboardPage} />
              
              {/* Main Profile Page */}
              <Route path="/profile" component={ProfilePage} />
              
              {/* New Profile Button Pages */}
              <Route path="/profile/edit" component={EditProfilePage} />
              <Route path="/profile/connections" component={ConnectionsPage} />
              <Route path="/profile/achievements" component={AchievementsPage} />
              <Route path="/profile/analytics" component={ProfileAnalyticsPage} />
              
              <Route path="/surveys" component={SurveyBuilderPage} />
              <Route path="/wallet" component={WalletPage} />
              <Route path="/analytics" component={AnalyticsPage} />
              <Route path="/settings" component={SettingsPage} />
              <Route component={NotFound} />
            </Switch>
          </MainLayout>
        )}
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
