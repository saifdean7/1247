import React from "react";
import feathersLogoImage from "../assets/images/feathers-logo.png";

interface FeatherLogoProps {
  className?: string;
}

export function FeatherLogo({ className = "w-10 h-10" }: FeatherLogoProps) {
  return (
    <img 
      src={feathersLogoImage} 
      alt="Feathers Logo" 
      className={className}
    />
  );
}
