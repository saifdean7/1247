import { Survey, User, Question, SurveyResponse } from "@shared/schema";

// Extended Survey type with creator information
export interface SurveyWithCreator extends Survey {
  creator: Omit<User, "password">;
  responseCount: number;
}

// Type for survey response with user information
export interface SurveyResponseWithUser extends SurveyResponse {
  user: Omit<User, "password">;
}

// Feed tab types
export type FeedTab = "forYou" | "popular" | "following" | "recent";

// Type for completed survey response
export interface CompletedSurveyResponse {
  response: {
    id: number;
    surveyId: number;
    userId: number;
    answers: Record<string, any>;
    createdAt: Date;
  };
  user: Omit<User, "password">;
  pointsAwarded: number;
}
