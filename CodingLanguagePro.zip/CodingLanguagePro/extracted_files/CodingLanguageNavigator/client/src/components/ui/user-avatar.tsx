import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "@shared/schema";

interface UserAvatarProps {
  user: User | null;
  className?: string;
}

export function UserAvatar({ user, className = "h-10 w-10" }: UserAvatarProps) {
  if (!user) {
    return (
      <Avatar className={className}>
        <AvatarFallback>U</AvatarFallback>
      </Avatar>
    );
  }

  // Get initials from user's name
  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .substring(0, 2);

  return (
    <Avatar className={className}>
      {user.profileImage ? (
        <AvatarImage src={user.profileImage} alt={user.name} />
      ) : null}
      <AvatarFallback className="bg-primary-100 text-primary-800">
        {initials}
      </AvatarFallback>
    </Avatar>
  );
}
