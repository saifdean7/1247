import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface SurveyCompletedModalProps {
  isOpen: boolean;
  onClose: () => void;
  pointsAwarded: number;
}

export function SurveyCompletedModal({ 
  isOpen, 
  onClose, 
  pointsAwarded 
}: SurveyCompletedModalProps) {
  const { user } = useAuth();
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white rounded-xl w-full max-w-md overflow-hidden">
        <div className="p-6 text-center">
          <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-10 w-10 text-primary-600" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Survey Completed!</h2>
          <p className="text-gray-600 mb-6">Thank you for sharing your insights. Your response has been recorded.</p>
          
          <div className="bg-primary-50 rounded-lg p-4 mb-6">
            <p className="text-primary-800 font-medium mb-1">You've earned</p>
            <p className="text-3xl font-bold text-primary-700">+{pointsAwarded} points</p>
            <p className="text-primary-600 text-sm">New balance: {user?.points} points</p>
          </div>
          
          <Button 
            className="w-full mb-2"
            onClick={onClose}
          >
            Return to Feed
          </Button>
          <Button 
            variant="outline" 
            className="w-full"
            onClick={onClose}
          >
            Share Results
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
