import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { PlusCircle, Trash2, X } from "lucide-react";
import { Question, QuestionType, SurveyWithQuestions } from "@shared/schema";
import { nanoid } from "nanoid";

interface SurveyCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SurveyCreatorModal({ isOpen, onClose }: SurveyCreatorModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [estimatedTime, setEstimatedTime] = useState("");
  const [rewardPoints, setRewardPoints] = useState(25);
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: nanoid(),
      text: "",
      type: "MULTIPLE_CHOICE_SINGLE",
      options: ["", ""],
      isRequired: true
    }
  ]);

  const createSurveyMutation = useMutation({
    mutationFn: async (surveyData: SurveyWithQuestions) => {
      const res = await apiRequest("POST", "/api/surveys", surveyData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/surveys"] });
      toast({
        title: "Survey created!",
        description: "Your survey has been published and is now available to others.",
      });
      resetForm();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create survey",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setTitle("");
    setDescription("");
    setCategory("");
    setEstimatedTime("");
    setRewardPoints(25);
    setQuestions([
      {
        id: nanoid(),
        text: "",
        type: "MULTIPLE_CHOICE_SINGLE",
        options: ["", ""],
        isRequired: true
      }
    ]);
  };

  const handleAddQuestion = () => {
    const newQuestion: Question = {
      id: nanoid(),
      text: "",
      type: "MULTIPLE_CHOICE_SINGLE",
      options: ["", ""],
      isRequired: true
    };
    setQuestions([...questions, newQuestion]);
  };

  const handleRemoveQuestion = (index: number) => {
    if (questions.length > 1) {
      setQuestions(questions.filter((_, i) => i !== index));
    }
  };

  const handleQuestionChange = (index: number, field: keyof Question, value: any) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index] = { ...updatedQuestions[index], [field]: value };
    setQuestions(updatedQuestions);
  };

  const handleOptionChange = (questionIndex: number, optionIndex: number, value: string) => {
    const updatedQuestions = [...questions];
    const question = updatedQuestions[questionIndex];
    if (question.options) {
      const updatedOptions = [...question.options];
      updatedOptions[optionIndex] = value;
      updatedQuestions[questionIndex] = { ...question, options: updatedOptions };
      setQuestions(updatedQuestions);
    }
  };

  const handleAddOption = (questionIndex: number) => {
    const updatedQuestions = [...questions];
    const question = updatedQuestions[questionIndex];
    if (question.options) {
      updatedQuestions[questionIndex] = {
        ...question,
        options: [...question.options, ""]
      };
      setQuestions(updatedQuestions);
    }
  };

  const handleRemoveOption = (questionIndex: number, optionIndex: number) => {
    const updatedQuestions = [...questions];
    const question = updatedQuestions[questionIndex];
    if (question.options && question.options.length > 2) {
      const updatedOptions = question.options.filter((_, i) => i !== optionIndex);
      updatedQuestions[questionIndex] = { ...question, options: updatedOptions };
      setQuestions(updatedQuestions);
    }
  };

  const handleSubmit = () => {
    if (!title || !description || !category || !estimatedTime) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (questions.some(q => !q.text)) {
      toast({
        title: "Incomplete questions",
        description: "Please ensure all questions have text",
        variant: "destructive",
      });
      return;
    }

    const surveyData: SurveyWithQuestions = {
      creatorId: user?.id || 0,
      title,
      description,
      category,
      estimatedTime,
      rewardPoints,
      questions,
    };

    createSurveyMutation.mutate(surveyData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">Create New Survey</DialogTitle>
          <Button variant="ghost" size="icon" className="absolute right-4 top-4" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="overflow-y-auto p-6 max-h-[calc(90vh-120px)]">
          {/* Survey Basics */}
          <div className="mb-6">
            <Label htmlFor="surveyTitle" className="block text-sm font-medium text-gray-700 mb-2">Survey Title</Label>
            <Input
              id="surveyTitle"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What's your survey about?"
              className="w-full"
            />
          </div>
          
          <div className="mb-6">
            <Label htmlFor="surveyDescription" className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
            <Textarea
              id="surveyDescription"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide details about your survey..."
              rows={3}
              className="w-full"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <Label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lifestyle">Lifestyle</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="health">Health & Wellness</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="estimatedTime" className="block text-sm font-medium text-gray-700 mb-2">Estimated Completion Time</Label>
              <Select value={estimatedTime} onValueChange={setEstimatedTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Less than 1 minute">Less than 1 minute</SelectItem>
                  <SelectItem value="1-2 minutes">1-2 minutes</SelectItem>
                  <SelectItem value="3-5 minutes">3-5 minutes</SelectItem>
                  <SelectItem value="5-10 minutes">5-10 minutes</SelectItem>
                  <SelectItem value="10-15 minutes">10-15 minutes</SelectItem>
                  <SelectItem value="More than 15 minutes">More than 15 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mb-8">
            <Label htmlFor="rewardPoints" className="block text-sm font-medium text-gray-700 mb-2">Reward Points</Label>
            <div className="flex items-center">
              <Slider
                value={[rewardPoints]}
                onValueChange={(values) => setRewardPoints(values[0])}
                min={5}
                max={50}
                step={5}
                className="flex-1 mr-4"
              />
              <span className="font-medium text-primary-600">{rewardPoints} pts</span>
            </div>
            <p className="mt-1 text-sm text-gray-500">Higher rewards attract more participants. Costs are deducted from your balance.</p>
          </div>
          
          {/* Question Builder */}
          <h3 className="font-semibold text-lg mb-4 text-gray-900">Survey Questions</h3>
          
          {questions.map((question, questionIndex) => (
            <div key={question.id} className="border border-gray-200 rounded-lg p-4 mb-4">
              <div className="flex justify-between mb-4">
                <h4 className="font-medium text-gray-900">Question {questionIndex + 1}</h4>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm" onClick={() => handleAddQuestion()}>
                    <PlusCircle className="h-5 w-5 text-gray-500" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={questions.length <= 1}
                    onClick={() => handleRemoveQuestion(questionIndex)}
                  >
                    <Trash2 className="h-5 w-5 text-gray-500" />
                  </Button>
                </div>
              </div>
              
              <div className="mb-4">
                <Input
                  placeholder="Enter your question"
                  value={question.text}
                  onChange={(e) => handleQuestionChange(questionIndex, 'text', e.target.value)}
                  className="w-full"
                />
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-gray-700 mb-2">Question Type</Label>
                <Select
                  value={question.type}
                  onValueChange={(value) => handleQuestionChange(questionIndex, 'type', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MULTIPLE_CHOICE_SINGLE">Multiple Choice (Single)</SelectItem>
                    <SelectItem value="MULTIPLE_CHOICE_MULTIPLE">Multiple Choice (Multiple)</SelectItem>
                    <SelectItem value="OPEN_TEXT">Open Text</SelectItem>
                    <SelectItem value="RATING_SCALE">Rating Scale</SelectItem>
                    <SelectItem value="SLIDER">Slider</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Question type specific inputs */}
              <div className="space-y-2">
                {['MULTIPLE_CHOICE_SINGLE', 'MULTIPLE_CHOICE_MULTIPLE'].includes(question.type) && (
                  <>
                    {question.options?.map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center">
                        {question.type === 'MULTIPLE_CHOICE_SINGLE' ? (
                          <RadioGroup disabled value="">
                            <RadioGroupItem value="disabled" className="ml-2 h-4 w-4" />
                          </RadioGroup>
                        ) : (
                          <Checkbox disabled className="ml-2 h-4 w-4" />
                        )}
                        <Input
                          value={option}
                          onChange={(e) => handleOptionChange(questionIndex, optionIndex, e.target.value)}
                          className="ml-2 flex-1"
                          placeholder={`Option ${optionIndex + 1}`}
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          disabled={question.options?.length <= 2}
                          onClick={() => handleRemoveOption(questionIndex, optionIndex)}
                          className="ml-2 p-1"
                        >
                          <X className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ))}
                    
                    <div className="mt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleAddOption(questionIndex)}
                        className="flex items-center text-primary-600 text-sm p-0"
                      >
                        <PlusCircle className="h-4 w-4 mr-1" />
                        Add Option
                      </Button>
                    </div>
                  </>
                )}
                
                {question.type === 'RATING_SCALE' && (
                  <div className="flex flex-col">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Very Unsatisfied</span>
                      <span className="text-sm text-gray-600">Very Satisfied</span>
                    </div>
                    <div className="flex justify-between">
                      <div className="flex items-center justify-center h-10 w-10 rounded-full border border-gray-300 text-gray-700 cursor-pointer hover:bg-gray-100">1</div>
                      <div className="flex items-center justify-center h-10 w-10 rounded-full border border-gray-300 text-gray-700 cursor-pointer hover:bg-gray-100">2</div>
                      <div className="flex items-center justify-center h-10 w-10 rounded-full border border-gray-300 text-gray-700 cursor-pointer hover:bg-gray-100">3</div>
                      <div className="flex items-center justify-center h-10 w-10 rounded-full border border-gray-300 text-gray-700 cursor-pointer hover:bg-gray-100">4</div>
                      <div className="flex items-center justify-center h-10 w-10 rounded-full border border-gray-300 text-gray-700 cursor-pointer hover:bg-gray-100">5</div>
                    </div>
                  </div>
                )}
                
                {question.type === 'OPEN_TEXT' && (
                  <Textarea disabled placeholder="Participants will enter their answer here" />
                )}
                
                {question.type === 'SLIDER' && (
                  <div className="px-2 py-4">
                    <Slider disabled value={[50]} className="w-full" />
                  </div>
                )}
              </div>
            </div>
          ))}
          
          <Button 
            variant="outline" 
            className="w-full mb-4"
            onClick={handleAddQuestion}
          >
            <PlusCircle className="h-5 w-5 mr-2" />
            Add Question
          </Button>
        </div>
        
        <DialogFooter className="border-t border-gray-200 px-6 py-4">
          <Button variant="outline" onClick={onClose}>
            Save Draft
          </Button>
          <div className="flex space-x-2">
            <Button variant="outline">
              Preview
            </Button>
            <Button 
              disabled={createSurveyMutation.isPending}
              onClick={handleSubmit}
            >
              {createSurveyMutation.isPending ? "Publishing..." : "Publish Survey"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
