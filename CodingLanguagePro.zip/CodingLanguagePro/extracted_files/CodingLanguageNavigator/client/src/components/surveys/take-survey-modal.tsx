import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { 
  RadioGroup, 
  RadioGroupItem 
} from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Progress } from "@/components/ui/progress";
import { Clock } from "lucide-react";
import { SurveyWithCreator } from "@/lib/types";
import { Question, SurveyResponse } from "@shared/schema";

interface TakeSurveyModalProps {
  isOpen: boolean;
  onClose: () => void;
  survey: SurveyWithCreator;
  onComplete: (pointsAwarded: number) => void;
}

export function TakeSurveyModal({ 
  isOpen, 
  onClose, 
  survey, 
  onComplete 
}: TakeSurveyModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  
  const questions = survey.questions as Question[];
  const currentQuestion = questions[currentQuestionIndex];
  const progress = Math.floor(((currentQuestionIndex + 1) / questions.length) * 100);
  
  const submitResponseMutation = useMutation({
    mutationFn: async (data: { answers: Record<string, any> }) => {
      const res = await apiRequest(
        "POST", 
        `/api/surveys/${survey.id}/responses`, 
        data
      );
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Survey completed!",
        description: "Thank you for your participation.",
      });
      onComplete(data.pointsAwarded);
    },
    onError: (error: Error) => {
      toast({
        title: "Error submitting response",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleNextQuestion = () => {
    if (!currentQuestion.isRequired && !answers[currentQuestion.id]) {
      // If question is not required and no answer, just move on
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        handleSubmit();
      }
      return;
    }

    // Check if the current question has been answered
    if (!answers[currentQuestion.id]) {
      toast({
        title: "Required question",
        description: "Please answer this question before proceeding.",
        variant: "destructive",
      });
      return;
    }

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      handleSubmit();
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleAnswerChange = (value: any) => {
    setAnswers({
      ...answers,
      [currentQuestion.id]: value,
    });
  };

  const handleMultiSelectChange = (optionValue: string, checked: boolean) => {
    const currentAnswer = answers[currentQuestion.id] || [];
    let newAnswer;
    
    if (checked) {
      newAnswer = [...currentAnswer, optionValue];
    } else {
      newAnswer = currentAnswer.filter((value: string) => value !== optionValue);
    }
    
    setAnswers({
      ...answers,
      [currentQuestion.id]: newAnswer,
    });
  };

  const handleSubmit = () => {
    // Check if all required questions are answered
    const unansweredRequiredQuestions = questions
      .filter(q => q.isRequired && !answers[q.id])
      .map(q => q.id);
    
    if (unansweredRequiredQuestions.length > 0) {
      // Go to the first unanswered required question
      const firstUnansweredIndex = questions.findIndex(
        q => q.id === unansweredRequiredQuestions[0]
      );
      setCurrentQuestionIndex(firstUnansweredIndex);
      
      toast({
        title: "Required questions",
        description: "Please answer all required questions.",
        variant: "destructive",
      });
      return;
    }
    
    submitResponseMutation.mutate({ answers });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader className="bg-primary-50 px-6 py-4 border-b border-primary-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <UserAvatar user={survey.creator} />
              <div className="ml-3">
                <h2 className="text-lg font-bold text-gray-900">{survey.title}</h2>
                <p className="text-sm text-gray-600">By {survey.creator.name}</p>
              </div>
            </div>
          </div>
          <div className="mt-2 flex justify-between items-center">
            <div className="flex items-center text-sm text-gray-600">
              <Clock className="h-4 w-4 mr-1" />
              <span>{survey.estimatedTime} to complete</span>
            </div>
            <div className="bg-primary-600 text-white text-sm font-semibold px-3 py-1 rounded-full">
              +{survey.rewardPoints} points
            </div>
          </div>
        </DialogHeader>
        
        <div className="overflow-y-auto p-6 max-h-[calc(90vh-200px)]">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">{survey.description}</p>
            
            {/* Progress Bar */}
            <Progress value={progress} className="w-full h-2.5 mb-2" />
            <p className="text-xs text-gray-500 text-right">
              Question {currentQuestionIndex + 1} of {questions.length}
            </p>
          </div>
          
          {/* Current Question */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              {currentQuestion?.text}
            </h3>
            
            {currentQuestion?.type === 'MULTIPLE_CHOICE_SINGLE' && (
              <RadioGroup
                value={answers[currentQuestion.id] || ""}
                onValueChange={handleAnswerChange}
                className="space-y-2"
              >
                {currentQuestion.options?.map((option, index) => (
                  <div key={index} className="flex items-center">
                    <RadioGroupItem value={option} id={`q-${currentQuestion.id}-option-${index}`} />
                    <Label htmlFor={`q-${currentQuestion.id}-option-${index}`} className="ml-3">{option}</Label>
                  </div>
                ))}
              </RadioGroup>
            )}
            
            {currentQuestion?.type === 'MULTIPLE_CHOICE_MULTIPLE' && (
              <div className="space-y-2">
                {currentQuestion.options?.map((option, index) => (
                  <div key={index} className="flex items-center">
                    <Checkbox 
                      id={`q-${currentQuestion.id}-option-${index}`} 
                      checked={(answers[currentQuestion.id] || []).includes(option)}
                      onCheckedChange={(checked) => 
                        handleMultiSelectChange(option, checked as boolean)
                      }
                    />
                    <Label htmlFor={`q-${currentQuestion.id}-option-${index}`} className="ml-3">{option}</Label>
                  </div>
                ))}
              </div>
            )}
            
            {currentQuestion?.type === 'OPEN_TEXT' && (
              <Textarea 
                value={answers[currentQuestion.id] || ""}
                onChange={(e) => handleAnswerChange(e.target.value)}
                placeholder="Enter your answer here..."
                rows={4}
              />
            )}
            
            {currentQuestion?.type === 'RATING_SCALE' && (
              <div className="flex flex-col mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Very Unsatisfied</span>
                  <span className="text-sm text-gray-600">Very Satisfied</span>
                </div>
                <div className="flex justify-between">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <Label
                      key={rating}
                      htmlFor={`rating-${rating}`}
                      className="flex flex-col items-center cursor-pointer"
                    >
                      <input
                        type="radio"
                        id={`rating-${rating}`}
                        name={`q-${currentQuestion.id}`}
                        className="sr-only peer"
                        checked={answers[currentQuestion.id] === rating}
                        onChange={() => handleAnswerChange(rating)}
                      />
                      <div className={`flex items-center justify-center h-10 w-10 rounded-full border ${
                        answers[currentQuestion.id] === rating
                          ? "bg-primary-500 text-white border-primary-500" 
                          : "border-gray-300 text-gray-700 hover:bg-gray-100"
                      }`}>
                        {rating}
                      </div>
                    </Label>
                  ))}
                </div>
              </div>
            )}
            
            {currentQuestion?.type === 'SLIDER' && (
              <div className="space-y-2 px-2 py-4">
                <Label htmlFor={`slider-${currentQuestion.id}`}>
                  Value: {answers[currentQuestion.id] || 50}
                </Label>
                <input
                  type="range"
                  id={`slider-${currentQuestion.id}`}
                  min="0"
                  max="100"
                  value={answers[currentQuestion.id] || 50}
                  onChange={(e) => handleAnswerChange(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">0</span>
                  <span className="text-sm text-gray-500">100</span>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <DialogFooter className="border-t border-gray-200 px-6 py-4">
          <Button 
            variant="outline" 
            onClick={handlePreviousQuestion}
            disabled={currentQuestionIndex === 0}
          >
            Previous
          </Button>
          <Button 
            onClick={handleNextQuestion}
            disabled={submitResponseMutation.isPending}
          >
            {currentQuestionIndex < questions.length - 1 ? "Next" : "Submit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
