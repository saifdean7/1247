import { useState } from "react";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThumbsUp, MessageSquare, Share2, Clock, Users } from "lucide-react";
import { TakeSurveyModal } from "./take-survey-modal";
import { SurveyCompletedModal } from "./survey-completed-modal";
import { SurveyWithCreator } from "@/lib/types";
import { formatDistanceToNow } from "date-fns";

interface SurveyCardProps {
  survey: SurveyWithCreator;
  onSurveyCompleted?: (pointsAwarded: number) => void;
}

export function SurveyCard({ survey, onSurveyCompleted }: SurveyCardProps) {
  const [isTakeSurveyOpen, setIsTakeSurveyOpen] = useState(false);
  const [isCompletedModalOpen, setIsCompletedModalOpen] = useState(false);
  const [earnedPoints, setEarnedPoints] = useState(0);

  const handleTakeSurvey = () => {
    setIsTakeSurveyOpen(true);
  };

  const handleSurveyComplete = (pointsAwarded: number) => {
    setIsTakeSurveyOpen(false);
    setEarnedPoints(pointsAwarded);
    setIsCompletedModalOpen(true);
    if (onSurveyCompleted) {
      onSurveyCompleted(pointsAwarded);
    }
  };

  const formattedDate = formatDistanceToNow(new Date(survey.createdAt), { addSuffix: true });

  return (
    <>
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition duration-200">
        <CardContent className="p-0">
          <div className="p-5">
            <div className="flex items-center mb-4">
              <UserAvatar user={survey.creator} />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">{survey.creator.name}</p>
                <p className="text-xs text-gray-500">{formattedDate}</p>
              </div>
              <div className="ml-auto flex items-center space-x-1">
                <span className="text-xs font-semibold text-primary-600 bg-primary-50 px-2 py-1 rounded-full">
                  +{survey.rewardPoints} pts
                </span>
              </div>
            </div>
            
            <h3 className="font-semibold text-lg mb-2 text-gray-900">{survey.title}</h3>
            <p className="text-gray-600 text-sm mb-4">{survey.description}</p>
            
            <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                <span>{survey.estimatedTime}</span>
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                <span>{survey.responseCount} responses</span>
              </div>
            </div>
            
            <div className="flex justify-between">
              <Button 
                className="w-full bg-primary-500 hover:bg-primary-600 text-white" 
                onClick={handleTakeSurvey}
              >
                Take Survey
              </Button>
            </div>
          </div>
          
          <div className="bg-gray-50 px-5 py-3 border-t border-gray-100">
            <div className="flex justify-between items-center text-sm">
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="flex items-center text-gray-500 hover:text-gray-700">
                  <ThumbsUp className="h-5 w-5 mr-1" />
                  <span>42</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center text-gray-500 hover:text-gray-700">
                  <MessageSquare className="h-5 w-5 mr-1" />
                  <span>12</span>
                </Button>
              </div>
              <div>
                <Button variant="ghost" size="sm" className="flex items-center text-gray-500 hover:text-gray-700">
                  <Share2 className="h-5 w-5 mr-1" />
                  <span>Share</span>
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <TakeSurveyModal
        isOpen={isTakeSurveyOpen}
        onClose={() => setIsTakeSurveyOpen(false)}
        survey={survey}
        onComplete={handleSurveyComplete}
      />

      <SurveyCompletedModal
        isOpen={isCompletedModalOpen}
        onClose={() => setIsCompletedModalOpen(false)}
        pointsAwarded={earnedPoints}
      />
    </>
  );
}
