import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { FeatherLogo } from "@/assets/feather-logo";
import { UserAvatar } from "@/components/ui/user-avatar";
import { 
  Home, 
  FileText, 
  BarChart2, 
  ShoppingBag, 
  HelpCircle, 
  Settings 
} from "lucide-react";
import { Button } from "@/components/ui/button";

export function Sidebar() {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-gray-200 bg-white h-screen sticky top-0">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <FeatherLogo className="w-10 h-10" />
          <h1 className="ml-2 text-xl font-bold text-gray-800">Feathers</h1>
        </div>
      </div>
      
      <nav className="flex-1 p-2 space-y-1 overflow-y-auto no-scrollbar">
        <Link href="/">
          <a className={`flex items-center px-4 py-3 rounded-lg ${isActive("/") 
            ? "text-gray-800 bg-primary-50" 
            : "text-gray-600 hover:bg-gray-100"}`}>
            <Home className="h-5 w-5 mr-3 text-primary" />
            <span className="font-medium">Home</span>
          </a>
        </Link>
        <Link href="/my-surveys">
          <a className={`flex items-center px-4 py-3 rounded-lg ${isActive("/my-surveys") 
            ? "text-gray-800 bg-primary-50" 
            : "text-gray-600 hover:bg-gray-100"}`}>
            <FileText className="h-5 w-5 mr-3 text-gray-500" />
            <span className="font-medium">My Surveys</span>
          </a>
        </Link>
        <Link href="/analytics">
          <a className={`flex items-center px-4 py-3 rounded-lg ${isActive("/analytics") 
            ? "text-gray-800 bg-primary-50" 
            : "text-gray-600 hover:bg-gray-100"}`}>
            <BarChart2 className="h-5 w-5 mr-3 text-gray-500" />
            <span className="font-medium">Analytics</span>
          </a>
        </Link>
        <Link href="/wallet">
          <a className={`flex items-center px-4 py-3 rounded-lg ${isActive("/wallet") 
            ? "text-gray-800 bg-primary-50" 
            : "text-gray-600 hover:bg-gray-100"}`}>
            <ShoppingBag className="h-5 w-5 mr-3 text-gray-500" />
            <span className="font-medium">Wallet</span>
            <span className="ml-auto bg-primary-100 text-primary-800 text-xs font-semibold px-2 py-1 rounded-full">
              {user?.points || 0} pts
            </span>
          </a>
        </Link>
        <Link href="/help">
          <a className={`flex items-center px-4 py-3 rounded-lg ${isActive("/help") 
            ? "text-gray-800 bg-primary-50" 
            : "text-gray-600 hover:bg-gray-100"}`}>
            <HelpCircle className="h-5 w-5 mr-3 text-gray-500" />
            <span className="font-medium">Help</span>
          </a>
        </Link>
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center">
          <UserAvatar user={user} />
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-800">{user?.name}</p>
            <p className="text-xs text-gray-500">{user?.email}</p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="ml-auto p-1 rounded-full hover:bg-gray-100"
            onClick={handleLogout}
          >
            <Settings className="h-5 w-5 text-gray-500" />
          </Button>
        </div>
      </div>
    </aside>
  );
}
