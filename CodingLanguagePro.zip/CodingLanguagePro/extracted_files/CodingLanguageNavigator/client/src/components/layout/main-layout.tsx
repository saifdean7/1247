import { ReactNode, useState } from "react";
import { Sidebar } from "./sidebar";
import { MobileNav } from "./mobile-nav";
import { SurveyCreatorModal } from "../surveys/survey-creator-modal";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [isSurveyCreatorOpen, setIsSurveyCreatorOpen] = useState(false);

  const handleOpenSurveyCreator = () => {
    setIsSurveyCreatorOpen(true);
  };

  const handleCloseSurveyCreator = () => {
    setIsSurveyCreatorOpen(false);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col relative">
        <MobileNav onCreateSurvey={handleOpenSurveyCreator} />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-20 md:pb-6">
          {children}
        </main>
      </div>

      <SurveyCreatorModal 
        isOpen={isSurveyCreatorOpen}
        onClose={handleCloseSurveyCreator}
      />
    </div>
  );
}
