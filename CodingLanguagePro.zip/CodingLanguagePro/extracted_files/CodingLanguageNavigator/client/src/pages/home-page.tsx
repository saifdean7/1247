import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { SurveyCard } from "@/components/surveys/survey-card";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { SurveyCreatorModal } from "@/components/surveys/survey-creator-modal";
import { useAuth } from "@/hooks/use-auth";
import { SurveyWithCreator } from "@/lib/types";
import { FeedTab } from "@/lib/types";

export default function HomePage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<FeedTab>("forYou");
  const [isSurveyCreatorOpen, setIsSurveyCreatorOpen] = useState(false);

  // Fetch surveys
  const { data: surveys, isLoading, refetch } = useQuery<SurveyWithCreator[]>({
    queryKey: ["/api/surveys"],
  });

  // Filter surveys based on active tab
  const filteredSurveys = surveys 
    ? surveys.filter(survey => {
        if (activeTab === "forYou") return true;
        if (activeTab === "popular") return survey.responseCount > 50;
        if (activeTab === "following") return false; // Not implemented yet
        if (activeTab === "recent") {
          // Show surveys created in the last 3 days
          const threeDaysAgo = new Date();
          threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
          return new Date(survey.createdAt) > threeDaysAgo;
        }
        return true;
      })
    : [];

  return (
    <MainLayout>
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Welcome back, {user?.name.split(' ')[0]}!</h1>
        <p className="text-gray-600">Discover surveys made for you or create your own.</p>
      </div>

      {/* Create Survey Button */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Your Feed</h2>
        <Button 
          onClick={() => setIsSurveyCreatorOpen(true)}
          className="bg-primary-500 hover:bg-primary-600 text-white transition duration-200"
        >
          <PlusCircle className="h-5 w-5 mr-2" />
          Create Survey
        </Button>
      </div>

      {/* Feed Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <a 
            href="#" 
            className={`whitespace-nowrap pb-3 px-1 border-b-2 font-medium text-sm ${
              activeTab === "forYou" 
                ? "border-primary-500 text-primary-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={(e) => { e.preventDefault(); setActiveTab("forYou"); }}
          >
            For You
          </a>
          <a 
            href="#" 
            className={`whitespace-nowrap pb-3 px-1 border-b-2 font-medium text-sm ${
              activeTab === "popular" 
                ? "border-primary-500 text-primary-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={(e) => { e.preventDefault(); setActiveTab("popular"); }}
          >
            Popular
          </a>
          <a 
            href="#" 
            className={`whitespace-nowrap pb-3 px-1 border-b-2 font-medium text-sm ${
              activeTab === "following" 
                ? "border-primary-500 text-primary-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={(e) => { e.preventDefault(); setActiveTab("following"); }}
          >
            Following
          </a>
          <a 
            href="#" 
            className={`whitespace-nowrap pb-3 px-1 border-b-2 font-medium text-sm ${
              activeTab === "recent" 
                ? "border-primary-500 text-primary-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={(e) => { e.preventDefault(); setActiveTab("recent"); }}
          >
            Recent
          </a>
        </nav>
      </div>

      {/* Survey Feed */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          // Loading skeleton
          Array(6).fill(0).map((_, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 animate-pulse">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                <div className="ml-3 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
              <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6 mb-4"></div>
              <div className="h-10 bg-gray-200 rounded w-full mb-4"></div>
              <div className="h-8 bg-gray-200 rounded w-full"></div>
            </div>
          ))
        ) : filteredSurveys.length > 0 ? (
          filteredSurveys.map((survey) => (
            <SurveyCard 
              key={survey.id} 
              survey={survey} 
              onSurveyCompleted={() => refetch()}
            />
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <h3 className="text-lg font-medium text-gray-700 mb-2">No surveys found</h3>
            <p className="text-gray-500 mb-4">There are no surveys matching your criteria right now.</p>
            <Button onClick={() => setIsSurveyCreatorOpen(true)}>
              Create Your First Survey
            </Button>
          </div>
        )}
      </div>

      <SurveyCreatorModal
        isOpen={isSurveyCreatorOpen}
        onClose={() => setIsSurveyCreatorOpen(false)}
      />
    </MainLayout>
  );
}
