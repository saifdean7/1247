import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Users, Clock, Calendar } from "lucide-react";
import { SurveyCreatorModal } from "@/components/surveys/survey-creator-modal";
import { SurveyWithCreator } from "@/lib/types";
import { format } from "date-fns";

export default function MySurveysPage() {
  const [isSurveyCreatorOpen, setIsSurveyCreatorOpen] = useState(false);

  // Fetch user surveys
  const { data: surveys, isLoading } = useQuery<SurveyWithCreator[]>({
    queryKey: ["/api/surveys/user"],
  });

  return (
    <MainLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">My Surveys</h1>
        <Button 
          onClick={() => setIsSurveyCreatorOpen(true)}
          className="bg-primary-500 hover:bg-primary-600 text-white transition duration-200"
        >
          <PlusCircle className="h-5 w-5 mr-2" />
          Create Survey
        </Button>
      </div>

      {isLoading ? (
        // Loading skeleton
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Array(4).fill(0).map((_, index) => (
            <Card key={index} className="animate-pulse">
              <CardHeader>
                <div className="h-6 bg-gray-200 rounded w-2/3 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-full"></div>
                  <div className="h-4 bg-gray-200 rounded w-5/6"></div>
                  <div className="h-4 bg-gray-200 rounded w-4/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : surveys && surveys.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {surveys.map((survey) => (
            <Card key={survey.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle>{survey.title}</CardTitle>
                <p className="text-sm text-gray-500">
                  {survey.category.charAt(0).toUpperCase() + survey.category.slice(1)}
                </p>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-gray-700">{survey.description}</p>
                <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>{survey.responseCount} responses</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{survey.estimatedTime}</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{format(new Date(survey.createdAt), 'MMM d, yyyy')}</span>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button size="sm" variant="outline">View Results</Button>
                  <Button size="sm" variant="outline">Share</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border border-dashed border-gray-300 rounded-lg bg-gray-50">
          <h3 className="text-lg font-medium text-gray-700 mb-2">No surveys yet</h3>
          <p className="text-gray-500 mb-4">You haven't created any surveys yet. Get started by creating your first survey!</p>
          <Button onClick={() => setIsSurveyCreatorOpen(true)}>
            Create Your First Survey
          </Button>
        </div>
      )}

      <SurveyCreatorModal
        isOpen={isSurveyCreatorOpen}
        onClose={() => setIsSurveyCreatorOpen(false)}
      />
    </MainLayout>
  );
}
