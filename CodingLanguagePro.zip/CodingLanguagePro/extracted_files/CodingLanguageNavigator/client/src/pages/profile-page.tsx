import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MainLayout } from "@/components/layout/main-layout";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  Settings, 
  Award, 
  FileText, 
  Lock, 
  Bell, 
  Shield, 
  LogOut 
} from "lucide-react";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  
  const [profileData, setProfileData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    bio: user?.bio || "",
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      // This would be connected to a real API endpoint in a production app
      const res = await apiRequest("PATCH", "/api/user/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleProfileUpdate = () => {
    updateProfileMutation.mutate(profileData);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Achievements are hardcoded for the MVP
  const achievements = [
    { id: 1, name: "Survey Pioneer", description: "Created your first survey", icon: "🏆" },
    { id: 2, name: "Feedback Maven", description: "Completed 10 surveys", icon: "🌟" },
    { id: 3, name: "Streak Master", description: "Maintained a 7-day login streak", icon: "🔥" },
    { id: 4, name: "Question Guru", description: "Used all question types in a survey", icon: "🧠" },
  ];
  
  return (
    <MainLayout>
      <div className="flex flex-col gap-6">
        <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Summary Card */}
          <Card className="lg:col-span-1">
            <CardContent className="pt-6 flex flex-col items-center">
              <UserAvatar user={user} className="h-24 w-24 mb-4" />
              <h2 className="text-xl font-bold text-center">{user?.name}</h2>
              <p className="text-gray-500 text-center mb-4">{user?.username}</p>
              
              <div className="flex items-center justify-center space-x-2 mb-6">
                <Badge variant="outline" className="bg-primary-50 text-primary-700 hover:bg-primary-100">
                  {user?.points} points
                </Badge>
                <Badge variant="outline" className="bg-gray-50 text-gray-700 hover:bg-gray-100">
                  Survey Creator
                </Badge>
              </div>
              
              <Separator className="mb-4" />
              
              <div className="w-full space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Surveys Created</span>
                  <span className="text-sm font-medium">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Surveys Completed</span>
                  <span className="text-sm font-medium">48</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Points Earned</span>
                  <span className="text-sm font-medium">{user?.points}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Login Streak</span>
                  <span className="text-sm font-medium">5 days</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Main Content Tabs */}
          <Card className="lg:col-span-2">
            <CardContent className="pt-6">
              <Tabs defaultValue="profile" className="w-full">
                <TabsList className="grid grid-cols-3 mb-6">
                  <TabsTrigger value="profile">
                    <User className="h-4 w-4 mr-2" /> Profile
                  </TabsTrigger>
                  <TabsTrigger value="achievements">
                    <Award className="h-4 w-4 mr-2" /> Achievements
                  </TabsTrigger>
                  <TabsTrigger value="settings">
                    <Settings className="h-4 w-4 mr-2" /> Settings
                  </TabsTrigger>
                </TabsList>
                
                {/* Profile Tab */}
                <TabsContent value="profile" className="space-y-4">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input 
                          id="name"
                          name="name"
                          value={profileData.name}
                          onChange={handleInputChange}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <Input 
                          id="email"
                          name="email"
                          type="email"
                          value={profileData.email}
                          onChange={handleInputChange}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea 
                          id="bio"
                          name="bio"
                          value={profileData.bio}
                          onChange={handleInputChange}
                          placeholder="Tell us about yourself..."
                          className="mt-1"
                          rows={4}
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handleProfileUpdate}
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                </TabsContent>
                
                {/* Achievements Tab */}
                <TabsContent value="achievements" className="space-y-4">
                  <div className="space-y-4">
                    {achievements.map((achievement) => (
                      <div key={achievement.id} className="flex items-start p-3 bg-gray-50 rounded-lg">
                        <div className="text-2xl mr-3">{achievement.icon}</div>
                        <div>
                          <h3 className="font-medium">{achievement.name}</h3>
                          <p className="text-sm text-gray-600">{achievement.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Settings Tab */}
                <TabsContent value="settings" className="space-y-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-gray-500" />
                        Account Settings
                      </h3>
                      <div className="mt-3 space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          <User className="h-4 w-4 mr-2" />
                          Edit Username
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          <Lock className="h-4 w-4 mr-2" />
                          Change Password
                        </Button>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium flex items-center">
                        <Bell className="h-5 w-5 mr-2 text-gray-500" />
                        Notification Preferences
                      </h3>
                      <div className="mt-3 space-y-2">
                        <div className="flex items-center">
                          <input type="checkbox" id="email-notif" defaultChecked className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                          <label htmlFor="email-notif" className="ml-2 block text-sm text-gray-700">Email Notifications</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="survey-notif" defaultChecked className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                          <label htmlFor="survey-notif" className="ml-2 block text-sm text-gray-700">New Survey Recommendations</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="response-notif" defaultChecked className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                          <label htmlFor="response-notif" className="ml-2 block text-sm text-gray-700">Survey Response Notifications</label>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium flex items-center">
                        <Shield className="h-5 w-5 mr-2 text-gray-500" />
                        Privacy & Data
                      </h3>
                      <div className="mt-3 space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          Privacy Settings
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          Download My Data
                        </Button>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <Button 
                      variant="destructive" 
                      className="w-full"
                      onClick={handleLogout}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
