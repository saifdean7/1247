import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Coins, 
  BarChart3, 
  TrendingUp,
  Award,
  Calendar,
  Gift,
  Clock
} from "lucide-react";
import { format } from "date-fns";

// Mock transactions for demonstration
const recentTransactions = [
  { id: 1, type: 'earned', amount: 25, description: 'Completed "Work-life balance" survey', date: new Date(2023, 6, 15) },
  { id: 2, type: 'earned', amount: 15, description: 'Completed "Social media habits" survey', date: new Date(2023, 6, 14) },
  { id: 3, type: 'spent', amount: 50, description: 'Boosted "Streaming service preferences" survey', date: new Date(2023, 6, 12) },
  { id: 4, type: 'earned', amount: 5, description: 'Daily login streak bonus', date: new Date(2023, 6, 11) },
  { id: 5, type: 'earned', amount: 30, description: 'Completed "Customer satisfaction" survey', date: new Date(2023, 6, 10) },
];

export default function WalletPage() {
  const { user } = useAuth();
  
  return (
    <MainLayout>
      <div className="flex flex-col gap-6">
        <h1 className="text-2xl font-bold text-gray-900">Your Wallet</h1>
        
        {/* Balance Card */}
        <Card className="bg-primary-50 border-primary-100">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:justify-between gap-4">
              <div>
                <p className="text-primary-800 text-sm font-medium">Current Balance</p>
                <h2 className="text-4xl font-bold text-primary-900 mt-1">{user?.points || 0} pts</h2>
                <p className="text-primary-700 text-sm mt-1">Last activity: {format(new Date(), 'MMMM d, yyyy')}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="bg-white">
                  <ArrowUpRight className="mr-2 h-4 w-4" />
                  Spend Points
                </Button>
                <Button>
                  <Coins className="mr-2 h-4 w-4" />
                  Earn More
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Tabs Content */}
        <Tabs defaultValue="transactions" className="space-y-4">
          <TabsList>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="earning">Earning Options</TabsTrigger>
            <TabsTrigger value="spending">Spending Options</TabsTrigger>
          </TabsList>
          
          {/* Transactions Tab */}
          <TabsContent value="transactions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Your point activity over the past 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between border-b border-gray-100 pb-4">
                      <div className="flex items-center">
                        <div className={`rounded-full p-2 ${transaction.type === 'earned' ? 'bg-green-100' : 'bg-red-100'} mr-3`}>
                          {transaction.type === 'earned' ? (
                            <ArrowUpRight className={`h-4 w-4 ${transaction.type === 'earned' ? 'text-green-600' : 'text-red-600'}`} />
                          ) : (
                            <ArrowDownRight className={`h-4 w-4 ${transaction.type === 'earned' ? 'text-green-600' : 'text-red-600'}`} />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{transaction.description}</p>
                          <p className="text-sm text-gray-500">{format(transaction.date, 'MMM d, yyyy')}</p>
                        </div>
                      </div>
                      <span className={`font-medium ${transaction.type === 'earned' ? 'text-green-600' : 'text-red-600'}`}>
                        {transaction.type === 'earned' ? '+' : '-'}{transaction.amount} pts
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">View All Transactions</Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Points Overview</CardTitle>
                <CardDescription>Your points activity summary</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center">
                      <div className="bg-primary-100 p-2 rounded-full mr-3">
                        <BarChart3 className="h-5 w-5 text-primary-700" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Total Earned</p>
                        <p className="text-xl font-bold text-gray-900">325 pts</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center">
                      <div className="bg-primary-100 p-2 rounded-full mr-3">
                        <TrendingUp className="h-5 w-5 text-primary-700" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Total Spent</p>
                        <p className="text-xl font-bold text-gray-900">150 pts</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center">
                      <div className="bg-primary-100 p-2 rounded-full mr-3">
                        <Award className="h-5 w-5 text-primary-700" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Streak Bonus</p>
                        <p className="text-xl font-bold text-gray-900">5 days</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Earning Options Tab */}
          <TabsContent value="earning" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <Gift className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Complete Surveys</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Earn points by participating in surveys. More complex surveys offer higher rewards.</p>
                  <p className="font-medium text-primary-600">5-50 pts per survey</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">Browse Surveys</Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Daily Login</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Log in daily to maintain your streak and earn bonus points for consistent participation.</p>
                  <p className="font-medium text-primary-600">5 pts per day</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" disabled>Claimed Today</Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <Award className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Referral Bonus</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Invite friends to join Feathers and earn points when they complete their first survey.</p>
                  <p className="font-medium text-primary-600">50 pts per referral</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">Invite Friends</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
          
          {/* Spending Options Tab */}
          <TabsContent value="spending" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Boost Survey</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Promote your survey to get more responses faster by featuring it at the top of users' feeds.</p>
                  <p className="font-medium text-primary-600">Cost: 50-200 pts</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">Boost a Survey</Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <Gift className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Premium Templates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Access exclusive, professionally designed survey templates with advanced features.</p>
                  <p className="font-medium text-primary-600">Cost: 100 pts each</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">Browse Templates</Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="rounded-full w-10 h-10 bg-primary-100 text-primary-600 flex items-center justify-center">
                    <Clock className="h-5 w-5" />
                  </div>
                  <CardTitle className="mt-3">Extended Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-2">Unlock detailed analytics and demographic insights for your survey responses.</p>
                  <p className="font-medium text-primary-600">Cost: 75 pts per survey</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">Upgrade Analytics</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
