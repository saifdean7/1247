import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertSurveySchema, insertResponseSchema, surveyResponseSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Survey routes
  app.post("/api/surveys", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.user!.id;
      const surveyData = insertSurveySchema.parse({
        ...req.body,
        creatorId: userId
      });
      
      const newSurvey = await storage.createSurvey(surveyData);
      res.status(201).json(newSurvey);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid survey data", errors: err.errors });
      }
      next(err);
    }
  });

  app.get("/api/surveys", async (req, res, next) => {
    try {
      const surveys = await storage.getSurveys();
      
      // Attach creator info to each survey
      const surveysWithCreator = await Promise.all(
        surveys.map(async (survey) => {
          const creator = await storage.getUser(survey.creatorId);
          
          // Don't expose sensitive user data
          const { password, ...creatorInfo } = creator || { 
            password: '', 
            id: 0, 
            name: 'Unknown', 
            username: 'unknown',
            email: '',
            bio: '',
            profileImage: '',
            points: 0
          };
          
          // Calculate response count
          const responses = await storage.getSurveyResponses(survey.id);
          
          return {
            ...survey,
            creator: creatorInfo,
            responseCount: responses.length
          };
        })
      );
      
      res.json(surveysWithCreator);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/surveys/user", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.user!.id;
      const surveys = await storage.getUserSurveys(userId);
      
      // Calculate response count for each survey
      const surveysWithStats = await Promise.all(
        surveys.map(async (survey) => {
          const responses = await storage.getSurveyResponses(survey.id);
          return {
            ...survey,
            responseCount: responses.length
          };
        })
      );
      
      res.json(surveysWithStats);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/surveys/:id", async (req, res, next) => {
    try {
      const surveyId = parseInt(req.params.id);
      if (isNaN(surveyId)) {
        return res.status(400).json({ message: "Invalid survey ID" });
      }

      const survey = await storage.getSurvey(surveyId);
      if (!survey) {
        return res.status(404).json({ message: "Survey not found" });
      }

      const creator = await storage.getUser(survey.creatorId);
      if (!creator) {
        return res.status(404).json({ message: "Survey creator not found" });
      }

      // Don't expose sensitive user data
      const { password, ...creatorInfo } = creator;
      
      // Get response count
      const responses = await storage.getSurveyResponses(surveyId);
      
      res.json({
        ...survey,
        creator: creatorInfo,
        responseCount: responses.length
      });
    } catch (err) {
      next(err);
    }
  });

  // Survey response routes
  app.post("/api/surveys/:id/responses", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const surveyId = parseInt(req.params.id);
      if (isNaN(surveyId)) {
        return res.status(400).json({ message: "Invalid survey ID" });
      }

      const userId = req.user!.id;
      
      // Verify survey exists
      const survey = await storage.getSurvey(surveyId);
      if (!survey) {
        return res.status(404).json({ message: "Survey not found" });
      }
      
      // Validate responses
      const responseData = insertResponseSchema.parse({
        surveyId,
        userId,
        answers: req.body.answers
      });
      
      // Save the response
      const response = await storage.createResponse(responseData);
      
      // Award points to the user
      const updatedUser = await storage.updateUserPoints(userId, survey.rewardPoints);
      
      // Return response with updated user data
      const { password, ...userWithoutPassword } = updatedUser || {};
      
      res.status(201).json({
        response,
        user: userWithoutPassword,
        pointsAwarded: survey.rewardPoints
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid response data", errors: err.errors });
      }
      next(err);
    }
  });
  
  app.get("/api/surveys/:id/responses", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const surveyId = parseInt(req.params.id);
      if (isNaN(surveyId)) {
        return res.status(400).json({ message: "Invalid survey ID" });
      }
      
      // Check if user is survey creator
      const survey = await storage.getSurvey(surveyId);
      if (!survey) {
        return res.status(404).json({ message: "Survey not found" });
      }
      
      if (survey.creatorId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to view these responses" });
      }
      
      const responses = await storage.getSurveyResponses(surveyId);
      
      // Attach respondent info to each response
      const responsesWithUser = await Promise.all(
        responses.map(async (response) => {
          const user = await storage.getUser(response.userId);
          // Don't expose sensitive user data
          const { password, ...userInfo } = user || { 
            password: '', 
            id: 0, 
            name: 'Unknown', 
            username: 'unknown',
            email: '',
            bio: '',
            profileImage: '',
            points: 0
          };
          
          return {
            ...response,
            user: userInfo
          };
        })
      );
      
      res.json(responsesWithUser);
    } catch (err) {
      next(err);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
