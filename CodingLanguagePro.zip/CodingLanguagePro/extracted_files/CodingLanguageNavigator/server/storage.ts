import { users, surveys, responses, type User, type InsertUser, type Survey, type InsertSurvey, type Response, type InsertResponse } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User | undefined>;
  
  // Survey operations
  createSurvey(survey: InsertSurvey): Promise<Survey>;
  getSurvey(id: number): Promise<Survey | undefined>;
  getSurveys(): Promise<Survey[]>;
  getUserSurveys(userId: number): Promise<Survey[]>;
  
  // Response operations
  createResponse(response: InsertResponse): Promise<Response>;
  getSurveyResponses(surveyId: number): Promise<Response[]>;
  getUserResponses(userId: number): Promise<Response[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private surveys: Map<number, Survey>;
  private responses: Map<number, Response>;
  sessionStore: session.SessionStore;
  private userIdCounter: number;
  private surveyIdCounter: number;
  private responseIdCounter: number;

  constructor() {
    this.users = new Map();
    this.surveys = new Map();
    this.responses = new Map();
    this.userIdCounter = 1;
    this.surveyIdCounter = 1;
    this.responseIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...userData, 
      id, 
      bio: "",
      profileImage: "",
      points: 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      points: user.points + points 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Survey methods
  async createSurvey(surveyData: InsertSurvey): Promise<Survey> {
    const id = this.surveyIdCounter++;
    const survey: Survey = {
      ...surveyData,
      id,
      createdAt: new Date(),
    };
    this.surveys.set(id, survey);
    return survey;
  }

  async getSurvey(id: number): Promise<Survey | undefined> {
    return this.surveys.get(id);
  }

  async getSurveys(): Promise<Survey[]> {
    return Array.from(this.surveys.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getUserSurveys(userId: number): Promise<Survey[]> {
    return Array.from(this.surveys.values())
      .filter((survey) => survey.creatorId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Response methods
  async createResponse(responseData: InsertResponse): Promise<Response> {
    const id = this.responseIdCounter++;
    const response: Response = {
      ...responseData,
      id,
      createdAt: new Date(),
    };
    this.responses.set(id, response);
    return response;
  }

  async getSurveyResponses(surveyId: number): Promise<Response[]> {
    return Array.from(this.responses.values())
      .filter((response) => response.surveyId === surveyId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUserResponses(userId: number): Promise<Response[]> {
    return Array.from(this.responses.values())
      .filter((response) => response.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();
