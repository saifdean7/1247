import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  bio: text("bio").default(""),
  profileImage: text("profile_image").default(""),
  points: integer("points").default(0).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
});

// Survey schema
export const surveys = pgTable("surveys", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  estimatedTime: text("estimated_time").notNull(),
  rewardPoints: integer("reward_points").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  questions: json("questions").notNull(),
});

export const insertSurveySchema = createInsertSchema(surveys).omit({
  id: true,
  createdAt: true,
});

// Response schema
export const responses = pgTable("responses", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id").notNull(),
  userId: integer("user_id").notNull(),
  answers: json("answers").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResponseSchema = createInsertSchema(responses).omit({
  id: true,
  createdAt: true,
});

// Question types enum
export const QuestionType = z.enum([
  "MULTIPLE_CHOICE_SINGLE",
  "MULTIPLE_CHOICE_MULTIPLE",
  "OPEN_TEXT",
  "RATING_SCALE",
  "SLIDER",
]);

// Question schema for frontend type safety
export const questionSchema = z.object({
  id: z.string(),
  text: z.string(),
  type: QuestionType,
  options: z.array(z.string()).optional(),
  isRequired: z.boolean().default(false),
});

// Survey schema with questions array
export const surveyWithQuestionsSchema = insertSurveySchema.extend({
  questions: z.array(questionSchema),
});

// Survey response schema
export const surveyResponseSchema = z.object({
  questionId: z.string(),
  answer: z.union([z.string(), z.array(z.string()), z.number()]),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Survey = typeof surveys.$inferSelect;
export type InsertSurvey = z.infer<typeof insertSurveySchema>;
export type Response = typeof responses.$inferSelect;
export type InsertResponse = z.infer<typeof insertResponseSchema>;
export type QuestionType = z.infer<typeof QuestionType>;
export type Question = z.infer<typeof questionSchema>;
export type SurveyWithQuestions = z.infer<typeof surveyWithQuestionsSchema>;
export type SurveyResponse = z.infer<typeof surveyResponseSchema>;
