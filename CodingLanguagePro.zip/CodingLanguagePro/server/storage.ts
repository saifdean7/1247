import { 
  users, type User, type InsertUser,
  surveys, type Survey, type InsertSurvey,
  activities, type Activity, type InsertActivity,
  achievements, type Achievement, type InsertAchievement,
  walletTransactions, type WalletTransaction, type InsertWalletTransaction,
  posts, type Post, type InsertPost,
  comments, type Comment, type InsertComment,
  likes, type Like, type InsertLike,
  follows, type Follow, type InsertFollow, 
  surveyResponses, type SurveyResponse, type InsertSurveyResponse
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Survey operations
  getSurvey(id: number): Promise<Survey | undefined>;
  getSurveysByUserId(userId: number): Promise<Survey[]>;
  getSurveysForFeed(excludeUserId?: number, limit?: number): Promise<Survey[]>;
  createSurvey(survey: InsertSurvey): Promise<Survey>;
  updateSurvey(id: number, data: Partial<Survey>): Promise<Survey | undefined>;
  deleteSurvey(id: number): Promise<boolean>;
  
  // Survey Response operations
  getSurveyResponsesByUserId(userId: number): Promise<SurveyResponse[]>;
  getSurveyResponsesBySurveyId(surveyId: number): Promise<SurveyResponse[]>;
  createSurveyResponse(response: InsertSurveyResponse): Promise<SurveyResponse>;
  hasUserRespondedToSurvey(userId: number, surveyId: number): Promise<boolean>;
  
  // Activity operations
  getActivitiesByUserId(userId: number, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Achievement operations
  getAchievementsByUserId(userId: number): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  updateAchievement(id: number, data: Partial<Achievement>): Promise<Achievement | undefined>;
  
  // Wallet operations
  getWalletTransactionsByUserId(userId: number): Promise<WalletTransaction[]>;
  createWalletTransaction(transaction: InsertWalletTransaction): Promise<WalletTransaction>;
  getWalletBalance(userId: number): Promise<number>;
  
  // Social operations (posts, comments, likes)
  getPost(id: number): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number): Promise<Post[]>;
  getPostsByUserId(userId: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, data: Partial<Post>): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;
  
  // Comment operations
  getCommentsByPostId(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: number): Promise<boolean>;
  
  // Like operations
  getLikesByPostId(postId: number): Promise<Like[]>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(userId: number, postId: number): Promise<boolean>;
  isLikedByUser(userId: number, postId: number): Promise<boolean>;
  
  // Follow operations
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;
  getFollowersCount(userId: number): Promise<number>;
  getFollowingCount(userId: number): Promise<number>;
  createFollow(follow: InsertFollow): Promise<Follow>;
  deleteFollow(followerId: number, followingId: number): Promise<boolean>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private surveys: Map<number, Survey>;
  private activities: Map<number, Activity>;
  private achievements: Map<number, Achievement>;
  private walletTransactions: Map<number, WalletTransaction>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private likes: Map<number, Like>;
  private follows: Map<number, Follow>;
  private surveyResponses: Map<number, SurveyResponse>;
  
  private userIdCounter: number;
  private surveyIdCounter: number;
  private activityIdCounter: number;
  private achievementIdCounter: number;
  private transactionIdCounter: number;
  private postIdCounter: number;
  private commentIdCounter: number;
  private likeIdCounter: number;
  private followIdCounter: number;
  private surveyResponseIdCounter: number;

  constructor() {
    this.users = new Map();
    this.surveys = new Map();
    this.activities = new Map();
    this.achievements = new Map();
    this.walletTransactions = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.follows = new Map();
    this.surveyResponses = new Map();
    
    this.userIdCounter = 1;
    this.surveyIdCounter = 1;
    this.activityIdCounter = 1;
    this.achievementIdCounter = 1;
    this.transactionIdCounter = 1;
    this.postIdCounter = 1;
    this.commentIdCounter = 1;
    this.likeIdCounter = 1;
    this.followIdCounter = 1;
    this.surveyResponseIdCounter = 1;
    
    // Add demo users
    const demoUserPromise = this.createUser({
      username: "demo",
      password: "demo123",
      displayName: "Saif",
      title: "Survey Creator & Analyst",
      bio: "Survey enthusiast and data analyst with over 5 years of experience in market research. I specialize in creating engaging surveys that generate meaningful insights for businesses and organizations.",
      profileImageUrl: "/assets/saif_profile.jpg",
      coverImageUrl: "",
    }).then(user => {
      // Add some demo wallet transactions
      const now = new Date();
      
      // Transaction 1 - 90 days ago
      const date1 = new Date(now);
      date1.setDate(now.getDate() - 90);
      this.createWalletTransaction({
        userId: user.id,
        amount: 12500, // $125.00
        description: "Survey completion payout: Customer Experience Survey",
        type: "payout"
      });
      
      // Transaction 2 - 60 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: 8750, // $87.50
          description: "Survey completion payout: Product Research Survey",
          type: "payout"
        });
      }, 100);
      
      // Transaction 3 - 45 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: -5000, // -$50.00
          description: "Withdrawal to bank account",
          type: "withdrawal"
        });
      }, 200);
      
      // Transaction 4 - 30 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: 6800, // $68.00
          description: "Survey completion payout: Market Analysis Survey",
          type: "payout"
        });
      }, 300);
      
      // Transaction 5 - 15 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: 3000, // $30.00
          description: "Referral bonus: New user signup",
          type: "referral"
        });
      }, 400);
      
      // Transaction 6 - 5 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: -7500, // -$75.00
          description: "Withdrawal to PayPal",
          type: "withdrawal"
        });
      }, 500);
      
      // Transaction 7 - 2 days ago
      setTimeout(() => {
        this.createWalletTransaction({
          userId: user.id,
          amount: 9250, // $92.50
          description: "Survey completion payout: User Interface Feedback",
          type: "payout"
        });
      }, 600);
      
      // Create demo posts
      setTimeout(() => {
        // Post 1 - Survey share
        this.createPost({
          userId: user.id,
          title: "Customer Experience Survey Results",
          content: "Just completed my latest customer experience survey with over 500 responses! The insights are fascinating - 78% of users prefer our new interface design. Check out the full report on my profile.",
          type: "survey",
          imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
        }).then(post => {
          // Add some comments to this post
          setTimeout(() => {
            this.createComment({
              userId: user.id,
              postId: post.id,
              content: "I'd love to hear more about the demographic breakdown of your respondents. Was there any correlation between age groups and interface preferences?"
            });
          }, 100);
          
          setTimeout(() => {
            this.createComment({
              userId: user.id,
              postId: post.id,
              content: "Great work! The insights from this survey will be really helpful for our upcoming product launch."
            });
          }, 200);
          
          // Add a like
          setTimeout(() => {
            this.createLike({
              userId: user.id,
              postId: post.id
            });
          }, 300);
        });
        
        // Post 2 - Tips
        setTimeout(() => {
          this.createPost({
            userId: user.id,
            title: "5 Tips for Better Survey Response Rates",
            content: "After years of creating surveys, I've learned a few tricks to boost response rates: 1) Keep it short, 2) Use clear language, 3) Offer incentives, 4) Mobile-friendly design, 5) Send reminders. What strategies have worked for you?",
            type: "article",
            imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
          }).then(post => {
            // Add a comment
            setTimeout(() => {
              this.createComment({
                userId: user.id,
                postId: post.id,
                content: "I've found that personalizing the invitation email significantly increases participation. Adding the recipient's name and referencing previous interactions makes a big difference."
              });
            }, 100);
            
            // Add likes
            setTimeout(() => {
              this.createLike({
                userId: user.id,
                postId: post.id
              });
            }, 200);
          });
        }, 700);
        
        // Post 3 - News
        setTimeout(() => {
          this.createPost({
            userId: user.id,
            title: "New Feature Release: AI-Powered Question Suggestions",
            content: "Excited to announce that our platform now offers AI-powered question suggestions! This new feature analyzes your survey goals and automatically recommends relevant questions to include. Initial tests show a 40% reduction in survey creation time.",
            type: "news",
            imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
          }).then(post => {
            // Add comments
            setTimeout(() => {
              this.createComment({
                userId: user.id,
                postId: post.id,
                content: "This is exactly what I've been waiting for! Can't wait to try it out on my next project."
              });
            }, 100);
            
            setTimeout(() => {
              this.createComment({
                userId: user.id,
                postId: post.id,
                content: "Will this feature be available on all account tiers or just premium?"
              });
            }, 200);
            
            setTimeout(() => {
              this.createComment({
                userId: user.id,
                postId: post.id,
                content: "It's available on all account tiers with a limit of 10 AI suggestions per month for free accounts, and unlimited for premium accounts."
              });
            }, 300);
            
            // Add likes
            setTimeout(() => {
              this.createLike({
                userId: user.id,
                postId: post.id
              });
            }, 400);
          });
        }, 1400);
      }, 700);
    });

    // Add more demo users for follow functionality
    const marketingUserPromise = this.createUser({
      username: "alex",
      password: "alex123",
      displayName: "Alex Rodriguez",
      title: "Marketing Specialist",
      bio: "Market research professional specializing in consumer insights. I create targeted surveys to help businesses understand their customers better and make data-driven decisions.",
      profileImageUrl: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      coverImageUrl: ""
    }).then(user => {
      // Create a sample survey
      setTimeout(() => {
        this.createSurvey({
          userId: user.id,
          title: "Customer Satisfaction Survey",
          status: "published",
          description: "Help us improve our service by providing your feedback",
          questions: JSON.stringify([
            {
              id: "q1",
              type: "rating",
              title: "How would you rate our service overall?",
              required: true,
              minValue: 1,
              maxValue: 5
            },
            {
              id: "q2",
              type: "text",
              title: "What could we improve?",
              required: false,
              placeholder: "Your suggestions..."
            }
          ])
        });
      }, 100);

      // Create a post
      setTimeout(() => {
        this.createPost({
          userId: user.id,
          title: "Looking for Survey Participants",
          content: "I'm conducting market research on fitness app preferences. If you're interested in participating, please check out my latest survey. Participants will receive a $10 gift card!",
          type: "announcement",
          imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
        });
      }, 300);
    });
    
    const designUserPromise = this.createUser({
      username: "maya",
      password: "maya123",
      displayName: "Maya Chen",
      title: "UX Researcher",
      bio: "UX researcher focused on creating user-friendly digital experiences. I use surveys and user testing to identify pain points and design opportunities.",
      profileImageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      coverImageUrl: ""
    }).then(user => {
      // Create a sample survey
      setTimeout(() => {
        this.createSurvey({
          userId: user.id,
          title: "Website Usability Survey",
          status: "published",
          description: "Help us understand how we can improve our website experience",
          questions: JSON.stringify([
            {
              id: "q1",
              type: "multiple_choice",
              title: "How did you find our website?",
              required: true,
              options: ["Search engine", "Social media", "Friend referral", "Advertisement", "Other"]
            },
            {
              id: "q2",
              type: "rating",
              title: "How easy was it to navigate our website?",
              required: true,
              minValue: 1,
              maxValue: 5
            },
            {
              id: "q3",
              type: "text",
              title: "What feature would you like to see added to our website?",
              required: false
            }
          ])
        });
      }, 100);

      // Create a post
      setTimeout(() => {
        this.createPost({
          userId: user.id,
          title: "The Importance of User Testing",
          content: "User testing is crucial for identifying design flaws before launch. In my recent project, we discovered that 70% of users struggled with our checkout process, leading to a complete redesign that increased conversions by 25%.",
          type: "article",
          imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80"
        });
      }, 300);
    });

    // Create follow relationships using independent promises with proper error handling
    // Add a delay to ensure user objects are fully created
    setTimeout(() => {
      Promise.all([
        this.getUserByUsername("demo"),
        this.getUserByUsername("alex"),
        this.getUserByUsername("maya")
      ]).then(([demoUser, marketingUser, designUser]) => {
        if (demoUser && marketingUser && designUser) {
          // Demo user follows both
          setTimeout(() => {
            this.createFollow({
              followerId: demoUser.id,
              followingId: marketingUser.id
            });
          }, 100);

          setTimeout(() => {
            this.createFollow({
              followerId: demoUser.id,
              followingId: designUser.id
            });
          }, 200);

          // Marketing user follows demo user
          setTimeout(() => {
            this.createFollow({
              followerId: marketingUser.id,
              followingId: demoUser.id
            });
          }, 300);
        }
      }).catch(err => {
        console.error("Error creating follow relationships:", err);
      });
    }, 1000);

      // Create cross-user likes and comments
      setTimeout(() => {
        Promise.all([
          this.getUserByUsername("demo"),
          this.getUserByUsername("alex"),
          this.getUserByUsername("maya")
        ]).then(([demoUser, alexUser, mayaUser]) => {
          if (demoUser && alexUser && mayaUser) {
            // Get Maya's posts
            const mayaPosts = Array.from(this.posts.values())
              .filter(post => post.userId === mayaUser.id);

            if (mayaPosts.length > 0) {
              // Demo user likes Maya's post
              this.createLike({
                userId: demoUser.id,
                postId: mayaPosts[0].id
              });

              // Demo user comments on Maya's post
              this.createComment({
                userId: demoUser.id,
                postId: mayaPosts[0].id,
                content: "Great insights, Maya! I've been trying to implement more user testing in my own survey designs."
              });
            }

            // Get Alex's posts
            const alexPosts = Array.from(this.posts.values())
              .filter(post => post.userId === alexUser.id);

            if (alexPosts.length > 0) {
              // Maya likes Alex's post
              this.createLike({
                userId: mayaUser.id,
                postId: alexPosts[0].id
              });

              // Maya comments on Alex's post
              this.createComment({
                userId: mayaUser.id,
                postId: alexPosts[0].id,
                content: "I'd be interested in participating in your research, Alex. The UX perspective might add some valuable insights."
              });
            }
          }
        }).catch(err => {
          console.error("Error creating cross-user interactions:", err);
        });
      }, 2000);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      isVerified: false,
      tier: "Basic",
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    
    // Create some initial achievements for the user
    this.createAchievement({
      userId: id,
      type: "survey_creator",
      name: "Survey Master",
      description: "Created 25+ surveys",
      iconType: "star",
      progress: 0,
      maxProgress: 25,
      isCompleted: false
    });
    
    this.createAchievement({
      userId: id,
      type: "responder",
      name: "Top Contributor",
      description: "Completed 100+ surveys",
      iconType: "checkmark",
      progress: 0,
      maxProgress: 100,
      isCompleted: false
    });
    
    this.createAchievement({
      userId: id,
      type: "earner",
      name: "Elite Earner",
      description: "Earned over $250",
      iconType: "money",
      progress: 0,
      maxProgress: 250,
      isCompleted: false
    });
    
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Survey operations
  async getSurvey(id: number): Promise<Survey | undefined> {
    return this.surveys.get(id);
  }

  async getSurveysByUserId(userId: number): Promise<Survey[]> {
    return Array.from(this.surveys.values()).filter(
      (survey) => survey.userId === userId,
    );
  }

  async createSurvey(insertSurvey: InsertSurvey): Promise<Survey> {
    const id = this.surveyIdCounter++;
    const now = new Date();
    const survey: Survey = { 
      ...insertSurvey, 
      id,
      responseCount: 0,
      createdAt: now,
      updatedAt: now
    };
    this.surveys.set(id, survey);
    
    // Create an activity for this survey creation
    await this.createActivity({
      userId: insertSurvey.userId,
      type: "survey_created",
      description: `Created a new survey: "${insertSurvey.title}"`,
      data: { surveyId: id }
    });
    
    return survey;
  }

  async updateSurvey(id: number, data: Partial<Survey>): Promise<Survey | undefined> {
    const survey = await this.getSurvey(id);
    if (!survey) return undefined;
    
    const updatedSurvey = { ...survey, ...data, updatedAt: new Date() };
    this.surveys.set(id, updatedSurvey);
    return updatedSurvey;
  }

  async deleteSurvey(id: number): Promise<boolean> {
    return this.surveys.delete(id);
  }

  // Activity operations
  async getActivitiesByUserId(userId: number, limit = 10): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }

  // Achievement operations
  async getAchievementsByUserId(userId: number): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(
      (achievement) => achievement.userId === userId,
    );
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = this.achievementIdCounter++;
    const achievement: Achievement = { 
      ...insertAchievement, 
      id,
      unlockedAt: new Date()
    };
    this.achievements.set(id, achievement);
    return achievement;
  }

  async updateAchievement(id: number, data: Partial<Achievement>): Promise<Achievement | undefined> {
    const achievement = this.achievements.get(id);
    if (!achievement) return undefined;
    
    const updatedAchievement = { ...achievement, ...data };
    if (data.progress && data.progress >= achievement.maxProgress && !achievement.isCompleted) {
      updatedAchievement.isCompleted = true;
      updatedAchievement.unlockedAt = new Date();
      
      // Create an activity for this achievement completion
      this.createActivity({
        userId: achievement.userId,
        type: "achievement_unlocked",
        description: `Unlocked achievement: "${achievement.name}"`,
        data: { achievementId: id }
      });
    }
    
    this.achievements.set(id, updatedAchievement);
    return updatedAchievement;
  }

  // Wallet operations
  async getWalletTransactionsByUserId(userId: number): Promise<WalletTransaction[]> {
    return Array.from(this.walletTransactions.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createWalletTransaction(insertTransaction: InsertWalletTransaction): Promise<WalletTransaction> {
    const id = this.transactionIdCounter++;
    const transaction: WalletTransaction = { 
      ...insertTransaction, 
      id,
      createdAt: new Date()
    };
    this.walletTransactions.set(id, transaction);
    
    // Create an activity for this transaction
    if (insertTransaction.amount > 0) {
      await this.createActivity({
        userId: insertTransaction.userId,
        type: "payment_received",
        description: `Received payment: $${(insertTransaction.amount / 100).toFixed(2)} for ${insertTransaction.description}`,
        data: { transactionId: id }
      });
    }
    
    return transaction;
  }

  async getWalletBalance(userId: number): Promise<number> {
    const transactions = await this.getWalletTransactionsByUserId(userId);
    return transactions.reduce((total, transaction) => total + transaction.amount, 0);
  }
  
  // Post operations
  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }
  
  async getPosts(limit = 20, offset = 0): Promise<Post[]> {
    return Array.from(this.posts.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(offset, offset + limit);
  }
  
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.postIdCounter++;
    const now = new Date();
    const post: Post = {
      ...insertPost,
      id,
      likeCount: 0,
      commentCount: 0,
      shareCount: 0,
      createdAt: now,
      updatedAt: now
    };
    this.posts.set(id, post);
    
    // Create an activity for the post
    await this.createActivity({
      userId: insertPost.userId,
      type: "post_created",
      description: `Created a new ${insertPost.type} post: "${insertPost.title}"`,
      data: { postId: id }
    });
    
    return post;
  }
  
  async updatePost(id: number, data: Partial<Post>): Promise<Post | undefined> {
    const post = await this.getPost(id);
    if (!post) return undefined;
    
    const updatedPost = { ...post, ...data, updatedAt: new Date() };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }
  
  async deletePost(id: number): Promise<boolean> {
    // Also delete all comments related to this post
    const commentsToDelete = Array.from(this.comments.values())
      .filter(comment => comment.postId === id);
    
    for (const comment of commentsToDelete) {
      this.comments.delete(comment.id);
    }
    
    // And all likes
    const likesToDelete = Array.from(this.likes.values())
      .filter(like => like.postId === id);
      
    for (const like of likesToDelete) {
      this.likes.delete(like.id);
    }
    
    return this.posts.delete(id);
  }
  
  // Comment operations
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime()); // Oldest first
  }
  
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.commentIdCounter++;
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.comments.set(id, comment);
    
    // Update the post's comment count
    const post = await this.getPost(insertComment.postId);
    if (post) {
      await this.updatePost(post.id, { 
        commentCount: post.commentCount + 1 
      });
      
      // Create an activity
      await this.createActivity({
        userId: insertComment.userId,
        type: "comment_created",
        description: `Commented on the post: "${post.title}"`,
        data: { postId: post.id, commentId: id }
      });
    }
    
    return comment;
  }
  
  async deleteComment(id: number): Promise<boolean> {
    const comment = this.comments.get(id);
    if (!comment) return false;
    
    // Update the post's comment count
    const post = await this.getPost(comment.postId);
    if (post) {
      await this.updatePost(post.id, { 
        commentCount: Math.max(0, post.commentCount - 1) 
      });
    }
    
    return this.comments.delete(id);
  }
  
  // Like operations
  async getLikesByPostId(postId: number): Promise<Like[]> {
    return Array.from(this.likes.values())
      .filter(like => like.postId === postId);
  }
  
  async createLike(insertLike: InsertLike): Promise<Like> {
    // Check if user already liked this post
    const existingLike = Array.from(this.likes.values())
      .find(like => like.userId === insertLike.userId && like.postId === insertLike.postId);
      
    if (existingLike) {
      return existingLike;
    }
    
    const id = this.likeIdCounter++;
    const like: Like = {
      ...insertLike,
      id,
      createdAt: new Date()
    };
    this.likes.set(id, like);
    
    // Update the post's like count
    const post = await this.getPost(insertLike.postId);
    if (post) {
      await this.updatePost(post.id, { 
        likeCount: post.likeCount + 1 
      });
      
      // Create an activity
      await this.createActivity({
        userId: insertLike.userId,
        type: "post_liked",
        description: `Liked the post: "${post.title}"`,
        data: { postId: post.id }
      });
    }
    
    return like;
  }
  
  async deleteLike(userId: number, postId: number): Promise<boolean> {
    const like = Array.from(this.likes.values())
      .find(like => like.userId === userId && like.postId === postId);
      
    if (!like) return false;
    
    // Update the post's like count
    const post = await this.getPost(postId);
    if (post) {
      await this.updatePost(post.id, { 
        likeCount: Math.max(0, post.likeCount - 1) 
      });
    }
    
    return this.likes.delete(like.id);
  }
  
  async isLikedByUser(userId: number, postId: number): Promise<boolean> {
    return Array.from(this.likes.values())
      .some(like => like.userId === userId && like.postId === postId);
  }

  // Additional survey methods
  async getSurveysForFeed(excludeUserId?: number, limit = 10): Promise<Survey[]> {
    let surveys = Array.from(this.surveys.values())
      .filter(survey => survey.status === 'published');
    
    // If excludeUserId is provided, filter out that user's surveys
    if (excludeUserId) {
      surveys = surveys.filter(survey => survey.userId !== excludeUserId);
    }
    
    // Sort by creation date (newest first) and limit the results
    return surveys
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
  }

  // Survey Response operations
  async getSurveyResponsesByUserId(userId: number): Promise<SurveyResponse[]> {
    return Array.from(this.surveyResponses.values())
      .filter(response => response.respondentId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getSurveyResponsesBySurveyId(surveyId: number): Promise<SurveyResponse[]> {
    return Array.from(this.surveyResponses.values())
      .filter(response => response.surveyId === surveyId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createSurveyResponse(insertResponse: InsertSurveyResponse): Promise<SurveyResponse> {
    const id = this.surveyResponseIdCounter++;
    const surveyResponse: SurveyResponse = {
      ...insertResponse,
      id,
      createdAt: new Date()
    };
    this.surveyResponses.set(id, surveyResponse);
    
    // Update the survey response count
    const survey = await this.getSurvey(insertResponse.surveyId);
    if (survey) {
      const responseCount = (survey.responseCount || 0) + 1;
      await this.updateSurvey(survey.id, { responseCount });
    }
    
    // Create an activity for the response
    await this.createActivity({
      userId: insertResponse.respondentId,
      type: 'survey_response',
      description: `Responded to a survey`,
      data: { surveyId: insertResponse.surveyId, responseId: id }
    });
    
    return surveyResponse;
  }

  async hasUserRespondedToSurvey(userId: number, surveyId: number): Promise<boolean> {
    return Array.from(this.surveyResponses.values()).some(
      response => response.respondentId === userId && response.surveyId === surveyId
    );
  }

  // Follow operations
  async getFollowers(userId: number): Promise<User[]> {
    // Get all follows where the user is being followed
    const followerIds = Array.from(this.follows.values())
      .filter(follow => follow.followingId === userId)
      .map(follow => follow.followerId);
    
    // Return the actual user objects
    return Array.from(this.users.values())
      .filter(user => followerIds.includes(user.id));
  }

  async getFollowing(userId: number): Promise<User[]> {
    // Get all follows where the user is following others
    const followingIds = Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId)
      .map(follow => follow.followingId);
    
    // Return the actual user objects
    return Array.from(this.users.values())
      .filter(user => followingIds.includes(user.id));
  }

  async getFollowersCount(userId: number): Promise<number> {
    return Array.from(this.follows.values())
      .filter(follow => follow.followingId === userId)
      .length;
  }

  async getFollowingCount(userId: number): Promise<number> {
    return Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId)
      .length;
  }

  async createFollow(insertFollow: InsertFollow): Promise<Follow> {
    // Check if already following
    const isAlreadyFollowing = await this.isFollowing(
      insertFollow.followerId, 
      insertFollow.followingId
    );
    
    if (isAlreadyFollowing) {
      throw new Error('Already following this user');
    }
    
    const id = this.followIdCounter++;
    const follow: Follow = {
      ...insertFollow,
      id,
      createdAt: new Date()
    };
    this.follows.set(id, follow);
    
    // Create an activity for the follow
    const followingUser = await this.getUser(insertFollow.followingId);
    if (followingUser) {
      await this.createActivity({
        userId: insertFollow.followerId,
        type: 'follow_created',
        description: `Started following ${followingUser.displayName || followingUser.username}`,
        data: { followingId: insertFollow.followingId }
      });
    }
    
    return follow;
  }

  async deleteFollow(followerId: number, followingId: number): Promise<boolean> {
    const follow = Array.from(this.follows.values()).find(
      f => f.followerId === followerId && f.followingId === followingId
    );
    
    if (!follow) {
      return false;
    }
    
    return this.follows.delete(follow.id);
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    return Array.from(this.follows.values()).some(
      follow => follow.followerId === followerId && follow.followingId === followingId
    );
  }

  // Method to get posts by user ID
  async getPostsByUserId(userId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }
}

export const storage = new MemStorage();
