import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import path from "path";
import { 
  insertUserSchema, 
  insertSurveySchema, 
  insertActivitySchema, 
  insertAchievementSchema, 
  insertWalletTransactionSchema, 
  insertPostSchema, 
  insertCommentSchema, 
  insertLikeSchema,
  insertFollowSchema,
  insertSurveyResponseSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve static assets from the public directory
  app.use('/assets', express.static(path.join(process.cwd(), 'public', 'assets')));
  
  const apiRouter = express.Router();
  
  // User endpoints
  apiRouter.get("/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send the password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  apiRouter.post("/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Don't send the password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create user" });
      }
    }
  });
  
  apiRouter.patch("/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(id, req.body);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send the password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Survey endpoints
  apiRouter.get("/surveys/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const survey = await storage.getSurvey(id);
    if (!survey) {
      return res.status(404).json({ message: "Survey not found" });
    }
    
    res.json(survey);
  });
  
  apiRouter.get("/users/:userId/surveys", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const surveys = await storage.getSurveysByUserId(userId);
    res.json(surveys);
  });
  
  apiRouter.post("/surveys", async (req, res) => {
    try {
      const surveyData = insertSurveySchema.parse(req.body);
      const survey = await storage.createSurvey(surveyData);
      res.status(201).json(survey);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create survey" });
      }
    }
  });
  
  apiRouter.patch("/surveys/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const updatedSurvey = await storage.updateSurvey(id, req.body);
      if (!updatedSurvey) {
        return res.status(404).json({ message: "Survey not found" });
      }
      
      res.json(updatedSurvey);
    } catch (error) {
      res.status(500).json({ message: "Failed to update survey" });
    }
  });
  
  apiRouter.delete("/surveys/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const deleted = await storage.deleteSurvey(id);
    if (!deleted) {
      return res.status(404).json({ message: "Survey not found" });
    }
    
    res.json({ success: true });
  });
  
  // Activity endpoints
  apiRouter.get("/users/:userId/activities", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const activities = await storage.getActivitiesByUserId(userId, limit);
    res.json(activities);
  });
  
  apiRouter.post("/activities", async (req, res) => {
    try {
      const activityData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create activity" });
      }
    }
  });
  
  // Achievement endpoints
  apiRouter.get("/users/:userId/achievements", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const achievements = await storage.getAchievementsByUserId(userId);
    res.json(achievements);
  });
  
  apiRouter.post("/achievements", async (req, res) => {
    try {
      const achievementData = insertAchievementSchema.parse(req.body);
      const achievement = await storage.createAchievement(achievementData);
      res.status(201).json(achievement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create achievement" });
      }
    }
  });
  
  apiRouter.patch("/achievements/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const updatedAchievement = await storage.updateAchievement(id, req.body);
      if (!updatedAchievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      res.json(updatedAchievement);
    } catch (error) {
      res.status(500).json({ message: "Failed to update achievement" });
    }
  });
  
  // Wallet endpoints
  apiRouter.get("/users/:userId/wallet/transactions", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const transactions = await storage.getWalletTransactionsByUserId(userId);
    res.json(transactions);
  });
  
  apiRouter.get("/users/:userId/wallet/balance", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const balance = await storage.getWalletBalance(userId);
    res.json({ balance });
  });
  
  apiRouter.post("/wallet/transactions", async (req, res) => {
    try {
      const transactionData = insertWalletTransactionSchema.parse(req.body);
      const transaction = await storage.createWalletTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create transaction" });
      }
    }
  });
  
  // Social endpoints - Posts
  apiRouter.get("/posts", async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const offset = req.query.offset ? parseInt(req.query.offset as string) : undefined;
    
    const posts = await storage.getPosts(limit, offset);
    res.json(posts);
  });
  
  apiRouter.get("/posts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const post = await storage.getPost(id);
    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }
    
    res.json(post);
  });
  
  apiRouter.post("/posts", async (req, res) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create post" });
      }
    }
  });
  
  apiRouter.patch("/posts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const updatedPost = await storage.updatePost(id, req.body);
      if (!updatedPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json(updatedPost);
    } catch (error) {
      res.status(500).json({ message: "Failed to update post" });
    }
  });
  
  apiRouter.delete("/posts/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const deleted = await storage.deletePost(id);
    if (!deleted) {
      return res.status(404).json({ message: "Post not found" });
    }
    
    res.json({ success: true });
  });
  
  // Social endpoints - Comments
  apiRouter.get("/posts/:postId/comments", async (req, res) => {
    const postId = parseInt(req.params.postId);
    if (isNaN(postId)) {
      return res.status(400).json({ message: "Invalid post ID format" });
    }
    
    const comments = await storage.getCommentsByPostId(postId);
    res.json(comments);
  });
  
  apiRouter.post("/comments", async (req, res) => {
    try {
      const commentData = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create comment" });
      }
    }
  });
  
  apiRouter.delete("/comments/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const deleted = await storage.deleteComment(id);
    if (!deleted) {
      return res.status(404).json({ message: "Comment not found" });
    }
    
    res.json({ success: true });
  });
  
  // Social endpoints - Likes
  apiRouter.get("/posts/:postId/likes", async (req, res) => {
    const postId = parseInt(req.params.postId);
    if (isNaN(postId)) {
      return res.status(400).json({ message: "Invalid post ID format" });
    }
    
    const likes = await storage.getLikesByPostId(postId);
    res.json(likes);
  });
  
  apiRouter.post("/likes", async (req, res) => {
    try {
      const likeData = insertLikeSchema.parse(req.body);
      const like = await storage.createLike(likeData);
      res.status(201).json(like);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create like" });
      }
    }
  });
  
  apiRouter.delete("/likes", async (req, res) => {
    const userId = parseInt(req.query.userId as string);
    const postId = parseInt(req.query.postId as string);
    
    if (isNaN(userId) || isNaN(postId)) {
      return res.status(400).json({ message: "Invalid ID format. Both userId and postId are required." });
    }
    
    const deleted = await storage.deleteLike(userId, postId);
    if (!deleted) {
      return res.status(404).json({ message: "Like not found" });
    }
    
    res.json({ success: true });
  });
  
  apiRouter.get("/users/:userId/likes/:postId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const postId = parseInt(req.params.postId);
    
    if (isNaN(userId) || isNaN(postId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const isLiked = await storage.isLikedByUser(userId, postId);
    res.json({ isLiked });
  });

  // Social endpoints - User follows
  apiRouter.get("/users/:userId/followers", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const followers = await storage.getFollowers(userId);
    res.json(followers);
  });

  apiRouter.get("/users/:userId/following", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const following = await storage.getFollowing(userId);
    res.json(following);
  });

  apiRouter.get("/users/:userId/followers/count", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const count = await storage.getFollowersCount(userId);
    res.json({ count });
  });

  apiRouter.get("/users/:userId/following/count", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const count = await storage.getFollowingCount(userId);
    res.json({ count });
  });

  apiRouter.get("/users/:followerId/is-following/:followingId", async (req, res) => {
    const followerId = parseInt(req.params.followerId);
    const followingId = parseInt(req.params.followingId);
    
    if (isNaN(followerId) || isNaN(followingId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const isFollowing = await storage.isFollowing(followerId, followingId);
    res.json({ isFollowing });
  });

  apiRouter.post("/follows", async (req, res) => {
    try {
      const followData = insertFollowSchema.parse(req.body);
      const follow = await storage.createFollow(followData);
      res.status(201).json(follow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(400).json({ message: "Failed to create follow relationship or already following" });
      }
    }
  });

  apiRouter.delete("/follows", async (req, res) => {
    const followerId = parseInt(req.query.followerId as string);
    const followingId = parseInt(req.query.followingId as string);
    
    if (isNaN(followerId) || isNaN(followingId)) {
      return res.status(400).json({ message: "Invalid ID format. Both followerId and followingId are required." });
    }
    
    const deleted = await storage.deleteFollow(followerId, followingId);
    if (!deleted) {
      return res.status(404).json({ message: "Follow relationship not found" });
    }
    
    res.json({ success: true });
  });

  // Survey related endpoints - feed & responses
  apiRouter.get("/surveys/feed", async (req, res) => {
    const excludeUserId = req.query.excludeUserId ? parseInt(req.query.excludeUserId as string) : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    
    const surveys = await storage.getSurveysForFeed(excludeUserId, limit);
    res.json(surveys);
  });

  apiRouter.get("/users/:userId/posts", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const posts = await storage.getPostsByUserId(userId);
    res.json(posts);
  });

  apiRouter.get("/surveys/:surveyId/responses", async (req, res) => {
    const surveyId = parseInt(req.params.surveyId);
    if (isNaN(surveyId)) {
      return res.status(400).json({ message: "Invalid survey ID format" });
    }
    
    const responses = await storage.getSurveyResponsesBySurveyId(surveyId);
    res.json(responses);
  });

  apiRouter.get("/users/:userId/survey-responses", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID format" });
    }
    
    const responses = await storage.getSurveyResponsesByUserId(userId);
    res.json(responses);
  });

  apiRouter.get("/users/:userId/has-responded-to/:surveyId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    const surveyId = parseInt(req.params.surveyId);
    
    if (isNaN(userId) || isNaN(surveyId)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const hasResponded = await storage.hasUserRespondedToSurvey(userId, surveyId);
    res.json({ hasResponded });
  });

  apiRouter.post("/survey-responses", async (req, res) => {
    try {
      const responseData = insertSurveyResponseSchema.parse(req.body);
      const response = await storage.createSurveyResponse(responseData);
      res.status(201).json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation failed", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create survey response" });
      }
    }
  });
  
  // Mount the API router
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
